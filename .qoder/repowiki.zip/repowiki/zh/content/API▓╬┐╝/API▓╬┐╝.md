# API参考

<cite>
**本文档中引用的文件**  
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java)
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java)
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java)
- [HandlerFeedBackVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerFeedBackVo.java)
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java)
</cite>

## 目录
1. [简介](#简介)
2. [API端点概览](#api端点概览)
3. [核心数据结构](#核心数据结构)
4. [WarmFlowController API详情](#warmflowcontroller-api详情)
5. [WarmFlowUiController API详情](#warmflowuicontroller-api详情)
6. [错误码说明](#错误码说明)
7. [使用示例](#使用示例)

## 简介
warm-flow是一个流程引擎系统，提供了一套完整的RESTful API用于流程定义、表单管理和任务处理。本参考文档详细说明了`WarmFlowController`和`WarmFlowUiController`中的所有API端点，包括HTTP方法、URL路径、请求头、请求体和响应体结构。这些API分为两类：`WarmFlowController`中的API主要用于前端UI与后端服务的交互，需要认证；`WarmFlowUiController`中的API用于前端UI的匿名访问配置。

## API端点概览
warm-flow提供了两类控制器来处理不同的API请求：
- **WarmFlowController**: 处理需要认证的API请求，主要用于流程设计、任务处理和数据获取，URL路径以`/warm-flow`为前缀。
- **WarmFlowUiController**: 处理匿名访问的API请求，主要用于获取前端UI的配置信息，URL路径以`/warm-flow-ui`为前缀。

所有API的响应都包装在`ApiResult`对象中，确保了统一的响应格式。

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)

## 核心数据结构
本节描述API中使用的核心数据结构，这些结构定义了请求和响应的数据格式。

### ApiResult
`ApiResult`是所有API响应的通用包装类，包含状态码、消息和数据。

```mermaid
classDiagram
class ApiResult~T~ {
+int code
+String msg
+T data
+static final int SUCCESS = 200
+static final int FAIL = 500
+static <T> ApiResult<T> ok()
+static <T> ApiResult<T> ok(T data)
+static <T> ApiResult<T> fail()
+static <T> ApiResult<T> fail(String msg)
}
```

**Diagram sources**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)

### DefJson
`DefJson`表示流程定义的JSON对象，包含流程的基本信息、节点和跳转关系。

```mermaid
classDiagram
class DefJson {
+Long id
+String flowCode
+String flowName
+String modelValue
+String category
+String version
+Integer isPublish
+String formCustom
+String formPath
+String listenerType
+String listenerPath
+Instance instance
+String ext
+Map<String, Object> extMap
+List<NodeJson> nodeList
+List<String> chartStatusColor
+String topText
+boolean topTextShow
+String createBy
+String updateBy
+List<Tree> categoryList
+List<Tree> formPathList
}
```

**Diagram sources**
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java)

### FlowDto
`FlowDto`表示流程任务的数据传输对象，包含表单内容和表单数据。

```mermaid
classDiagram
class FlowDto {
+Long id
+String formContent
+Form form
+Object data
}
```

**Diagram sources**
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java)

## WarmFlowController API详情
`WarmFlowController`提供了流程管理和任务处理的核心API，所有端点都需要认证。

### 保存流程JSON
保存流程定义的JSON字符串。

- **HTTP方法**: POST
- **URL路径**: `/warm-flow/save-json`
- **请求头**: `Authorization: Bearer <token>`, `onlyNodeSkip: boolean`
- **请求体**: `DefJson`对象
- **响应体**: `ApiResult<Void>`
- **用途**: 前端UI用于保存流程设计
- **curl示例**:
```bash
curl -X POST "http://localhost:8080/warm-flow/save-json" \
  -H "Authorization: Bearer your_token" \
  -H "onlyNodeSkip: false" \
  -H "Content-Type: application/json" \
  -d '{"flowCode":"flow001","flowName":"测试流程","nodeList":[]}'
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L58)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L79-L82)

### 查询流程定义
获取流程定义的全部数据，包含节点和跳转。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/query-def` 或 `/warm-flow/query-def/{id}`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `id` (可选，流程定义ID)
- **响应体**: `ApiResult<DefJson>`
- **用途**: 前端UI用于加载流程设计
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/query-def/123" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L68-L71)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L92-L119)

### 获取流程图
根据流程实例ID获取流程图数据。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/query-flow-chart/{id}`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `id` (流程实例ID)
- **响应体**: `ApiResult<DefJson>`
- **用途**: 前端UI用于显示流程图
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/query-flow-chart/456" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L79-L82)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L128-L151)

### 办理人类型
获取办理人权限设置的类型列表。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/handler-type`
- **请求头**: `Authorization: Bearer <token>`
- **响应体**: `ApiResult<List<String>>`
- **用途**: 前端UI用于显示办理人类型选项卡
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/handler-type" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L89-L92)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L158-L171)

### 办理人结果
根据查询条件获取办理人权限设置的结果。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/handler-result`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `HandlerQuery`对象
- **响应体**: `ApiResult<HandlerSelectVo>`
- **用途**: 前端UI用于获取办理人选择结果
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/handler-result?handlerCode=admin&handlerType=user" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L99-L102)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L178-L191)

### 办理人回显
根据存储ID获取办理人权限名称的回显信息。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/handler-feedback`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `HandlerFeedBackDto`对象
- **响应体**: `ApiResult<List<HandlerFeedBackVo>>`
- **用途**: 前端UI用于回显已选择的办理人
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/handler-feedback?storageIds=role:1,user:2" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L109-L112)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L198-L213)

### 办理人字典
获取办理人选择项的字典列表。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/handler-dict`
- **请求头**: `Authorization: Bearer <token>`
- **响应体**: `ApiResult<List<Dict>>`
- **用途**: 前端UI用于显示办理人选择的字典选项
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/handler-dict" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L119-L122)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L220-L246)

### 已发布表单
获取已发布的表单列表。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/published-form`
- **请求头**: `Authorization: Bearer <token>`
- **响应体**: `ApiResult<List<Form>>`
- **用途**: 前端UI用于显示已发布的表单
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/published-form" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L128-L131)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L251-L258)

### 表单内容获取
根据表单ID获取表单内容。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/form-content/{id}`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `id` (表单ID)
- **响应体**: `ApiResult<String>`
- **用途**: 前端UI用于加载表单内容
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/form-content/789" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L139-L142)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L266-L273)

### 表单内容保存
保存表单内容。

- **HTTP方法**: POST
- **URL路径**: `/warm-flow/form-content`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**: `FlowDto`对象
- **响应体**: `ApiResult<Void>`
- **用途**: 前端UI用于保存表单内容
- **curl示例**:
```bash
curl -X POST "http://localhost:8080/warm-flow/form-content" \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{"id":789,"formContent":"{\"name\":\"test\"}"}'
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L150-L154)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L281-L284)

### 加载待办任务
根据任务ID加载待办任务的表单及数据。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/execute/load/{taskId}`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `taskId` (任务ID)
- **响应体**: `ApiResult<FlowDto>`
- **用途**: 前端UI用于加载待办任务
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/execute/load/101" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L165-L168)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L295-L300)

### 加载已办任务
根据历史任务ID加载已办任务的表单及数据。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/execute/hisLoad/{taskId}`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `taskId` (历史任务ID)
- **响应体**: `ApiResult<FlowDto>`
- **用途**: 前端UI用于加载已办任务
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/execute/hisLoad/102" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L176-L179)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L307-L311)

### 任务审批
通用表单流程审批接口。

- **HTTP方法**: POST
- **URL路径**: `/warm-flow/execute/handle`
- **请求头**: `Authorization: Bearer <token>`
- **请求参数**: `formData` (表单数据), `taskId` (任务ID), `skipType` (跳转类型), `message` (审批意见), `nodeCode` (节点编码)
- **响应体**: `ApiResult<Instance>`
- **用途**: 前端UI用于提交任务审批
- **curl示例**:
```bash
curl -X POST "http://localhost:8080/warm-flow/execute/handle?taskId=101&skipType=APPROVE&message=同意" \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{"name":"张三","age":25}'
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L192-L197)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L323-L333)

### 节点扩展属性
获取节点的扩展属性。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow/node-ext`
- **请求头**: `Authorization: Bearer <token>`
- **响应体**: `ApiResult<List<NodeExt>>`
- **用途**: 前端UI用于获取节点扩展属性
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow/node-ext" \
  -H "Authorization: Bearer your_token"
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L204-L207)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L334-L353)

## WarmFlowUiController API详情
`WarmFlowUiController`提供了前端UI的配置信息，所有端点都支持匿名访问。

### 获取配置
返回流程定义的配置信息。

- **HTTP方法**: GET
- **URL路径**: `/warm-flow-ui/config`
- **请求头**: 无
- **响应体**: `ApiResult<WarmFlowVo>`
- **用途**: 前端UI用于获取系统配置
- **curl示例**:
```bash
curl -X GET "http://localhost:8080/warm-flow-ui/config"
```

```mermaid
classDiagram
class WarmFlowVo {
+List<String> tokenNameList
}
```

**Diagram sources**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L39-L42)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)

**Section sources**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L39-L42)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L53-L67)

## 错误码说明
本节说明API可能返回的错误码及其含义。

| 错误码 | 含义 | 说明 |
|-------|------|------|
| 200 | SUCCESS | 操作成功 |
| 500 | FAIL | 操作失败 |
| 401 | UNAUTHORIZED | 未授权访问 |
| 400 | BAD_REQUEST | 请求参数错误 |
| 404 | NOT_FOUND | 资源未找到 |

**Section sources**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L36-L41)

## 使用示例
以下是一个完整的流程审批使用示例：

1. 首先获取流程定义：
```bash
curl -X GET "http://localhost:8080/warm-flow/query-def/123" \
  -H "Authorization: Bearer your_token"
```

2. 加载待办任务：
```bash
curl -X GET "http://localhost:8080/warm-flow/execute/load/101" \
  -H "Authorization: Bearer your_token"
```

3. 提交审批：
```bash
curl -X POST "http://localhost:8080/warm-flow/execute/handle?taskId=101&skipType=APPROVE&message=同意" \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{"name":"张三","age":25}'
```

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
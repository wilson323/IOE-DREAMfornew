# 用户与权限相关API

<cite>
**本文档中引用的文件**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java)
- [HandlerFeedBackVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerFeedBackVo.java)
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java)
- [HandlerSelectService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerSelectService.java)
- [HandlerDictService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerDictService.java)
- [definition.js](file://warm-flow-ui/src/api/flow/definition.js)
- [selectUser.vue](file://warm-flow-ui/src/components/design/common/vue/selectUser.vue)
- [nodeExtList.vue](file://warm-flow-ui/src/components/design/common/vue/nodeExtList.vue)
</cite>

## 目录
1. [简介](#简介)
2. [API架构概览](#api架构概览)
3. [核心API端点详解](#核心api端点详解)
4. [数据模型说明](#数据模型说明)
5. [使用场景与示例](#使用场景与示例)
6. [集成指南](#集成指南)
7. [错误处理](#错误处理)
8. [最佳实践](#最佳实践)

## 简介

WarmFlow框架提供了完整的用户与权限管理API，专门用于流程节点中办理人的动态配置和权限控制。这些API支持在流程设计器中配置各种类型的办理人，包括用户、角色、部门等，并提供灵活的权限验证和回显功能。

主要功能包括：
- 办理人权限类型列表获取
- 办理人选择结果查询
- 权限名称回显显示
- 办理人选择项字典获取
- 支持多种权限类型（用户、角色、部门等）
- 分页查询和树形结构支持

## API架构概览

WarmFlow的用户与权限API采用RESTful设计，基于Spring Boot和Solon两种框架实现，提供统一的接口规范。

```mermaid
graph TB
subgraph "前端应用"
UI[流程设计器UI]
API_CLIENT[API客户端]
end
subgraph "WarmFlow控制器层"
SB_CONTROLLER[Spring Boot控制器]
SOLON_CONTROLLER[Solon控制器]
end
subgraph "服务层"
WARM_SERVICE[WarmFlowService]
HANDLER_SERVICE[HandlerSelectService]
DICT_SERVICE[HandlerDictService]
end
subgraph "数据层"
BUSINESS_SYS[业务系统]
DATABASE[(数据库)]
end
UI --> API_CLIENT
API_CLIENT --> SB_CONTROLLER
API_CLIENT --> SOLON_CONTROLLER
SB_CONTROLLER --> WARM_SERVICE
SOLON_CONTROLLER --> WARM_SERVICE
WARM_SERVICE --> HANDLER_SERVICE
WARM_SERVICE --> DICT_SERVICE
HANDLER_SERVICE --> BUSINESS_SYS
DICT_SERVICE --> BUSINESS_SYS
BUSINESS_SYS --> DATABASE
```

**图表来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L41-L210)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L41-L236)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L45-L356)

## 核心API端点详解

### 1. 获取办理人权限类型列表

**端点描述**: 获取流程设计器中可用的办理人权限类型列表，如用户、角色、部门等。

**HTTP方法**: GET  
**完整URL路径**: `/warm-flow/handler-type`  
**请求参数**: 无  
**请求体**: 无  
**响应体**: `ApiResult<List<String>>`

**响应结构**:
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": [
    "用户",
    "角色",
    "部门",
    "岗位"
  ]
}
```

**使用场景**: 在流程设计器的权限配置面板中，初始化权限类型选项卡。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L89-L92)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L106-L109)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L158-L170)

### 2. 查询办理人选择结果

**端点描述**: 根据查询条件获取办理人列表，支持分页和树形结构展示。

**HTTP方法**: GET  
**完整URL路径**: `/warm-flow/handler-result`  
**查询参数**: `HandlerQuery` 对象  
**请求体**: 无  
**响应体**: `ApiResult<HandlerSelectVo>`

**查询参数结构** (`HandlerQuery`):
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| handlerCode | String | 否 | 权限编码，如：zhang、roleAdmin、deptAdmin等 |
| handlerName | String | 否 | 权限名称，如：管理员、角色管理员等 |
| handlerType | String | 是 | 办理权限类型，如用户/角色/部门等 |
| groupId | String | 否 | 页面左侧树权限分组主键 |
| pageNum | Integer | 否 | 当前页码，默认1 |
| pageSize | Integer | 否 | 每页显示条数，默认10 |
| beginTime | String | 否 | 开始时间，格式：yyyy-MM-dd |
| endTime | String | 否 | 结束时间，格式：yyyy-MM-dd |

**响应体结构** (`HandlerSelectVo`):
```json
{
  "handlerAuths": {
    "code": 200,
    "msg": "查询成功",
    "rows": [
      {
        "storageId": "user:1001",
        "handlerCode": "admin",
        "handlerName": "系统管理员",
        "groupName": "技术部",
        "createTime": "2024-01-15 10:30:00"
      }
    ],
    "total": 15,
    "pageNum": 1,
    "pageSize": 10
  },
  "treeSelections": [
    {
      "id": "dept:1",
      "name": "技术部",
      "parentId": null,
      "children": [
        {
          "id": "dept:2",
          "name": "研发组",
          "parentId": "dept:1"
        }
      ]
    }
  ]
}
```

**使用场景**: 在权限配置界面中，根据当前选择的权限类型和查询条件，动态加载对应的办理人列表。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L99-L102)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L118-L121)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L178-L190)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java#L27-L72)

### 3. 回显办理人权限名称

**端点描述**: 根据存储ID集合回显对应的权限名称，主要用于权限配置后的结果显示。

**HTTP方法**: GET  
**完整URL路径**: `/warm-flow/handler-feedback`  
**查询参数**: `HandlerFeedBackDto` 对象  
**请求体**: 无  
**响应体**: `ApiResult<List<HandlerFeedBackVo>>`

**查询参数结构** (`HandlerFeedBackDto`):
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| storageIds | List<String> | 是 | 存储主键集合，如：["user:1001", "role:2001"] |

**响应体结构** (`List<HandlerFeedBackVo>`):
```json
[
  {
    "storageId": "user:1001",
    "handlerName": "张三"
  },
  {
    "storageId": "role:2001",
    "handlerName": "系统管理员"
  }
]
```

**使用场景**: 在权限配置完成后，需要显示用户选择的权限名称时使用，如显示"张三(系统管理员)"的组合名称。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L109-L112)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L129-L132)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L198-L213)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java#L29-L40)

### 4. 获取办理人选择项字典

**端点描述**: 获取办理人选择项的字典配置，主要用于表达式配置和权限规则设置。

**HTTP方法**: GET  
**完整URL路径**: `/warm-flow/handler-dict`  
**请求参数**: 无  
**请求体**: 无  
**响应体**: `ApiResult<List<Dict>>`

**响应体结构** (`List<Dict>`):
```json
[
  {
    "label": "默认表达式",
    "value": "${handler}",
    "childList": null
  },
  {
    "label": "spel表达式",
    "value": "#{@user.evalVar(#handler)}",
    "childList": null
  },
  {
    "label": "其他",
    "value": "",
    "childList": null
  }
]
```

**使用场景**: 在流程节点的权限表达式配置中，提供可用的表达式模板供用户选择。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L119-L122)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L139-L142)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L215-L246)
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java#L29-L47)

## 数据模型说明

### HandlerQuery 查询模型

`HandlerQuery` 是办理人查询的核心参数模型，支持多种查询条件组合。

```mermaid
classDiagram
class HandlerQuery {
+String handlerCode
+String handlerName
+String handlerType
+String groupId
+Integer pageNum
+Integer pageSize
+String beginTime
+String endTime
}
class HandlerSelectVo {
+FlowPage~HandlerAuth~ handlerAuths
+Tree[] treeSelections
}
class HandlerAuth {
+String storageId
+String handlerCode
+String handlerName
+String groupName
+String createTime
}
class FlowPage {
+int code
+String msg
+T[] rows
+long total
+int pageNum
+int pageSize
}
HandlerSelectVo --> FlowPage
FlowPage --> HandlerAuth
```

**图表来源**
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java#L27-L72)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java#L31-L47)

### HandlerFeedBackDto 和 HandlerFeedBackVo

权限名称回显相关的数据传输模型。

```mermaid
classDiagram
class HandlerFeedBackDto {
+String[] storageIds
}
class HandlerFeedBackVo {
+String storageId
+String handlerName
}
HandlerFeedBackDto --> HandlerFeedBackVo : "转换为"
```

**图表来源**
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java#L29-L40)
- [HandlerFeedBackVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerFeedBackVo.java#L34-L46)

### Dict 字典模型

权限表达式和配置项的字典模型。

```mermaid
classDiagram
class Dict {
+String label
+String value
+Dict[] childList
}
Dict --> Dict : "子级"
```

**图表来源**
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java#L29-L47)

## 使用场景与示例

### 场景一：流程节点审批人配置

在流程设计器中配置审批节点的办理人：

```mermaid
sequenceDiagram
participant Designer as 流程设计器
participant API as WarmFlow API
participant Business as 业务系统
Designer->>API : GET /warm-flow/handler-type
API-->>Designer : ["用户", "角色", "部门"]
Designer->>API : GET /warm-flow/handler-result?handlerType=用户&handlerName=张三
API->>Business : 查询用户列表
Business-->>API : 用户数据列表
API-->>Designer : 分页用户列表+树形结构
Designer->>API : GET /warm-flow/handler-feedback?storageIds=["user : 1001","role : 2001"]
API->>Business : 查询权限名称
Business-->>API : ["张三", "系统管理员"]
API-->>Designer : 权限名称回显
Designer->>API : GET /warm-flow/handler-dict
API-->>Designer : 表达式字典配置
```

**图表来源**
- [selectUser.vue](file://warm-flow-ui/src/components/design/common/vue/selectUser.vue#L180-L210)
- [definition.js](file://warm-flow-ui/src/api/flow/definition.js#L38-L86)

### 场景二：抄送人配置流程

配置流程节点的抄送人：

```mermaid
flowchart TD
A[打开抄送人配置] --> B[获取权限类型]
B --> C[用户选择权限类型]
C --> D[加载权限列表]
D --> E[多选权限项]
E --> F[回显权限名称]
F --> G[保存配置]
B --> B1[handlerType API]
D --> D1[handlerResult API]
F --> F1[handlerFeedback API]
G --> G1[保存到流程定义]
```

**图表来源**
- [nodeExtList.vue](file://warm-flow-ui/src/components/design/common/vue/nodeExtList.vue#L121-L161)

### 实际代码示例

前端Vue组件中的API调用示例：

```javascript
// 获取权限类型
function getTabsType() {
  handlerType().then(res => {
    tabsList.value = res.data;
    if(res.data && res.data.length > 0) {
        tabsValue.value = res.data[0]
    }
    getList();
  });
}

// 查询权限列表
function getList() {
  loading.value = true;
  queryParams.value.handlerType = tabsValue.value;
  handlerResult(queryParams.value).then(res => {
    loading.value = false;
    tableList.value = res.data.handlerAuths.rows;
    total.value = res.data.handlerAuths.total;
    groupOptions.value = res.data.treeSelections;
  });
}

// 权限名称回显
function getHandlerFeedback() {
  handlerFeedback({storageIds: form.value[key]}).then(response => {
    if (response.code === 200 && response.data) {
      permissionRows.value[key] = response.data;
    }
  });
}
```

**节来源**
- [selectUser.vue](file://warm-flow-ui/src/components/design/common/vue/selectUser.vue#L180-L210)
- [nodeExtList.vue](file://warm-flow-ui/src/components/design/common/vue/nodeExtList.vue#L121-L161)

## 集成指南

### 1. 服务接口实现

业务系统需要实现以下接口来提供具体的权限数据：

```java
// 办理人选择服务接口
public interface HandlerSelectService {
    // 获取权限类型列表
    List<String> getHandlerType();
    
    // 获取权限列表
    HandlerSelectVo getHandlerSelect(HandlerQuery query);
    
    // 权限名称回显
    List<HandlerFeedBackVo> handlerFeedback(List<String> storageIds);
}

// 办理人字典服务接口
public interface HandlerDictService {
    // 获取权限表达式字典
    List<Dict> getHandlerDict();
}
```

### 2. 配置注入

在业务系统的Spring容器中注册服务实现：

```java
@Configuration
public class WarmFlowConfig {
    
    @Bean
    public HandlerSelectService handlerSelectService() {
        return new CustomHandlerSelectService();
    }
    
    @Bean
    public HandlerDictService handlerDictService() {
        return new CustomHandlerDictService();
    }
}
```

### 3. 前端集成

前端通过标准的HTTP客户端调用API：

```javascript
// 使用axios或其他HTTP库
import axios from 'axios';

// 配置基础URL
const api = axios.create({
  baseURL: '/warm-flow/',
  timeout: 5000
});

// 封装API调用
export const WarmFlowAPI = {
  // 获取权限类型
  getHandlerTypes: () => api.get('/handler-type'),
  
  // 查询权限列表
  queryHandlers: (params) => api.get('/handler-result', { params }),
  
  // 权限名称回显
  getHandlerFeedback: (storageIds) => api.get('/handler-feedback', { 
    params: { storageIds } 
  }),
  
  // 获取表达式字典
  getHandlerDict: () => api.get('/handler-dict')
};
```

## 错误处理

### 常见错误码

| 错误码 | 描述 | 解决方案 |
|--------|------|----------|
| 500 | 服务器内部错误 | 检查业务服务实现，查看日志 |
| 400 | 请求参数错误 | 验证HandlerQuery参数格式 |
| 404 | 资源不存在 | 确认业务服务已正确注册 |
| 401 | 权限不足 | 检查用户权限配置 |

### 错误处理策略

```javascript
// 统一错误处理
const errorHandler = (error) => {
  if (error.response) {
    // 服务器返回错误
    switch(error.response.status) {
      case 400:
        Message.error('请求参数错误');
        break;
      case 401:
        Message.error('权限不足，请重新登录');
        break;
      case 500:
        Message.error('服务器内部错误');
        break;
      default:
        Message.error('未知错误');
    }
  } else if (error.request) {
    // 请求超时
    Message.error('网络连接超时');
  } else {
    // 其他错误
    Message.error(error.message);
  }
};
```

## 最佳实践

### 1. 性能优化

- **分页查询**: 对于大量数据，务必使用分页参数避免性能问题
- **缓存机制**: 对于不经常变化的权限类型数据，建议添加缓存
- **懒加载**: 树形结构采用懒加载方式，减少初始加载时间

### 2. 安全考虑

- **权限验证**: 在业务服务中对查询参数进行严格验证
- **数据脱敏**: 敏感信息如密码、密钥等不应通过API暴露
- **访问控制**: 确保只有授权用户才能访问权限管理功能

### 3. 用户体验

- **加载状态**: 显示加载动画，提升用户体验
- **错误提示**: 提供友好的错误提示信息
- **搜索功能**: 支持关键词搜索，快速定位权限项

### 4. 扩展性设计

- **插件化**: 支持自定义权限类型扩展
- **国际化**: 支持多语言权限名称显示
- **主题定制**: 支持UI主题的个性化配置

**节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L158-L246)
- [HandlerSelectService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerSelectService.java#L38-L127)
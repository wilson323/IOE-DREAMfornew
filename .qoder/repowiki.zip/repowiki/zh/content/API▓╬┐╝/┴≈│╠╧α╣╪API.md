# 流程相关API参考文档

<cite>
**本文档中引用的文件**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java)
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java)
- [SkipType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/SkipType.java)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java)
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java)
- [NodeJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/NodeJson.java)
</cite>

## 目录
1. [简介](#简介)
2. [API概览](#api概览)
3. [核心API详解](#核心api详解)
4. [数据结构说明](#数据结构说明)
5. [错误处理](#错误处理)
6. [调用时序图](#调用时序图)
7. [最佳实践](#最佳实践)

## 简介

WarmFlow流程引擎提供了完整的RESTful API接口，用于管理流程定义、流程实例和流程执行。本文档详细介绍了核心的流程相关API，包括流程定义的保存、查询、流程图获取，以及任务的加载和处理等功能。

## API概览

WarmFlow提供的流程相关API主要分为以下几类：

| API分类 | 描述 | 主要用途 |
|---------|------|----------|
| 流程定义管理 | `/warm-flow/save-json`, `/warm-flow/query-def` | 流程设计和定义管理 |
| 流程图展示 | `/warm-flow/query-flow-chart` | 流程可视化展示 |
| 任务管理 | `/warm-flow/execute/load`, `/warm-flow/execute/hisLoad`, `/warm-flow/execute/handle` | 待办任务和已办任务处理 |
| 权限配置 | `/warm-flow/handler-*` | 办理人权限设置 |
| 表单管理 | `/warm-flow/form-*` | 表单内容管理 |

## 核心API详解

### 1. 保存流程定义 - `/warm-flow/save-json`

#### HTTP方法和路径
- **方法**: `POST`
- **路径**: `/warm-flow/save-json`
- **Spring Boot**: `@PostMapping("/save-json")`
- **Solon**: `@Post @Mapping("/save-json")`

#### 请求头
- `Authorization`: 认证令牌（可选）
- `onlyNodeSkip`: `boolean`类型，指示是否只保存节点和跳转信息

#### 请求体
```json
{
  "id": 1,
  "flowCode": "leave_flow",
  "flowName": "请假流程",
  "modelValue": "CLASSICS",
  "category": "HR",
  "version": "1.0",
  "isPublish": 0,
  "formCustom": "N",
  "formPath": "",
  "listenerType": "",
  "listenerPath": "",
  "instance": {},
  "ext": "",
  "extMap": {},
  "nodeList": [
    {
      "nodeType": 0,
      "nodeCode": "start",
      "nodeName": "开始",
      "permissionFlag": "",
      "nodeRatio": 0,
      "coordinate": "100,100",
      "anyNodeSkip": "N",
      "listenerType": "",
      "listenerPath": "",
      "handlerType": "",
      "handlerPath": "",
      "formCustom": "N",
      "formPath": "",
      "ext": "",
      "status": 0,
      "extMap": {},
      "promptContent": {},
      "skipList": []
    }
  ],
  "chartStatusColor": [],
  "topText": "",
  "topTextShow": false,
  "createBy": "admin",
  "updateBy": "admin",
  "categoryList": [],
  "formPathList": []
}
```

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": null
}
```

#### 业务说明
该接口用于保存流程定义的JSON数据，支持完整流程定义或仅保存节点和跳转信息两种模式。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L58)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L58)

### 2. 查询流程定义 - `/warm-flow/query-def`

#### HTTP方法和路径
- **方法**: `GET`
- **路径**: `/warm-flow/query-def` 或 `/warm-flow/query-def/{id}`
- **Spring Boot**: `@GetMapping({"/query-def", "/query-def/{id}")`
- **Solon**: `@Get @Mapping("/query-def/{id}")` 和 `@Get @Mapping("/query-def")`

#### 路径参数
- `id` (可选): 流程定义ID

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1,
    "flowCode": "leave_flow",
    "flowName": "请假流程",
    "modelValue": "CLASSICS",
    "category": "HR",
    "version": "1.0",
    "isPublish": 0,
    "formCustom": "N",
    "formPath": "",
    "listenerType": "",
    "listenerPath": "",
    "instance": {},
    "ext": "",
    "extMap": {},
    "nodeList": [],
    "chartStatusColor": [],
    "topText": "",
    "topTextShow": false,
    "createBy": "admin",
    "updateBy": "admin",
    "categoryList": [],
    "formPathList": []
  }
}
```

#### 业务说明
- 不带ID参数时返回新的空流程定义模板
- 带ID参数时返回指定ID的完整流程定义

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L68-L70)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L69-L72)

### 3. 获取流程图 - `/warm-flow/query-flow-chart`

#### HTTP方法和路径
- **方法**: `GET`
- **路径**: `/warm-flow/query-flow-chart/{id}`
- **Spring Boot**: `@GetMapping("/query-flow-chart/{id}")`
- **Solon**: `@Get @Mapping("/query-flow-chart/{id}")`

#### 路径参数
- `id`: 流程实例ID

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1,
    "flowCode": "leave_flow",
    "flowName": "请假流程",
    "modelValue": "CLASSICS",
    "category": "HR",
    "version": "1.0",
    "isPublish": 1,
    "formCustom": "N",
    "formPath": "",
    "listenerType": "",
    "listenerPath": "",
    "instance": {
      "id": 1001,
      "definitionId": 1,
      "flowName": "请假流程",
      "businessId": "BIZ123",
      "nodeType": 1,
      "nodeCode": "manager_approve",
      "nodeName": "经理审批",
      "variable": "{\"days\":3}",
      "flowStatus": "RUNNING",
      "formCustom": "N",
      "formPath": "",
      "defJson": "",
      "ext": "",
      "activityStatus": 1
    },
    "ext": "",
    "extMap": {},
    "nodeList": [],
    "chartStatusColor": ["#FF0000", "#00FF00", "#0000FF"],
    "topText": "请假流程",
    "topTextShow": true,
    "createBy": "admin",
    "updateBy": "admin",
    "categoryList": [],
    "formPathList": []
  }
}
```

#### 业务说明
根据流程实例ID获取流程图数据，包含当前节点状态和流程变量信息。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L79-L81)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L95-L98)

### 4. 加载待办任务 - `/warm-flow/execute/load`

#### HTTP方法和路径
- **方法**: `GET`
- **路径**: `/warm-flow/execute/load/{taskId}`
- **Spring Boot**: `@GetMapping("/execute/load/{taskId}")`
- **Solon**: `@Get @Mapping("/execute/load/{taskId}")`

#### 路径参数
- `taskId`: 任务ID

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1001,
    "formContent": "<form>...</form>",
    "form": {
      "id": 1,
      "formCode": "leave_form",
      "formName": "请假申请表单",
      "formContent": "<form>...</form>",
      "isPublish": 1,
      "ext": ""
    },
    "data": {
      "applicant": "张三",
      "department": "技术部",
      "days": 3,
      "reason": "身体不适"
    }
  }
}
```

#### 业务说明
根据任务ID获取待办任务的表单内容和业务数据，用于前端展示。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L165-L167)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L189-L191)

### 5. 加载已办任务 - `/warm-flow/execute/hisLoad`

#### HTTP方法和路径
- **方法**: `GET`
- **路径**: `/warm-flow/execute/hisLoad/{taskId}`
- **Spring Boot**: `@GetMapping("/execute/hisLoad/{taskId}")`
- **Solon**: `@Get @Mapping("/execute/hisLoad/{taskId}")`

#### 路径参数
- `taskId`: 任务ID

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1002,
    "formContent": "<form>...</form>",
    "form": {
      "id": 1,
      "formCode": "leave_form",
      "formName": "请假申请表单",
      "formContent": "<form>...</form>",
      "isPublish": 1,
      "ext": ""
    },
    "data": {
      "applicant": "李四",
      "department": "市场部",
      "days": 5,
      "reason": "家庭事务",
      "approvalResult": "同意",
      "approvalMessage": "批准请假"
    }
  }
}
```

#### 业务说明
根据任务ID获取已办任务的表单内容和审批结果，用于历史记录查看。

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L176-L178)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L201-L204)

### 6. 处理任务审批 - `/warm-flow/execute/handle`

#### HTTP方法和路径
- **方法**: `POST`
- **路径**: `/warm-flow/execute/handle`
- **Spring Boot**: `@PostMapping("/execute/handle")`
- **Solon**: `@Post @Mapping("/execute/handle/{taskId}")`

#### 请求参数
- `taskId` (路径参数): 任务ID
- `skipType` (请求参数): 审批类型
- `message` (请求参数): 审批意见
- `nodeCode` (可选请求参数): 节点编码
- `formData` (请求体): 表单数据

#### 请求体示例
```json
{
  "applicant": "王五",
  "department": "财务部",
  "days": 2,
  "reason": "紧急情况",
  "managerComment": "请尽快处理"
}
```

#### 请求参数说明
- `taskId`: 必需，待处理任务的唯一标识
- `skipType`: 必需，审批动作类型，取值见下表
- `message`: 必需，审批意见或备注信息
- `nodeCode`: 可选，指定跳转到的节点编码
- `formData`: 包含表单提交的所有数据

#### skipType参数取值说明

| skipType值 | 中文描述 | 业务含义 | 使用场景 |
|------------|----------|----------|----------|
| `PASS` | 审批通过 | 同意当前审批请求，继续流程 | 正常审批通过 |
| `REJECT` | 退回 | 将流程退回至上一节点或指定节点 | 审批不通过或需要修改 |
| `NONE` | 无动作 | 不进行任何流程跳转，仅记录审批意见 | 查看或评论性质的操作 |

#### 响应体
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1003,
    "definitionId": 1,
    "flowName": "请假流程",
    "businessId": "BIZ124",
    "nodeType": 2,
    "nodeCode": "end",
    "nodeName": "结束",
    "variable": "{\"status\":\"COMPLETED\"}",
    "flowStatus": "COMPLETED",
    "formCustom": "N",
    "formPath": "",
    "defJson": "",
    "ext": "",
    "activityStatus": 2
  }
}
```

#### curl命令示例
```bash
# 审批通过
curl -X POST "http://localhost:8080/warm-flow/execute/handle?taskId=1001&skipType=PASS&message=同意请假" \
  -H "Content-Type: application/json" \
  -d '{
    "applicant": "张三",
    "department": "技术部",
    "days": 3,
    "reason": "身体不适"
  }'

# 退回审批
curl -X POST "http://localhost:8080/warm-flow/execute/handle?taskId=1002&skipType=REJECT&message=需要补充材料" \
  -H "Content-Type: application/json" \
  -d '{
    "applicant": "李四",
    "department": "市场部",
    "days": 5,
    "reason": "家庭事务"
  }'

# 指定节点退回
curl -X POST "http://localhost:8010/warm-flow/execute/handle/1003?skipType=REJECT&message=重新填写&nodeCode=start" \
  -H "Content-Type: application/json" \
  -d '{
    "applicant": "赵六",
    "department": "运营部",
    "days": 1,
    "reason": "临时调整"
  }'
```

#### 业务说明
该接口是流程引擎的核心审批接口，支持多种审批动作：
- **审批通过**: 继续流程到下一个节点
- **退回**: 将流程退回至上一节点或指定节点
- **无动作**: 仅记录审批意见，不改变流程状态

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L191-L197)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L217-L223)

## 数据结构说明

### ApiResult通用响应结构

所有API响应都遵循统一的ApiResult结构：

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {}
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | int | 响应状态码，200表示成功，500表示失败 |
| `msg` | string | 响应消息，描述操作结果 |
| `data` | any | 响应数据，具体结构因接口而异 |

### DefJson流程定义结构

流程定义的核心数据结构：

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | Long | 流程定义ID |
| `flowCode` | string | 流程编码 |
| `flowName` | string | 流程名称 |
| `modelValue` | string | 设计器模型（CLASSICS/MIMIC） |
| `category` | string | 流程类别 |
| `version` | string | 版本号 |
| `isPublish` | Integer | 发布状态（0未发布，1已发布） |
| `formCustom` | string | 是否自定义表单（Y/N） |
| `nodeList` | List<NodeJson> | 节点列表 |
| `chartStatusColor` | List<string> | 流程图状态颜色 |

### FlowDto表单数据结构

表单数据传输对象：

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | Long | 表单ID |
| `formContent` | string | 表单HTML内容 |
| `form` | Form | 表单基本信息 |
| `data` | Object | 表单提交的业务数据 |

### Instance流程实例结构

流程实例的核心信息：

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | Long | 实例ID |
| `definitionId` | Long | 流程定义ID |
| `flowName` | string | 流程名称 |
| `businessId` | string | 业务关联ID |
| `nodeType` | Integer | 当前节点类型 |
| `nodeCode` | string | 当前节点编码 |
| `nodeName` | string | 当前节点名称 |
| `variable` | string | 流程变量（JSON字符串） |
| `flowStatus` | string | 流程状态 |
| `activityStatus` | Integer | 活动状态 |

**节来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L30-L48)
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java#L44-L119)
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java#L29-L53)
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java#L29-L165)

## 错误处理

### 常见错误码

| HTTP状态码 | 错误类型 | 描述 | 解决方案 |
|------------|----------|------|----------|
| 400 | 参数错误 | 请求参数格式不正确或缺失必要参数 | 检查请求参数格式和必填字段 |
| 401 | 未授权 | 缺少认证信息或认证失败 | 提供有效的Authorization头 |
| 404 | 资源不存在 | 指定的流程定义、实例或任务不存在 | 确认资源ID的有效性 |
| 500 | 内部错误 | 服务器内部处理异常 | 检查日志，联系技术支持 |

### 错误响应示例

```json
{
  "code": 400,
  "msg": "参数错误：taskId不能为空",
  "data": null
}
```

```json
{
  "code": 500,
  "msg": "获取流程定义失败：数据库连接异常",
  "data": null
}
```

### 错误处理建议

1. **参数验证**: 在调用API前验证所有必需参数
2. **重试机制**: 对于临时性错误（如网络超时），实现指数退避重试
3. **日志记录**: 记录详细的错误日志以便问题排查
4. **降级处理**: 在服务不可用时提供备用处理方案

## 调用时序图

### 完整流程生命周期时序

```mermaid
sequenceDiagram
participant Designer as 流程设计器
participant API as WarmFlow API
participant Engine as 流程引擎
participant DB as 数据库
Note over Designer,DB : 流程设计阶段
Designer->>API : POST /warm-flow/save-json
API->>Engine : 保存流程定义
Engine->>DB : 存储流程数据
DB-->>Engine : 返回保存结果
Engine-->>API : 返回保存状态
API-->>Designer : 返回保存结果
Note over Designer,DB : 流程发布阶段
Designer->>API : GET /warm-flow/query-def/{id}
API->>Engine : 查询流程定义
Engine->>DB : 获取流程数据
DB-->>Engine : 返回流程定义
Engine-->>API : 返回流程数据
API-->>Designer : 返回流程定义
Note over Designer,DB : 流程实例启动
Designer->>API : POST /warm-flow/execute/handle
API->>Engine : 启动流程实例
Engine->>DB : 创建实例记录
DB-->>Engine : 返回实例ID
Engine-->>API : 返回实例信息
API-->>Designer : 返回启动结果
Note over Designer,DB : 任务处理阶段
Designer->>API : GET /warm-flow/execute/load/{taskId}
API->>Engine : 加载待办任务
Engine->>DB : 获取任务数据
DB-->>Engine : 返回任务详情
Engine-->>API : 返回任务数据
API-->>Designer : 返回任务表单
Designer->>API : POST /warm-flow/execute/handle
API->>Engine : 处理任务审批
Engine->>DB : 更新任务状态
Engine->>DB : 创建历史记录
DB-->>Engine : 返回更新结果
Engine-->>API : 返回流程状态
API-->>Designer : 返回处理结果
```

### 单个任务处理时序

```mermaid
sequenceDiagram
participant User as 用户
participant Frontend as 前端应用
participant API as WarmFlow API
participant Engine as 流程引擎
participant DB as 数据库
User->>Frontend : 查看待办任务
Frontend->>API : GET /warm-flow/execute/load/{taskId}
API->>Engine : 加载任务数据
Engine->>DB : 查询任务详情
DB-->>Engine : 返回任务数据
Engine-->>API : 返回任务表单
API-->>Frontend : 返回任务信息
Frontend-->>User : 显示任务表单
User->>Frontend : 填写表单并审批
Frontend->>API : POST /warm-flow/execute/handle
Note over Frontend,API : 包含formData、skipType、message
API->>Engine : 处理审批
Engine->>DB : 更新任务状态
Engine->>DB : 创建审批记录
Engine->>DB : 更新流程状态
DB-->>Engine : 返回更新结果
Engine-->>API : 返回流程实例
API-->>Frontend : 返回处理结果
Frontend-->>User : 显示处理结果
```

## 最佳实践

### 1. API调用规范

#### 认证和授权
```bash
# 设置认证头
curl -H "Authorization: Bearer your_token_here" \
     -H "Content-Type: application/json" \
     http://localhost:8080/warm-flow/query-def
```

#### 参数校验
```javascript
// 前端参数校验示例
const validateFormData = (formData) => {
  if (!formData.applicant) {
    throw new Error('申请人不能为空');
  }
  if (formData.days <= 0) {
    throw new Error('请假天数必须大于0');
  }
};
```

### 2. 错误处理策略

#### 重试机制
```javascript
const retryApiCall = async (apiCall, maxRetries = 3) => {
  let lastError;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await apiCall();
    } catch (error) {
      lastError = error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, i)));
      }
    }
  }
  
  throw lastError;
};
```

#### 错误分类处理
```javascript
const handleApiError = (error) => {
  if (error.response) {
    const { status, data } = error.response;
    
    switch (status) {
      case 400:
        console.error('参数错误:', data.msg);
        break;
      case 401:
        console.error('认证失败，请重新登录');
        break;
      case 404:
        console.error('资源不存在');
        break;
      default:
        console.error('服务器错误:', data.msg);
    }
  } else {
    console.error('网络错误:', error.message);
  }
};
```

### 3. 性能优化建议

#### 批量操作
```javascript
// 批量加载任务
const loadTasksBatch = async (taskIds) => {
  const promises = taskIds.map(id => 
    api.execute.load(id).catch(err => ({ taskId: id, error: err }))
  );
  return await Promise.all(promises);
};
```

#### 缓存策略
```javascript
const taskCache = new Map();

const getCachedTask = async (taskId) => {
  if (taskCache.has(taskId)) {
    return taskCache.get(taskId);
  }
  
  const task = await api.execute.load(taskId);
  taskCache.set(taskId, task);
  
  // 缓存有效期：5分钟
  setTimeout(() => taskCache.delete(taskId), 5 * 60 * 1000);
  
  return task;
};
```

### 4. 安全考虑

#### 输入验证
```javascript
const sanitizeFormData = (formData) => {
  const sanitized = { ...formData };
  
  // 移除潜在危险字符
  Object.keys(sanitized).forEach(key => {
    if (typeof sanitized[key] === 'string') {
      sanitized[key] = sanitized[key].replace(/[<>"']/g, '');
    }
  });
  
  return sanitized;
};
```

#### 权限检查
```javascript
const checkTaskPermission = (task, userId) => {
  // 检查用户是否有权限处理该任务
  const allowedUsers = task.allowedUsers || [];
  return allowedUsers.includes(userId);
};
```

### 5. 监控和日志

#### API调用监控
```javascript
const trackApiCall = (endpoint, params, response) => {
  const metrics = {
    endpoint,
    timestamp: new Date(),
    duration: performance.now() - startTime,
    status: response.status,
    userId: getCurrentUserId(),
    sessionId: getSessionId()
  };
  
  sendMetrics(metrics);
};
```

#### 日志记录
```javascript
const logApiCall = (level, message, context) => {
  const logEntry = {
    level,
    message,
    timestamp: new Date().toISOString(),
    context: {
      userId: context.userId,
      taskId: context.taskId,
      flowId: context.flowId,
      correlationId: context.correlationId
    }
  };
  
  console.log(JSON.stringify(logEntry));
};
```

通过遵循这些最佳实践，可以确保WarmFlow API的稳定、安全和高效使用，为业务系统提供可靠的流程管理能力。
# 前端UI配置API参考文档

<cite>
**本文档中引用的文件**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)
- [anony.js](file://warm-flow-ui/src/api/anony.js)
- [index.html](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/src/main/resources/warm-flow-ui/index.html)
</cite>

## 目录
1. [简介](#简介)
2. [API概述](#api概述)
3. [端点详情](#端点详情)
4. [响应结构](#响应结构)
5. [配置详解](#配置详解)
6. [前端集成](#前端集成)
7. [错误处理](#错误处理)
8. [最佳实践](#最佳实践)

## 简介

WarmFlow前端UI配置API是流程设计器的核心配置接口，专门用于向前端提供流程设计器运行所需的基础配置信息。该API采用RESTful设计，支持匿名访问，确保前端静态资源能够快速加载和初始化。

### 主要功能
- 提供前端流程设计器的基础配置信息
- 支持多token名称配置，便于与业务系统权限共享
- 返回标准化的配置数据结构
- 支持多种前端框架集成

## API概述

### 端点信息
- **端点路径**: `/warm-flow-ui/config`
- **HTTP方法**: GET
- **认证方式**: 匿名访问（无需认证）
- **内容类型**: `application/json`

### 请求参数
该API不接受任何请求参数，直接返回配置信息。

### 响应格式
所有响应均采用统一的API结果格式，包含状态码、消息和数据内容。

## 端点详情

### GET /warm-flow-ui/config

获取前端流程设计器的全局配置信息。

#### 请求示例
```bash
curl -X GET "https://your-domain.com/warm-flow-ui/config"
```

#### 响应示例
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "tokenNameList": ["Authorization", "X-Token", "Custom-Token"]
  }
}
```

**节来源**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L38-L42)

## 响应结构

### ApiResult<T> 统一响应格式

所有API响应都遵循统一的响应格式：

| 字段 | 类型 | 描述 |
|------|------|------|
| code | Integer | 响应状态码，200表示成功，500表示失败 |
| msg | String | 响应消息，描述操作结果 |
| data | T | 实际响应数据，泛型类型 |

### WarmFlowVo 配置数据结构

WarmFlowVo是前端UI配置的具体数据结构：

| 字段 | 类型 | 描述 | 必需 |
|------|------|------|------|
| tokenNameList | List<String> | 令牌名称列表，用于与业务系统权限共享 | 是 |

**节来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L42-L48)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java#L36-L38)

## 配置详解

### tokenName配置机制

WarmFlow支持灵活的令牌配置机制，允许前端与业务系统的多种认证方式进行集成。

#### 配置方式
1. **单令牌配置**: 在WarmFlow配置中设置单一令牌名称
2. **多令牌配置**: 支持多个令牌名称，用逗号分隔
3. **动态解析**: 后端自动解析配置并提供给前端

#### 默认配置
```yaml
warm-flow:
  tokenName: "Authorization"
```

#### 多令牌配置示例
```yaml
warm-flow:
  tokenName: "Authorization,X-Token,Custom-Token"
```

**节来源**
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L90-L92)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L56-L64)

## 前端集成

### Vue3集成示例

前端通过专门的API模块调用配置接口：

```javascript
// 前端API调用示例
import { config } from '@/api/anony'

// 获取配置
config().then(response => {
  const tokenNames = response.data.tokenNameList
  // 存储到本地或全局状态管理
  localStorage.setItem('tokenNameList', JSON.stringify(tokenNames))
})
```

### 前端初始化流程

```mermaid
sequenceDiagram
participant Browser as 浏览器
participant Frontend as 前端应用
participant Backend as WarmFlow后端
participant Designer as 流程设计器
Browser->>Frontend : 加载页面
Frontend->>Backend : GET /warm-flow-ui/config
Backend-->>Frontend : 返回配置信息
Frontend->>Frontend : 解析配置
Frontend->>Designer : 初始化设计器
Designer-->>Browser : 渲染流程设计器
```

**图表来源**
- [anony.js](file://warm-flow-ui/src/api/anony.js#L6-L11)
- [index.html](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/src/main/resources/warm-flow-ui/index.html#L211)

**节来源**
- [anony.js](file://warm-flow-ui/src/api/anony.js#L1-L14)

## 错误处理

### 常见错误情况

| 错误代码 | 错误消息 | 原因 | 解决方案 |
|----------|----------|------|----------|
| 500 | "未配置tokenName" | 后端未正确配置tokenName | 检查WarmFlow配置文件中的tokenName设置 |
| 404 | "接口不存在" | URL路径错误 | 确认URL路径为`/warm-flow-ui/config` |
| 500 | "操作失败" | 系统内部错误 | 检查后端服务状态 |

### 错误处理建议

1. **前端容错**: 对配置接口调用添加错误捕获
2. **降级处理**: 配置获取失败时使用默认配置
3. **日志记录**: 记录配置获取过程中的异常信息

## 最佳实践

### 1. 配置优化
- 合理设置tokenName数量，避免过多不必要的令牌
- 定期检查配置的有效性
- 考虑使用环境变量管理配置

### 2. 前端集成
- 在应用启动时优先获取配置
- 缓存配置信息，减少重复请求
- 实现配置的动态更新机制

### 3. 安全考虑
- 确保配置接口的安全性
- 避免在前端暴露敏感配置信息
- 实现适当的访问控制

### 4. 性能优化
- 利用浏览器缓存机制
- 实现配置的懒加载策略
- 优化网络请求频率

**节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L58-L60)

## 总结

WarmFlow前端UI配置API是一个简洁而强大的接口，为流程设计器提供了必要的基础配置信息。通过合理的配置管理和前端集成，可以实现高效的流程设计和管理工作流。

该API的设计充分考虑了易用性和扩展性，支持多种部署场景和集成需求，是WarmFlow流程管理系统的重要组成部分。
# 节点扩展属性API

<cite>
**本文档引用的文件**   
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java)
- [NodeExtService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/NodeExtService.java)
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java)
- [definition.js](file://warm-flow-ui/src/api/flow/definition.js)
- [warm-flow_1.7.4.sql](file://sql/mysql/v1-upgrade/warm-flow_1.7.4.sql)
</cite>

## 目录
1. [简介](#简介)
2. [API端点详情](#api端点详情)
3. [响应数据结构](#响应数据结构)
4. [NodeExt对象字段说明](#nodeext对象字段说明)
5. [JSON示例](#json示例)
6. [与DefJson的关系](#与defjson的关系)
7. [前端调用示例](#前端调用示例)

## 简介
节点扩展属性API为流程设计器提供了灵活性，允许为不同类型的节点（如开始、结束、审批等）动态配置额外的属性。该API通过`/warm-flow/node-ext`端点提供服务，返回所有节点类型可配置的扩展属性列表。这些属性可用于定义提示信息、办理人规则等自定义配置项，从而增强流程设计器的功能性和可定制性。

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L1-L30)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L1-L356)

## API端点详情
`/warm-flow/node-ext`端点使用HTTP GET方法获取流程设计器中所有节点的扩展属性配置。

| 属性 | 说明 |
|------|------|
| **HTTP方法** | GET |
| **端点路径** | `/warm-flow/node-ext` |
| **功能描述** | 获取流程设计器中所有节点类型的扩展属性配置 |
| **认证要求** | 需要有效的身份验证令牌 |
| **返回类型** | `ApiResult<List<NodeExt>>` |

```mermaid
sequenceDiagram
participant 前端 as 前端应用
participant 控制器 as WarmFlowController
participant 服务层 as WarmFlowService
participant 业务实现 as NodeExtService
前端->>控制器 : GET /warm-flow/node-ext
控制器->>服务层 : 调用WarmFlowService.nodeExt()
服务层->>业务实现 : 通过FrameInvoker获取NodeExtService实例
业务实现-->>服务层 : 返回List<NodeExt>
服务层-->>控制器 : 包装为ApiResult返回
控制器-->>前端 : 返回ApiResult<List<NodeExt>>
```

**Diagram sources **
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L199-L207)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L336-L353)

**Section sources**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L199-L207)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L336-L353)

## 响应数据结构
API的响应体是一个包装在`ApiResult`中的`List<NodeExt>`对象列表。`ApiResult`是标准的响应封装类，包含状态码、消息和数据体。

```mermaid
classDiagram
class ApiResult~T~ {
+int code
+String msg
+T data
+static ApiResult~T~ ok(T data)
+static ApiResult~T~ fail(String msg)
}
class NodeExt {
+String code
+String name
+String desc
+int type
+List<ChildNode> childs
}
class ChildNode {
+String code
+String desc
+String label
+int type
+boolean must
+boolean multiple
+List<DictItem> dict
}
class DictItem {
+String label
+String value
+boolean selected
}
NodeExt "1" *-- "0..*" ChildNode : 包含
ChildNode "1" *-- "0..*" DictItem : 包含
ApiResult "1" --> "0..*" NodeExt : 数据
```

**Diagram sources **
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java#L32-L75)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L340-L349)

## NodeExt对象字段说明
`NodeExt`对象定义了每个节点类型可配置的额外属性，其字段说明如下：

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| **code** | String | 是 | 节点类型编码，如"start"、"end"、"approval"等 |
| **name** | String | 是 | 节点类型名称，用于界面显示 |
| **desc** | String | 否 | 节点类型的描述信息 |
| **type** | int | 是 | 节点类型标识，用于区分不同类型的节点 |
| **childs** | List<ChildNode> | 是 | 该节点类型支持的可配置子属性列表 |

### ChildNode字段说明
`ChildNode`类定义了具体的可配置属性项：

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| **code** | String | 是 | 属性编码，用于数据存储和识别 |
| **desc** | String | 否 | 属性描述 |
| **label** | String | 是 | 属性标签，用于界面显示 |
| **type** | int | 是 | 属性类型（1:文本, 2:数字, 3:下拉框, 4:复选框等） |
| **must** | boolean | 是 | 是否为必填项 |
| **multiple** | boolean | 是 | 是否支持多选（仅适用于下拉框、复选框等） |
| **dict** | List<DictItem> | 否 | 下拉选项数据（当type为下拉框或复选框时） |

### DictItem字段说明
`DictItem`类定义了下拉选项的数据结构：

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| **label** | String | 是 | 选项显示文本 |
| **value** | String | 是 | 选项值 |
| **selected** | boolean | 否 | 是否默认选中 |

**Section sources**
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java#L32-L75)

## JSON示例
以下是`/warm-flow/node-ext`端点的典型响应示例：

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": [
    {
      "code": "start",
      "name": "开始节点",
      "desc": "流程的起始节点",
      "type": 0,
      "childs": [
        {
          "code": "prompt",
          "desc": "开始节点提示信息",
          "label": "提示信息",
          "type": 1,
          "must": false,
          "multiple": false
        },
        {
          "code": "handlerRule",
          "desc": "开始节点办理人规则",
          "label": "办理人规则",
          "type": 3,
          "must": true,
          "multiple": false,
          "dict": [
            {
              "label": "发起人自己",
              "value": "self",
              "selected": true
            },
            {
              "label": "指定人员",
              "value": "specified",
              "selected": false
            },
            {
              "label": "发起人部门主管",
              "value": "deptLeader",
              "selected": false
            }
          ]
        }
      ]
    },
    {
      "code": "approval",
      "name": "审批节点",
      "desc": "需要人工审批的节点",
      "type": 1,
      "childs": [
        {
          "code": "prompt",
          "desc": "审批节点提示信息",
          "label": "审批提示",
          "type": 1,
          "must": false,
          "multiple": false
        },
        {
          "code": "handlerType",
          "desc": "审批人选择类型",
          "label": "审批人类型",
          "type": 3,
          "must": true,
          "multiple": false,
          "dict": [
            {
              "label": "单人审批",
              "value": "single",
              "selected": true
            },
            {
              "label": "多人会签",
              "value": "joint",
              "selected": false
            },
            {
              "label": "多人或签",
              "value": "orSign",
              "selected": false
            }
          ]
        },
        {
          "code": "notifyUsers",
          "desc": "审批时通知人员",
          "label": "通知人员",
          "type": 3,
          "must": false,
          "multiple": true,
          "dict": [
            {
              "label": "发起人",
              "value": "initiator",
              "selected": false
            },
            {
              "label": "上一审批人",
              "value": "previousApprover",
              "selected": false
            },
            {
              "label": "相关干系人",
              "value": "stakeholders",
              "selected": false
            }
          ]
        }
      ]
    }
  ]
}
```

**Section sources**
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java#L32-L75)

## 与DefJson的关系
`NodeExt`对象与`DefJson`数据结构有着密切的关系，共同构成了流程设计器的配置体系。

```mermaid
flowchart TD
A[NodeExt API] --> B[获取节点扩展配置]
B --> C[流程设计器界面]
C --> D[用户配置节点属性]
D --> E[生成DefJson]
E --> F[Node节点的ext字段]
F --> G[存储为JSON字符串]
G --> H[数据库flow_node表]
I[NodeExtService] --> J[业务系统实现]
J --> K[自定义节点配置]
K --> A
L[DefJson] --> M[nodeList]
M --> N[NodeJson]
N --> O[ext字段]
O --> P[存储NodeExt配置值]
style A fill:#f9f,stroke:#333
style I fill:#f9f,stroke:#333
style L fill:#bbf,stroke:#333
```

**Diagram sources **
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java#L105-L114)
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java#L32-L75)
- [warm-flow_1.7.4.sql](file://sql/mysql/v1-upgrade/warm-flow_1.7.4.sql#L1)

**Section sources**
- [DefJson.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/DefJson.java#L105-L114)
- [warm-flow_1.7.4.sql](file://sql/mysql/v1-upgrade/warm-flow_1.7.4.sql#L1)

`NodeExt`对象定义了**元数据配置**，即"可以配置什么"，而`DefJson`中的`Node`对象的`ext`字段存储了**实际配置值**，即"已经配置了什么"。具体关系如下：

1. **元数据定义**: `NodeExt` API提供所有节点类型可配置的属性定义，包括属性名称、类型、选项等元数据信息。

2. **数据存储**: 在`DefJson`结构中，每个`NodeJson`对象都有一个`ext`字段（类型为String），用于存储该节点实例的具体扩展属性配置值。

3. **数据库映射**: 数据库`flow_node`表中的`ext`字段（TEXT类型）对应`Node`实体的`ext`属性，用于持久化存储节点的扩展配置。

4. **配置流程**: 
   - 流程设计器首先调用`/warm-flow/node-ext`获取所有可配置项
   - 用户根据这些配置项为特定节点设置属性值
   - 设计器将配置值序列化为JSON字符串，存储在`DefJson`的`NodeJson.ext`字段中
   - 保存时，这些数据被持久化到数据库的`flow_node.ext`字段

这种设计实现了配置定义与配置值的分离，使得系统既灵活又易于扩展。

## 前端调用示例
前端应用可以通过以下方式调用节点扩展属性API：

```javascript
// 在definition.js中定义的API调用
export function nodeExt() {
  return request({
    url: urlPrefix + 'warm-flow/node-ext',
    method: 'get'
  })
}

// 使用示例
async function loadNodeExtConfig() {
  try {
    const response = await nodeExt();
    if (response.code === 200) {
      const nodeExtConfigs = response.data;
      // 处理节点扩展配置
      nodeExtConfigs.forEach(nodeConfig => {
        console.log(`节点类型: ${nodeConfig.name}`);
        console.log(`可配置项:`, nodeConfig.childs);
      });
      return nodeExtConfigs;
    } else {
      console.error('获取节点扩展属性失败:', response.msg);
      return [];
    }
  } catch (error) {
    console.error('请求异常:', error);
    return [];
  }
}
```

**Section sources**
- [definition.js](file://warm-flow-ui/src/api/flow/definition.js#L81-L86)
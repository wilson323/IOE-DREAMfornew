# 表单相关API参考文档

<cite>
**本文档中引用的文件**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java)
- [Form.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Form.java)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)
- [form.js](file://warm-flow-ui/src/api/form/form.js)
- [design.vue](file://warm-flow-ui/src/components/form/design.vue)
</cite>

## 目录
1. [简介](#简介)
2. [API概览](#api概览)
3. [表单内容获取API](#表单内容获取api)
4. [表单内容保存API](#表单内容保存api)
5. [已发布表单列表API](#已发布表单列表api)
6. [数据结构说明](#数据结构说明)
7. [错误处理](#错误处理)
8. [使用示例](#使用示例)
9. [最佳实践](#最佳实践)

## 简介

本文档详细介绍了WarmFlow工作流引擎中与表单设计和表单内容管理相关的RESTful API。这些API主要服务于前端表单设计器，支持表单内容的读取、保存以及已发布表单列表的查询功能。

## API概览

WarmFlow提供了三个核心的表单相关API端点：

| 端点 | HTTP方法 | 描述 |
|------|----------|------|
| `/warm-flow/form-content/{id}` | GET | 获取指定ID的表单内容 |
| `/warm-flow/form-content` | POST | 保存表单内容 |
| `/warm-flow/published-form` | GET | 获取已发布表单列表 |

## 表单内容获取API

### 接口描述

获取指定ID的表单内容，主要用于加载表单设计器中的现有表单配置。

### 请求信息

| 属性 | 值 |
|------|-----|
| URL路径 | `/warm-flow/form-content/{id}` |
| HTTP方法 | GET |
| 内容类型 | 无 |
| 认证要求 | 是 |

### 路径参数

| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | Long | 是 | 表单定义的唯一标识符 |

### 响应结构

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": "{\"rule\": {...}, \"option\": {...}}"
}
```

### 响应字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| code | int | 响应状态码，200表示成功 |
| msg | String | 响应消息 |
| data | String | 表单内容的JSON字符串，包含rule和option两个部分 |

### 错误响应

```json
{
  "code": 500,
  "msg": "获取表单内容字符串失败",
  "data": null
}
```

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L139-L142)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L265-L271)

## 表单内容保存API

### 接口描述

保存表单内容到数据库，主要用于存储表单设计器中编辑的表单配置。

### 请求信息

| 属性 | 值 |
|------|-----|
| URL路径 | `/warm-flow/form-content` |
| HTTP方法 | POST |
| 内容类型 | application/json |
| 认证要求 | 是 |

### 请求体

```json
{
  "id": 123,
  "formContent": "{\"rule\": {...}, \"option\": {...}}",
  "form": {
    "id": 123,
    "formCode": "test_form",
    "formName": "测试表单",
    "version": "1.0",
    "isPublish": 0,
    "formType": 0,
    "formContent": "{\"rule\": {...}, \"option\": {...}}",
    "formPath": null,
    "ext": null
  },
  "data": {}
}
```

### 请求体字段说明

| 字段名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | Long | 是 | 表单定义的唯一标识符 |
| formContent | String | 是 | 表单内容的JSON字符串 |
| form | Form | 否 | 表单实体对象 |
| data | Object | 否 | 表单数据对象 |

### 响应结构

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": null
}
```

### 响应字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| code | int | 响应状态码，200表示成功 |
| msg | String | 响应消息 |
| data | null | 无返回数据 |

### 错误响应

```json
{
  "code": 500,
  "msg": "保存表单内容失败",
  "data": null
}
```

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L151-L154)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L280-L282)

## 已发布表单列表API

### 接口描述

获取所有已发布的表单列表，主要用于为流程设计器提供可绑定的表单选项。

### 请求信息

| 属性 | 值 |
|------|-----|
| URL路径 | `/warm-flow/published-form` |
| HTTP方法 | GET |
| 内容类型 | 无 |
| 认证要求 | 是 |

### 响应结构

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": [
    {
      "id": 123,
      "formCode": "test_form",
      "formName": "测试表单",
      "version": "1.0",
      "isPublish": 1,
      "formType": 0,
      "formContent": "{\"rule\": {...}, \"option\": {...}}",
      "formPath": null,
      "ext": null,
      "createTime": "2024-01-01 10:00:00",
      "updateTime": "2024-01-01 10:00:00",
      "createBy": "admin",
      "updateBy": "admin",
      "tenantId": "default",
      "delFlag": "0"
    }
  ]
}
```

### 响应字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| code | int | 响应状态码，200表示成功 |
| msg | String | 响应消息 |
| data | List<Form> | 已发布表单列表 |

### Form实体字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| id | Long | 表单ID |
| formCode | String | 表单编码 |
| formName | String | 表单名称 |
| version | String | 版本号 |
| isPublish | Integer | 发布状态（0未发布，1已发布，9失效） |
| formType | Integer | 表单类型（0内置表单，1外挂表单） |
| formContent | String | 表单内容 |
| formPath | String | 表单路径 |
| ext | String | 扩展字段 |

### 错误响应

```json
{
  "code": 500,
  "msg": "已发布表单列表异常",
  "data": null
}
```

**节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L127-L131)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L249-L256)

## 数据结构说明

### FlowDto结构

FlowDto是表单内容操作的核心数据传输对象，其中`formContent`字段承载着表单的设计配置信息。

```mermaid
classDiagram
class FlowDto {
+Long id
+String formContent
+Form form
+Object data
}
class Form {
+Long id
+String formCode
+String formName
+String version
+Integer isPublish
+Integer formType
+String formContent
+String formPath
+String ext
+Date createTime
+Date updateTime
+String createBy
+String updateBy
+String tenantId
+String delFlag
}
FlowDto --> Form : "contains"
```

**图表来源**
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java#L32-L53)
- [Form.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Form.java#L26-L111)

### formContent字段交互

`formContent`字段在三个API中的交互方式：

1. **getFormContent接口**：
   - 输入：表单ID
   - 输出：表单内容的JSON字符串
   - 用途：加载现有表单配置到设计器

2. **saveFormContent接口**：
   - 输入：包含formContent字段的FlowDto对象
   - 输出：保存结果
   - 用途：将设计器中的表单配置保存到数据库

3. **publishedForm接口**：
   - 输出：包含formContent字段的Form对象列表
   - 用途：提供可绑定的表单选项

**节来源**
- [FlowDto.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/FlowDto.java#L38-L41)
- [Form.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Form.java#L100-L102)

## 错误处理

所有API都遵循统一的错误处理机制，使用ApiResult作为响应包装器。

### 错误响应格式

```json
{
  "code": 500,
  "msg": "错误消息",
  "data": null
}
```

### 常见错误码

| 错误码 | 描述 | 可能原因 |
|--------|------|----------|
| 500 | 操作失败 | 数据库异常、参数验证失败等 |
| 401 | 未授权 | 缺少认证信息或认证过期 |
| 403 | 权限不足 | 用户没有访问权限 |
| 404 | 资源不存在 | 请求的资源不存在 |

### 异常处理策略

1. **参数验证异常**：返回400状态码和具体错误信息
2. **业务逻辑异常**：返回500状态码和业务异常信息
3. **系统异常**：返回500状态码和系统异常信息

**节来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L36-L41)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L267-L271)

## 使用示例

### 前端调用示例

以下是前端JavaScript调用这些API的示例：

#### 获取表单内容

```javascript
// 获取表单内容
function getFormContent(id) {
  return request({
    url: '/warm-flow/form-content/' + id,
    method: 'get'
  });
}

// 使用示例
getFormContent(123).then(response => {
  if (response.code === 200) {
    const formContent = response.data;
    // 将表单内容解析并加载到设计器
    const parsedContent = JSON.parse(formContent);
    designer.setRule(parsedContent.rule);
    designer.setOption(parsedContent.option);
  }
});
```

#### 保存表单内容

```javascript
// 保存表单内容
function saveFormContent(data) {
  return request({
    url: '/warm-flow/form-content',
    method: 'post',
    data: data
  });
}

// 使用示例
const formData = {
  id: 123,
  formContent: JSON.stringify({
    rule: formCreate.parseJson(ruleJson),
    option: formCreate.parseJson(optionsJson)
  })
};

saveFormContent(formData).then(response => {
  if (response.code === 200) {
    message.success('保存成功');
    // 关闭当前页面
    window.parent.postMessage({ method: 'close' }, '*');
  }
});
```

#### 获取已发布表单列表

```javascript
// 获取已发布表单列表
function getPublishedForms() {
  return request({
    url: '/warm-flow/published-form',
    method: 'get'
  });
}

// 使用示例
getPublishedForms().then(response => {
  if (response.code === 200) {
    const forms = response.data;
    // 将表单列表用于流程绑定
    formSelect.options = forms.map(form => ({
      label: form.formName,
      value: form.id
    }));
  }
});
```

**节来源**
- [form.js](file://warm-flow-ui/src/api/form/form.js#L6-L45)
- [design.vue](file://warm-flow-ui/src/components/form/design.vue#L25-L44)

## 最佳实践

### 1. 表单内容序列化

- 使用JSON.stringify()序列化表单内容
- 确保表单内容的完整性验证
- 处理特殊字符的转义

### 2. 错误处理

- 检查API响应的code字段
- 提供友好的错误提示信息
- 实现重试机制处理临时性错误

### 3. 性能优化

- 对频繁访问的表单内容进行缓存
- 使用分页处理大量表单数据
- 实现增量更新减少网络传输

### 4. 安全考虑

- 验证用户权限再执行操作
- 对敏感数据进行加密存储
- 实现操作日志记录

### 5. 开发建议

- 使用TypeScript定义接口类型
- 实现单元测试覆盖核心功能
- 添加详细的API文档注释

这些API为WarmFlow工作流引擎提供了完整的表单管理能力，支持从表单设计到流程绑定的完整生命周期管理。通过合理使用这些接口，可以构建功能完善的业务流程管理系统。
# 节点跳转表 (flow_skip)

<cite>
**本文档引用的文件**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L362-L506)
- [Skip.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Skip.java)
- [FlowSkipMapper.xml](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/resources/warm/flow/FlowSkipMapper.xml)
- [flow_skip表结构定义](file://sql/sqlserver/sqlserver.sql#L366-L386)
</cite>

## 目录
1. [简介](#简介)
2. [字段说明](#字段说明)
3. [数据模型关系](#数据模型关系)
4. [坐标字段详解](#坐标字段详解)
5. [条件跳转示例](#条件跳转示例)

## 简介
`flow_skip` 表是流程引擎中的核心数据表之一，用于定义流程中节点之间的跳转规则。该表存储了从一个节点到另一个节点的流转路径，包括跳转类型（如通过或退回）和跳转条件（基于业务规则的表达式）。通过该表，系统能够构建完整的流程图并实现动态的流程流转控制。

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L366-L506)

## 字段说明
`flow_skip` 表包含以下关键字段：

| 字段名 | 类型 | 是否必填 | 描述 |
|--------|------|----------|------|
| id | bigint | 是 | 主键，唯一标识每条跳转规则 |
| definition_id | bigint | 是 | 流程定义ID，关联 `flow_definition` 表 |
| now_node_code | nvarchar(100) | 是 | 当前节点编码，关联 `flow_node` 表的 `node_code` |
| next_node_code | nvarchar(100) | 是 | 下一节点编码，指向目标节点 |
| skip_type | nvarchar(40) | 否 | 跳转类型，如 PASS（通过）、REJECT（退回） |
| skip_condition | nvarchar(200) | 否 | 跳转条件表达式，用于条件分支判断 |
| coordinate | nvarchar(100) | 否 | 跳转线在流程设计器中的坐标位置 |
| create_time | datetime2(7) | 否 | 创建时间 |
| update_time | datetime2(7) | 否 | 更新时间 |
| del_flag | nchar(1) | 否 | 删除标志（'0' 未删除，'1' 已删除） |
| tenant_id | nvarchar(40) | 否 | 租户ID，支持多租户架构 |

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L366-L458)
- [Skip.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Skip.java)

## 数据模型关系
`flow_skip` 表通过外键关系与流程定义和节点表建立关联，形成完整的流程拓扑结构。

```mermaid
erDiagram
flow_definition ||--o{ flow_skip : "包含"
flow_node ||--o{ flow_skip : "作为当前节点"
flow_node ||--o{ flow_skip : "作为下一节点"
flow_definition {
bigint id PK
varchar flow_code
varchar flow_name
int model_value
}
flow_skip {
bigint id PK
bigint definition_id FK
varchar now_node_code FK
varchar next_node_code FK
varchar skip_type
varchar skip_condition
varchar coordinate
}
flow_node {
bigint id PK
bigint definition_id FK
varchar node_code UK
varchar node_name
int node_type
varchar coordinate
}
flow_definition ||--o{ flow_node : "定义"
```

**Diagram sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L366-L506)
- [Skip.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Skip.java)

## 坐标字段详解
`coordinate` 字段用于存储跳转线在流程设计器中的可视化位置信息。该字段通常包含起点和终点的坐标数据，格式为 `"x1,y1;x2,y2"`，其中：
- `x1,y1` 表示当前节点连接点的坐标
- `x2,y2` 表示下一节点连接点的坐标

此信息在流程设计界面中用于渲染连接线，确保流程图的布局美观和可读性。当用户在图形化设计器中拖动节点时，系统会自动更新相关跳转线的坐标值。

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L453-L458)
- [FlowSkipMapper.xml](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/resources/warm/flow/FlowSkipMapper.xml#L223-L243)

## 条件跳转示例
以下是一个基于表达式的条件跳转SQL示例，展示如何根据业务数据决定流程走向：

```sql
SELECT next_node_code 
FROM flow_skip 
WHERE definition_id = 1001 
  AND now_node_code = 'APPROVE_NODE_1'
  AND (
    skip_condition IS NULL -- 无条件跳转（默认路径）
    OR 
    (skip_condition = 'amount>5000' AND ${businessData.amount} > 5000) -- 高额审批路径
    OR 
    (skip_condition = 'amount<=5000' AND ${businessData.amount} <= 5000) -- 普通审批路径
  )
```

在实际应用中，`skip_condition` 字段存储的条件表达式由流程设计器生成，系统在运行时通过表达式引擎（如SpEL）进行求值，从而实现动态的流程分支控制。

**Section sources**
- [Skip.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Skip.java)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L446-L451)
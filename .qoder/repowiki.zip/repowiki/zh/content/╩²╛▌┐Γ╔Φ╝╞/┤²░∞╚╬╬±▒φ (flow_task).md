# 待办任务表 (flow_task)

<cite>
**本文档引用的文件**
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java)
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java)
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java)
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java)
- [FlowStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FlowStatus.java)
- [TaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/TaskServiceImpl.java)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql)
- [warm-flow_1.8.2.sql](file://sql/mysql/v1-upgrade/warm-flow_1.8.2.sql)
</cite>

## 目录
1. [简介](#简介)
2. [表结构概述](#表结构概述)
3. [核心字段详解](#核心字段详解)
4. [数据模型关系](#数据模型关系)
5. [任务状态管理](#任务状态管理)
6. [任务处理机制](#任务处理机制)
7. [数据归档机制](#数据归档机制)
8. [性能优化考虑](#性能优化考虑)
9. [最佳实践建议](#最佳实践建议)
10. [总结](#总结)

## 简介

`flow_task`表是Warm-Flow工作流引擎的核心数据表之一，专门用于存储当前处于待处理状态的任务信息。该表是用户待办事项的主要来源，反映了流程的当前执行点，为用户提供实时的任务提醒和处理入口。

该表采用标准的关系型数据库设计，支持多租户架构，具备完善的审计功能，能够准确跟踪每个任务的生命周期状态。通过与`flow_instance`、`flow_user`等相关表的关联，形成了完整的工作流任务管理体系。

## 表结构概述

`flow_task`表采用标准的主键设计，包含13个核心字段，支持完整的任务信息存储和状态跟踪。

```mermaid
erDiagram
FLOW_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
varchar node_code
varchar node_name
tinyint node_type
varchar flow_status
char form_custom
varchar form_path
datetime create_time
varchar create_by
datetime update_time
varchar update_by
char del_flag
varchar tenant_id
}
FLOW_INSTANCE {
bigint id PK
bigint definition_id FK
varchar business_id
tinyint node_type
varchar node_code
varchar node_name
varchar flow_status
text variable
datetime create_time
varchar create_by
datetime update_time
varchar update_by
char del_flag
varchar tenant_id
}
FLOW_USER {
bigint id PK
char type
varchar processed_by
bigint associated FK
datetime create_time
varchar create_by
datetime update_time
varchar update_by
char del_flag
varchar tenant_id
}
FLOW_HIS_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
bigint task_id FK
varchar node_code
varchar node_name
tinyint node_type
varchar target_node_code
varchar approver
tinyint cooperate_type
varchar collaborator
varchar skip_type
varchar flow_status
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_TASK ||--|| FLOW_INSTANCE : "instance_id"
FLOW_TASK ||--o{ FLOW_USER : "associated"
FLOW_TASK ||--o| FLOW_HIS_TASK : "task_id"
```

**图表来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L96-L114)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L667-L717)

**节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L96-L114)
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java#L31-L131)

## 核心字段详解

### 主键字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `id` | bigint | - | 否 | 主键，唯一标识每个待办任务 |

### 关联字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `definition_id` | bigint | - | 否 | 关联的流程定义ID，指向`flow_definition`表 |
| `instance_id` | bigint | - | 否 | 关联的流程实例ID，指向`flow_instance`表 |

### 节点信息字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `node_code` | varchar | 100 | 否 | 任务所在节点的编码，用于定位具体处理环节 |
| `node_name` | varchar | 100 | 是 | 节点名称，提供更友好的显示信息 |
| `node_type` | tinyint | - | 否 | 节点类型（0开始节点 1中间节点 2结束节点 3互斥网关 4并行网关） |

### 状态控制字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `flow_status` | varchar | 20 | 否 | 流程状态，参考`FlowStatus`枚举值 |

### 表单配置字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `form_custom` | char | 1 | 是 | 审批表单是否自定义（Y=是 N=否） |
| `form_path` | varchar | 100 | 是 | 审批表单路径，关联特定的审批界面 |

### 审计字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 描述 |
|--------|------|------|--------------|------|
| `create_time` | datetime | - | 是 | 创建时间 |
| `create_by` | varchar | 64 | 是 | 创建人 |
| `update_time` | datetime | - | 是 | 更新时间 |
| `update_by` | varchar | 64 | 是 | 更新人 |
| `del_flag` | char | 1 | 是 | 删除标志（0正常 1删除） |
| `tenant_id` | varchar | 40 | 是 | 租户ID，支持多租户隔离 |

**节来源**
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java#L31-L131)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L96-L114)

## 数据模型关系

### 与流程实例的关系

`flow_task`表与`flow_instance`表建立了一对多的关系，一个流程实例可能包含多个待办任务：

```mermaid
sequenceDiagram
participant PI as "流程实例 (flow_instance)"
participant PT as "待办任务 (flow_task)"
participant PU as "流程用户 (flow_user)"
PI->>PT : 创建新任务
PT->>PI : 关联instance_id
PT->>PU : 分配处理人
PU->>PT : 关联associated
PT->>PT : 记录任务状态
Note over PI,PU : 一个实例可有多个待办任务
```

**图表来源**
- [TaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/TaskServiceImpl.java#L96-L98)
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java#L78-L79)

### 处理人关联机制

`flow_task`表通过`flow_user`表间接关联处理人信息：

```mermaid
flowchart TD
A["flow_task.id"] --> B["flow_user.associated"]
B --> C["flow_user.processed_by"]
C --> D["实际处理人"]
E["任务创建"] --> F["分配处理人"]
F --> G["插入flow_user记录"]
G --> H["关联任务ID"]
I["任务查询"] --> J["获取处理人列表"]
J --> K["解析权限标识"]
K --> L["确定可处理人员"]
```

**图表来源**
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java#L89-L92)
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java#L80-L83)

**节来源**
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java#L75-L85)
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java#L89-L92)

## 任务状态管理

### 流程状态枚举

`flow_task`表的`flow_status`字段使用标准化的状态码，与`FlowStatus`枚举保持一致：

| 状态码 | 状态值 | 描述 |
|--------|--------|------|
| 0 | 待提交 | 任务已创建但尚未提交审批 |
| 1 | 审批中 | 任务正在等待处理 |
| 2 | 审批通过 | 任务已通过审批 |
| 4 | 终止 | 任务被终止 |
| 5 | 作废 | 任务被作废 |
| 6 | 撤销 | 任务被撤销 |
| 8 | 已完成 | 任务已完成 |
| 9 | 已退回 | 任务被退回 |
| 10 | 失效 | 任务已失效 |
| 11 | 拿回 | 任务被拿回 |

### 状态转换流程

```mermaid
stateDiagram-v2
[*] --> 待提交 : 创建任务
待提交 --> 审批中 : 提交审批
审批中 --> 审批通过 : 通过审批
审批中 --> 已退回 : 退回任务
审批中 --> 终止 : 终止流程
审批中 --> 作废 : 作废任务
审批中 --> 撤销 : 撤销操作
审批通过 --> 已完成 : 完成流程
已退回 --> 审批中 : 重新提交
终止 --> [*] : 归档处理
作废 --> [*] : 归档处理
撤销 --> [*] : 归档处理
已完成 --> [*] : 归档处理
```

**图表来源**
- [FlowStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FlowStatus.java#L34-L58)

**节来源**
- [FlowStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FlowStatus.java#L34-L58)
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java#L106-L110)

## 任务处理机制

### 处理人识别机制

`flow_task`表通过`flow_user`表实现灵活的处理人管理：

```mermaid
classDiagram
class FlowTask {
+Long id
+String nodeCode
+String flowStatus
+User[] userList
+getHandlerId() String
+hasPermission(userId) boolean
}
class FlowUser {
+Long id
+String type
+String processedBy
+Long associated
+getUserType() String
+getUserId() String
}
class User {
+String userId
+String userName
+String department
}
FlowTask --> FlowUser : "关联"
FlowUser --> User : "映射"
```

**图表来源**
- [FlowTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowTask.java#L118-L120)
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java#L70-L83)

### 协作处理模式

系统支持多种协作处理模式：

| 协作类型 | 数值 | 描述 |
|----------|------|------|
| 审批 | 1 | 正常审批流程 |
| 转办 | 2 | 将任务转交给其他人处理 |
| 委派 | 3 | 委托他人代理处理 |
| 会签 | 4 | 多人同时参与审批 |
| 票签 | 5 | 投票式审批 |
| 加签 | 6 | 添加新的审批人 |
| 减签 | 7 | 移除审批人 |

**节来源**
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java#L116-L126)
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java#L70-L83)

## 数据归档机制

### 任务完成后的归档流程

当任务完成时，系统会自动将任务信息从`flow_task`表归档到`flow_his_task`表：

```mermaid
sequenceDiagram
participant T as "flow_task"
participant S as "TaskService"
participant H as "flow_his_task"
participant I as "flow_instance"
T->>S : 任务完成通知
S->>T : 查询任务详情
S->>H : 创建历史记录
H->>H : 复制任务信息
H->>H : 记录处理结果
S->>T : 标记任务完成
T->>I : 更新实例状态
Note over T,H : 任务完成后自动归档
```

**图表来源**
- [TaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/TaskServiceImpl.java#L96-L98)

### 归档数据结构对比

| 字段 | flow_task | flow_his_task | 说明 |
|------|-----------|---------------|------|
| 任务标识 | id | task_id | 唯一标识任务 |
| 流程定义 | definition_id | definition_id | 关联流程定义 |
| 流程实例 | instance_id | instance_id | 关联流程实例 |
| 节点信息 | node_code/name/type | node_code/name/type | 任务开始时的节点信息 |
| 处理结果 | flow_status | flow_status | 最终处理状态 |
| 处理人 | user_list | approver | 实际处理人员 |
| 处理时间 | create_time/update_time | create_time/update_time | 开始和结束时间 |
| 处理意见 | - | message | 审批意见 |

**节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L116-L142)
- [TaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/TaskServiceImpl.java#L96-L98)

## 性能优化考虑

### 索引策略

为了确保查询性能，建议在以下字段上建立索引：

| 索引类型 | 字段组合 | 用途 |
|----------|----------|------|
| 主键索引 | id | 唯一标识查询 |
| 外键索引 | instance_id | 实例关联查询 |
| 复合索引 | node_code, flow_status | 节点状态过滤 |
| 复合索引 | create_time, del_flag | 时间范围查询 |
| 复合索引 | tenant_id, instance_id | 租户隔离查询 |

### 查询优化建议

1. **分页查询**：对于大量待办任务的场景，建议使用分页查询
2. **状态过滤**：优先按`flow_status`字段进行过滤
3. **时间范围**：限制查询的时间范围，避免全表扫描
4. **租户隔离**：始终包含`tenant_id`条件进行查询

### 数据清理策略

建议定期清理历史数据：
- 清理超过3个月的历史任务记录
- 归档重要但不再活跃的任务
- 保留关键业务数据的长期存档

## 最佳实践建议

### 设计原则

1. **单一职责**：每个任务只代表一个具体的处理环节
2. **状态一致性**：确保任务状态与流程实例状态同步
3. **权限控制**：严格控制任务处理权限
4. **审计追踪**：完整记录所有操作日志

### 使用建议

1. **及时处理**：建议设置任务过期机制，避免任务积压
2. **状态监控**：实时监控任务状态变化
3. **异常处理**：建立任务异常处理机制
4. **性能监控**：定期检查查询性能和数据量增长

### 开发指导

1. **事务管理**：任务创建和更新必须在事务中进行
2. **并发控制**：处理并发任务时注意数据一致性
3. **缓存策略**：合理使用缓存提高查询效率
4. **错误处理**：完善异常处理和恢复机制

## 总结

`flow_task`表作为Warm-Flow工作流引擎的核心组件，承担着任务管理和状态跟踪的重要职责。通过精心设计的数据结构和完善的关联关系，该表能够准确反映流程的当前执行状态，为用户提供及时有效的待办事项提醒。

主要特性包括：
- **完整性**：涵盖任务的所有必要信息
- **灵活性**：支持多种处理模式和协作方式
- **可扩展性**：适应不同业务场景的需求
- **可靠性**：提供完整的审计和归档机制
- **性能**：通过合理的索引和查询策略保证高效运行

通过深入理解`flow_task`表的设计原理和使用方法，开发者可以更好地构建稳定可靠的工作流应用，为用户提供优秀的业务处理体验。
# 历史任务表 (flow_his_task) 数据模型文档

<cite>
**本文档引用的文件**
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java)
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java)
- [FlowHisTaskMapper.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/mapper/FlowHisTaskMapper.java)
- [CooperateType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/CooperateType.java)
- [SkipType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/SkipType.java)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java)
</cite>

## 目录
1. [概述](#概述)
2. [表结构设计](#表结构设计)
3. [核心字段详解](#核心字段详解)
4. [协作类型系统](#协作类型系统)
5. [流转类型系统](#流转类型系统)
6. [与其他表的关系](#与其他表的关系)
7. [数据模型架构](#数据模型架构)
8. [使用场景分析](#使用场景分析)
9. [性能优化建议](#性能优化建议)
10. [最佳实践](#最佳实践)

## 概述

`flow_his_task`表是Warm-Flow工作流引擎中的核心历史记录表，专门用于记录所有已完成或已结束的任务历史信息。该表作为流程执行过程的完整日志，为审计追踪、流程监控和问题排查提供了重要的数据支撑。

### 主要功能特性

- **完整性记录**：记录每个任务的完整生命周期信息
- **审计支持**：提供详细的审批轨迹和操作记录
- **追溯能力**：支持按流程实例、任务ID等多维度查询
- **扩展性设计**：支持业务详情的JSON格式存储

## 表结构设计

### 数据库表结构

```mermaid
erDiagram
FLOW_HIS_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
bigint task_id FK
varchar node_code
varchar node_name
tinyint node_type
varchar target_node_code
varchar target_node_name
varchar approver
tinyint cooperate_type
varchar collaborator
varchar skip_type
varchar flow_status
char form_custom
varchar form_path
varchar message
text variable
text ext
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_DEFINITION {
bigint id PK
varchar flow_name
varchar flow_code
text flow_json
varchar flow_status
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_INSTANCE {
bigint id PK
bigint definition_id FK
varchar flow_name
varchar business_id
varchar flow_status
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
varchar node_code
varchar node_name
varchar handler
varchar flow_status
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_HIS_TASK ||--|| FLOW_DEFINITION : "定义ID关联"
FLOW_HIS_TASK ||--|| FLOW_INSTANCE : "实例ID关联"
FLOW_HIS_TASK ||--|| FLOW_TASK : "任务ID关联"
```

**图表来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L120-L142)
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java#L31-L166)

**章节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L120-L142)
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java#L31-L166)

## 核心字段详解

### 主键字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `id` | bigint | 20 | 否 | 无 | 主键标识符，自增或UUID |

### 关联关系字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `definition_id` | bigint | 20 | 否 | 无 | 关联到流程定义表(flow_definition)的ID |
| `instance_id` | bigint | 20 | 否 | 无 | 关联到流程实例表(flow_instance)的ID |
| `task_id` | bigint | 20 | 否 | 无 | 关联到待办任务表(flow_task)的ID |

### 节点信息字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `node_code` | varchar | 100 | 是 | NULL | 开始节点编码 |
| `node_name` | varchar | 100 | 是 | NULL | 开始节点名称 |
| `node_type` | tinyint | 1 | 是 | NULL | 节点类型(0开始节点 1中间节点 2结束节点 3互斥网关 4并行网关) |
| `target_node_code` | varchar | 200 | 是 | NULL | 目标节点编码(多个用逗号分隔) |
| `target_node_name` | varchar | 200 | 是 | NULL | 目标节点名称(多个用逗号分隔) |

### 审批信息字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `approver` | varchar | 40 | 是 | NULL | 审批人标识 |
| `cooperate_type` | tinyint | 1 | 否 | 0 | 协作方式(1审批 2转办 3委派 4会签 5票签 6加签 7减签) |
| `collaborator` | varchar | 500 | 是 | NULL | 协作人信息(会签或加签时存储多人信息) |
| `skip_type` | varchar | 10 | 否 | 无 | 流转类型(PASS通过 REJECT退回 NONE无动作) |
| `flow_status` | varchar | 20 | 否 | 无 | 流程状态(0待提交 1审批中 2审批通过 4终止 5作废 6撤销 8已完成 9已退回 10失效 11拿回) |

### 内容信息字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `message` | varchar | 500 | 是 | NULL | 审批意见或备注信息 |
| `variable` | text | 可变 | 是 | NULL | 任务变量(JSON格式存储) |
| `ext` | text | 可变 | 是 | NULL | 业务详情(JSON格式存储) |

### 系统信息字段

| 字段名 | 类型 | 长度 | 是否允许NULL | 默认值 | 描述 |
|--------|------|------|--------------|--------|------|
| `create_time` | datetime | 无 | 是 | NULL | 任务开始时间 |
| `update_time` | datetime | 无 | 是 | NULL | 审批完成时间 |
| `del_flag` | char | 1 | 是 | '0' | 删除标志(0正常 1删除) |
| `tenant_id` | varchar | 40 | 是 | NULL | 租户ID(多租户支持) |
| `form_custom` | char | 1 | 是 | 'N' | 审批表单是否自定义(Y是 N否) |
| `form_path` | varchar | 100 | 是 | NULL | 审批表单路径 |

**章节来源**
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java#L35-L165)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L120-L142)

## 协作类型系统

`flow_his_task`表支持多种协作类型的记录，每种类型都有其特定的业务含义和应用场景。

### 协作类型枚举

```mermaid
graph TD
A[协作类型] --> B[1-审批 APPROVAL]
A --> C[2-转办 TRANSFER]
A --> D[3-委派 DEPUTE]
A --> E[4-会签 COUNTERSIGN]
A --> F[5-票签 VOTE]
A --> G[6-加签 ADD_SIGNATURE]
A --> H[7-减签 REDUCTION_SIGNATURE]
B --> B1[无其他协作方式<br/>默认审批模式]
C --> C1[任务转给其他人办理<br/>责任转移]
D --> D1[求助其他人审批<br/>参考意见后决策]
E --> E1[和其他人一起审批<br/>必须全部通过]
F --> F1[和部分人一起审批<br/>达到通过率即可]
G --> G1[办理中途希望其他人参与<br/>临时增加审批人]
H --> H1[办理中途希望某些人不参与<br/>临时移除审批人]
```

**图表来源**
- [CooperateType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/CooperateType.java#L37-L56)

### 协作类型详细说明

| 协作类型 | 数值 | 描述 | 使用场景 | `collaborator`字段用途 |
|----------|------|------|----------|----------------------|
| 审批 | 1 | 无其他协作方式 | 单人审批流程 | 通常为空 |
| 转办 | 2 | 任务转给其他人办理 | 责任转移场景 | 存储接收人信息 |
| 委派 | 3 | 求助其他人审批 | 需要参考意见 | 存储被委托人信息 |
| 会签 | 4 | 和其他人一起审批 | 必须全员通过 | 存储所有参与者 |
| 票签 | 5 | 和部分人一起审批 | 达到通过率即可 | 存储投票比例和参与者 |
| 加签 | 6 | 办理中途希望其他人参与 | 临时增加审批人 | 存储新增参与者 |
| 减签 | 7 | 办理中途希望某些人不参与 | 临时移除审批人 | 存储移除的参与者 |

**章节来源**
- [CooperateType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/CooperateType.java#L25-L56)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L95-L124)

## 流转类型系统

流转类型决定了任务在流程中的前进方向和状态变化。

### 流转类型枚举

```mermaid
graph LR
A[流转类型] --> B[PASS-通过]
A --> C[REJECT-退回]
A --> D[NONE-无动作]
B --> B1[审批通过<br/>继续流程]
C --> C1[审批退回<br/>返回上一步]
D --> D1[保持原状<br/>不改变流程]
```

**图表来源**
- [SkipType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/SkipType.java#L34-L38)

### 流转类型详细说明

| 流转类型 | 键值 | 描述 | 影响结果 | 常见场景 |
|----------|------|------|----------|----------|
| PASS | PASS | 审批通过 | 继续流程到下一个节点 | 正常审批流程 |
| REJECT | REJECT | 退回 | 返回上一节点或指定节点 | 审批不通过需要修改 |
| NONE | NONE | 无动作 | 保持当前状态不变 | 特殊情况下的静默操作 |

**章节来源**
- [SkipType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/SkipType.java#L31-L38)

## 与其他表的关系

### 与流程定义表的关系

```mermaid
sequenceDiagram
participant Task as flow_task
participant HisTask as flow_his_task
participant Definition as flow_definition
Task->>HisTask : 任务完成后生成历史记录
HisTask->>Definition : 关联definition_id
Definition-->>HisTask : 查询流程定义信息
HisTask-->>Task : 提供完整的审批历史
```

**图表来源**
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L62-L68)

### 与流程实例表的关系

```mermaid
sequenceDiagram
participant Instance as flow_instance
participant HisTask as flow_his_task
participant Task as flow_task
Task->>HisTask : 完成任务时创建历史记录
HisTask->>Instance : 关联instance_id
Instance-->>HisTask : 查询整个流程状态
HisTask-->>Instance : 提供流程历史轨迹
```

**图表来源**
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L74-L81)

### 与待办任务表的关系

```mermaid
sequenceDiagram
participant Task as flow_task
participant HisTask as flow_his_task
participant Engine as FlowEngine
Task->>Engine : 任务完成
Engine->>HisTask : 创建历史记录
HisTask->>Task : 关联task_id
Task-->>HisTask : 提供原始任务信息
HisTask-->>Engine : 记录完整的审批过程
```

**图表来源**
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L190-L216)

**章节来源**
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L62-L81)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L190-L216)

## 数据模型架构

### 整体架构图

```mermaid
graph TB
subgraph "流程管理模块"
A[flow_definition<br/>流程定义]
B[flow_instance<br/>流程实例]
C[flow_task<br/>待办任务]
D[flow_his_task<br/>历史任务]
end
subgraph "节点管理模块"
E[flow_node<br/>节点定义]
F[flow_skip<br/>跳转规则]
end
subgraph "用户管理模块"
G[flow_user<br/>用户权限]
H[flow_form<br/>表单定义]
end
A --> B
B --> C
C --> D
A --> E
E --> F
C --> G
A --> H
style D fill:#e1f5fe
style C fill:#f3e5f5
```

**图表来源**
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java#L31-L166)

### 数据流向图

```mermaid
flowchart TD
A[新任务创建] --> B[flow_task表插入]
B --> C[任务执行中]
C --> D[任务完成]
D --> E[flow_his_task表插入]
E --> F[flow_task表更新状态]
F --> G[历史记录生成完成]
H[查询历史] --> I[flow_his_task表查询]
I --> J[关联其他表获取完整信息]
J --> K[返回历史记录]
style E fill:#c8e6c9
style I fill:#fff3e0
```

**图表来源**
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L190-L216)

**章节来源**
- [FlowHisTask.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowHisTask.java#L31-L166)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L190-L216)

## 使用场景分析

### 审计追踪场景

```mermaid
sequenceDiagram
participant Auditor as 审计员
participant HisTask as flow_his_task
participant Instance as flow_instance
Auditor->>HisTask : 查询某流程的所有历史记录
HisTask->>Instance : 关联流程实例
Instance-->>HisTask : 获取流程基本信息
HisTask-->>Auditor : 返回完整的审批轨迹
Auditor->>Auditor : 分析审批效率和合规性
```

### 流程监控场景

```mermaid
sequenceDiagram
participant Monitor as 监控系统
participant HisTask as flow_his_task
participant Status as 状态统计
Monitor->>HisTask : 查询最近时间段的历史记录
HisTask-->>Monitor : 返回审批完成数据
Monitor->>Status : 统计各类协作类型的使用频率
Status-->>Monitor : 提供流程健康度报告
```

### 问题排查场景

```mermaid
flowchart TD
A[发现问题] --> B[查询相关历史记录]
B --> C{协作类型分析}
C --> |会签失败| D[检查会签参与者]
C --> |审批超时| E[检查审批人响应时间]
C --> |流程异常| F[检查流转路径]
D --> G[定位具体问题]
E --> G
F --> G
G --> H[制定解决方案]
```

**章节来源**
- [FlowHisTaskMapper.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/mapper/FlowHisTaskMapper.java#L31-L77)

## 性能优化建议

### 索引策略

| 索引类型 | 字段组合 | 用途 | 性能影响 |
|----------|----------|------|----------|
| 主键索引 | id | 唯一标识查询 | 最优 |
| 复合索引 | instance_id, create_time | 流程历史查询 | 很好 |
| 复合索引 | task_id, cooperate_type | 协作类型过滤 | 很好 |
| 单列索引 | approver | 审批人查询 | 良好 |
| 单列索引 | skip_type | 流转类型过滤 | 良好 |

### 查询优化

```sql
-- 推荐的查询方式
SELECT * FROM flow_his_task 
WHERE instance_id = ? 
  AND create_time BETWEEN ? AND ?
ORDER BY create_time DESC
LIMIT 100;

-- 避免全表扫描的查询
SELECT COUNT(*) FROM flow_his_task 
WHERE collaborate_type = 4; -- 会签类型
```

### 数据归档策略

```mermaid
graph LR
A[历史数据] --> B{时间判断}
B --> |超过1年| C[归档到历史表]
B --> |1年内| D[保留在线表]
C --> E[flow_his_task_archive]
D --> F[flow_his_task]
style C fill:#ffebee
style F fill:#e8f5e8
```

## 最佳实践

### 数据完整性保证

1. **外键约束**：确保关联字段的有效性
2. **事务处理**：历史记录创建与任务状态更新的原子性
3. **数据验证**：协作类型和流转类型的合法性校验

### 查询优化实践

1. **合理使用索引**：根据查询频率建立适当的索引
2. **分页查询**：大数据量场景下使用分页避免内存溢出
3. **缓存策略**：对频繁查询的历史数据进行缓存

### 扩展性设计

1. **JSON字段利用**：充分利用`variable`和`ext`字段存储动态数据
2. **字段命名规范**：保持字段命名的一致性和可读性
3. **版本兼容**：考虑未来可能的字段扩展需求

### 安全性考虑

1. **租户隔离**：利用`tenant_id`字段实现多租户数据隔离
2. **访问控制**：基于用户角色限制历史数据的访问权限
3. **数据脱敏**：敏感信息在历史记录中的适当脱敏处理

**章节来源**
- [FlowHisTaskMapper.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/mapper/FlowHisTaskMapper.java#L31-L77)
- [HisTaskServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/HisTaskServiceImpl.java#L50-L68)

## 总结

`flow_his_task`表作为Warm-Flow工作流引擎的核心历史记录表，具有以下关键特点：

1. **完整性**：记录了流程执行的每一个环节，提供了完整的审计轨迹
2. **灵活性**：支持多种协作类型和流转方式，适应复杂的业务场景
3. **可扩展性**：通过JSON字段支持灵活的业务数据存储
4. **关联性强**：与流程定义、实例、任务等表形成完整的数据链路

该表的设计充分体现了现代工作流引擎对审计追踪和流程监控的需求，为系统的稳定运行和持续优化提供了重要支撑。在实际使用中，应当结合具体的业务场景，合理设计查询策略和优化方案，以充分发挥其价值。
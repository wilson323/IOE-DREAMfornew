# 流程节点表 (flow_node)

<cite>
**本文档引用文件**   
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java)
- [NodeType.java](file://warm-flow-core\src\main\java\org\dromara\warm\flow\core\enums\NodeType.java)
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql)
- [postgresql-warm-flow-all.sql](file://sql\postgresql\postgresql-warm-flow-all.sql)
- [sqlserver.sql](file://sql\sqlserver\sqlserver.sql)
- [FlowNodeMapper.xml](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\resources\warm\flow\FlowNodeMapper.xml)
- [FlowDefinition.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowDefinition.java)
- [FlowSkip.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowSkip.java)
</cite>

## 目录
1. [简介](#简介)
2. [表结构概览](#表结构概览)
3. [核心字段详解](#核心字段详解)
4. [节点类型说明](#节点类型说明)
5. [坐标字段](#坐标字段)
6. [通用字段](#通用字段)
7. [关联关系](#关联关系)
8. [数据模型图](#数据模型图)

## 简介
`flow_node`表是流程设计系统的核心数据表，用于存储流程中每个节点的配置信息。该表记录了流程节点的各种属性，包括节点类型、处理器配置、表单路径等，是实现流程定义和执行的基础。通过`definition_id`字段与`flow_definition`表关联，共同构成完整的流程定义。

**Section sources**
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L33-L145)
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L24-L51)

## 表结构概览
`flow_node`表存储了流程节点的所有配置信息，其结构设计支持多种数据库（MySQL、PostgreSQL、SQL Server）。表中每个节点通过`definition_id`与流程定义关联，确保节点属于特定的流程。

```mermaid
erDiagram
flow_node {
bigint id PK
tinyint node_type
bigint definition_id FK
varchar(100) node_code
varchar(100) node_name
varchar(200) permission_flag
decimal(6,3) node_ratio
varchar(100) coordinate
varchar(100) any_node_skip
varchar(100) listener_type
varchar(400) listener_path
varchar(100) handler_type
varchar(400) handler_path
char(1) form_custom
varchar(100) form_path
varchar(20) version
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
text ext
char(1) del_flag
varchar(40) tenant_id
}
flow_definition ||--o{ flow_node : "包含"
flow_skip }o--|| flow_node : "关联"
```

**Diagram sources **
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L24-L51)
- [postgresql-warm-flow-all.sql](file://sql\postgresql\postgresql-warm-flow-all.sql#L45-L72)
- [sqlserver.sql](file://sql\sqlserver\sqlserver.sql#L166-L196)

**Section sources**
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L24-L51)
- [postgresql-warm-flow-all.sql](file://sql\postgresql\postgresql-warm-flow-all.sql#L45-L72)
- [sqlserver.sql](file://sql\sqlserver\sqlserver.sql#L166-L196)

## 核心字段详解
`flow_node`表包含多个关键字段，用于定义流程节点的行为和配置：

- **id**: 主键，唯一标识每个流程节点
- **node_type**: 节点类型，标识节点在流程中的角色（开始、中间、结束、网关等）
- **definition_id**: 关联的流程定义ID，将节点与特定流程关联
- **node_code**: 节点编码，在同一流程定义中必须唯一
- **permission_flag**: 权限标识，用于控制节点的访问权限，多个权限用@@分隔
- **handler_type** 和 **handler_path**: 处理器配置，定义节点执行时调用的处理逻辑
- **form_path**: 关联表单路径，指定节点使用的审批表单

**Section sources**
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L44-L139)
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L27-L41)

## 节点类型说明
`node_type`字段定义了流程节点的类型，其值对应`NodeType`枚举类中的定义：

```mermaid
classDiagram
class NodeType {
+START(0, "start")
+BETWEEN(1, "between")
+END(2, "end")
+SERIAL(3, "serial")
+PARALLEL(4, "parallel")
+INCLUSIVE(5, "inclusive")
+getKeyByValue(value) Integer
+getValueByKey(key) String
+getByKey(key) NodeType
+isStart(key) Boolean
+isBetween(key) Boolean
+isEnd(key) Boolean
+isGateWay(key) Boolean
+isGateWaySerial(key) Boolean
+isGateWayParallel(key) Boolean
+isGateWayInclusive(key) Boolean
}
```

**Diagram sources **
- [NodeType.java](file://warm-flow-core\src\main\java\org\dromara\warm\flow\core\enums\NodeType.java#L27-L159)

**Section sources**
- [NodeType.java](file://warm-flow-core\src\main\java\org\dromara\warm\flow\core\enums\NodeType.java#L27-L159)
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L75-L77)

## 坐标字段
`coordinate`字段用于存储设计器中节点的坐标信息，支持流程图的可视化展示。该字段存储节点在画布上的位置，通常以"x,y"格式保存，便于前端设计器准确渲染节点位置。

**Section sources**
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L99-L101)
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L34)

## 通用字段
`del_flag`和`tenant_id`是系统通用字段：
- **del_flag**: 删除标志，用于逻辑删除，'0'表示未删除，'1'表示已删除
- **tenant_id**: 租户ID，支持多租户架构，确保数据隔离

**Section sources**
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L67-L72)
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql#L48-L49)

## 关联关系
`flow_node`表通过以下方式与其他表建立关联：
- 通过`definition_id`与`flow_definition`表关联，形成"一对多"关系
- 与`flow_skip`表共同定义流程走向，`flow_skip`表存储节点间的跳转规则

```mermaid
erDiagram
flow_definition {
bigint id PK
varchar(100) flow_code
varchar(100) flow_name
varchar(20) model_value
varchar(100) category
varchar(20) version
integer is_publish
char(1) form_custom
varchar(100) form_path
integer activity_status
varchar(100) listener_type
varchar(400) listener_path
varchar(500) ext
char(1) del_flag
varchar(40) tenant_id
}
flow_node {
bigint id PK
tinyint node_type
bigint definition_id FK
varchar(100) node_code
varchar(100) node_name
varchar(200) permission_flag
decimal(6,3) node_ratio
varchar(100) coordinate
varchar(100) any_node_skip
varchar(100) listener_type
varchar(400) listener_path
varchar(100) handler_type
varchar(400) handler_path
char(1) form_custom
varchar(100) form_path
varchar(20) version
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
text ext
char(1) del_flag
varchar(40) tenant_id
}
flow_skip {
bigint id PK
bigint definition_id FK
varchar(100) now_node_code
tinyint now_node_type
varchar(100) next_node_code
tinyint next_node_type
varchar(100) skip_name
varchar(40) skip_type
varchar(200) skip_condition
varchar(100) coordinate
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
char(1) del_flag
varchar(40) tenant_id
}
flow_definition ||--o{ flow_node : "包含"
flow_node }o--|| flow_skip : "关联跳转"
```

**Diagram sources **
- [FlowDefinition.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowDefinition.java#L33-L139)
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java#L33-L145)
- [FlowSkip.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowSkip.java)

**Section sources**
- [flow_node.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowNode.java)
- [FlowDefinition.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowDefinition.java)
- [FlowSkip.java](file://warm-flow-orm\warm-flow-mybatis\warm-flow-mybatis-core\src\main\java\org\dromara\warm\flow\orm\entity\FlowSkip.java)

## 数据模型图
以下是`flow_node`表的完整数据模型图，展示了其与相关表的关联关系：

```mermaid
erDiagram
flow_definition {
bigint id PK
varchar(100) flow_code
varchar(100) flow_name
varchar(20) model_value
varchar(100) category
varchar(20) version
integer is_publish
char(1) form_custom
varchar(100) form_path
integer activity_status
varchar(100) listener_type
varchar(400) listener_path
varchar(500) ext
char(1) del_flag
varchar(40) tenant_id
}
flow_node {
bigint id PK
tinyint node_type
bigint definition_id FK
varchar(100) node_code
varchar(100) node_name
varchar(200) permission_flag
decimal(6,3) node_ratio
varchar(100) coordinate
varchar(100) any_node_skip
varchar(100) listener_type
varchar(400) listener_path
varchar(100) handler_type
varchar(400) handler_path
char(1) form_custom
varchar(100) form_path
varchar(20) version
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
text ext
char(1) del_flag
varchar(40) tenant_id
}
flow_skip {
bigint id PK
bigint definition_id FK
varchar(100) now_node_code
tinyint now_node_type
varchar(100) next_node_code
tinyint next_node_type
varchar(100) skip_name
varchar(40) skip_type
varchar(200) skip_condition
varchar(100) coordinate
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
char(1) del_flag
varchar(40) tenant_id
}
flow_task {
bigint id PK
bigint definition_id FK
bigint instance_id FK
varchar(100) node_code
varchar(100) node_name
tinyint node_type
varchar(20) flow_status
char(1) form_custom
varchar(100) form_path
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
char(1) del_flag
varchar(40) tenant_id
}
flow_his_task {
bigint id PK
bigint definition_id FK
bigint instance_id FK
bigint task_id FK
varchar(100) node_code
varchar(100) node_name
tinyint node_type
varchar(200) target_node_code
varchar(200) target_node_name
varchar(40) approver
tinyint cooperate_type
varchar(500) collaborator
varchar(10) skip_type
varchar(20) flow_status
char(1) form_custom
varchar(100) form_path
varchar(500) message
text variable
text ext
datetime create_time
datetime update_time
char(1) del_flag
varchar(40) tenant_id
}
flow_instance {
bigint id PK
bigint definition_id FK
varchar(40) business_id
tinyint node_type
varchar(40) node_code
varchar(100) node_name
text variable
varchar(20) flow_status
tinyint activity_status
text def_json
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
varchar(500) ext
char(1) del_flag
varchar(40) tenant_id
}
flow_user {
bigint id PK
char(1) type
varchar(80) processed_by
bigint associated FK
datetime create_time
varchar(80) create_by
datetime update_time
varchar(64) update_by
char(1) del_flag
varchar(40) tenant_id
}
flow_definition ||--o{ flow_node : "包含"
flow_definition ||--o{ flow_skip : "包含"
flow_definition ||--o{ flow_task : "关联"
flow_definition ||--o{ flow_his_task : "关联"
flow_definition ||--o{ flow_instance : "关联"
flow_definition ||--o{ flow_user : "关联"
flow_node }o--|| flow_skip : "关联跳转"
flow_node }o--|| flow_task : "当前节点"
flow_node }o--|| flow_his_task : "历史节点"
flow_node }o--|| flow_instance : "当前节点"
```

**Diagram sources **
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql)
- [postgresql-warm-flow-all.sql](file://sql\postgresql\postgresql-warm-flow-all.sql)
- [sqlserver.sql](file://sql\sqlserver\sqlserver.sql)

**Section sources**
- [warm-flow-all.sql](file://sql\mysql\warm-flow-all.sql)
- [postgresql-warm-flow-all.sql](file://sql\postgresql\postgresql-warm-flow-all.sql)
- [sqlserver.sql](file://sql\sqlserver\sqlserver.sql)
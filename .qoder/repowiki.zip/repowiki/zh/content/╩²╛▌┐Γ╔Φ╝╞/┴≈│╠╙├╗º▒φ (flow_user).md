# 流程用户表 (flow_user) 数据模型文档

<cite>
**本文档引用的文件**
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java)
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java)
- [UserType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/UserType.java)
- [UserService.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/UserService.java)
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java)
- [FlowUserDao.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/orm/dao/FlowUserDao.java)
- [warm-flow_1.2.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.2.0.sql)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql)
- [oracle-wram-flow-all.sql](file://sql/oracle/oracle-wram-flow-all.sql)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql)
</cite>

## 目录
1. [概述](#概述)
2. [表结构设计](#表结构设计)
3. [字段详解](#字段详解)
4. [设计模式分析](#设计模式分析)
5. [关联关系](#关联关系)
6. [权限类型机制](#权限类型机制)
7. [数据迁移策略](#数据迁移策略)
8. [业务应用场景](#业务应用场景)
9. [性能优化考虑](#性能优化考虑)
10. [最佳实践建议](#最佳实践建议)

## 概述

`flow_user`表是Warm-Flow工作流引擎中的核心权限管理表，专门用于存储任务与用户之间的权限关系。该表的设计巧妙地解决了多处理人场景（如会签）的复杂性，通过灵活的权限类型和关联机制，实现了复杂的工作流权限分配和任务协作模式。

该表的核心价值在于：
- 支持多种权限类型的灵活配置
- 实现了从传统权限标识到细粒度权限控制的演进
- 提供了完整的任务协作机制
- 确保了权限数据的完整性和一致性

## 表结构设计

### 数据库表结构概览

```mermaid
erDiagram
FLOW_USER {
bigint id PK
char(1) type
varchar(80) processed_by
bigint associated FK
datetime create_time
varchar(80) create_by
datetime update_time
varchar(80) update_by
char(1) del_flag
varchar(40) tenant_id
}
FLOW_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
varchar(100) node_code
varchar(100) node_name
tinyint node_type
varchar(20) flow_status
char(1) form_custom
varchar(100) form_path
datetime create_time
varchar(64) create_by
datetime update_time
varchar(64) update_by
char(1) del_flag
varchar(40) tenant_id
}
FLOW_HIS_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
bigint task_id FK
varchar(100) node_code
varchar(100) node_name
tinyint node_type
varchar(200) target_node_code
varchar(200) target_node_name
varchar(40) approver
tinyint cooperate_type
varchar(500) collaborator
varchar(10) skip_type
varchar(20) flow_status
char(1) form_custom
varchar(100) form_path
varchar(500) message
text variable
text ext
datetime create_time
datetime update_time
char(1) del_flag
varchar(40) tenant_id
}
FLOW_USER ||--|| FLOW_TASK : "associated"
FLOW_USER }|--|| FLOW_HIS_TASK : "associated"
```

**图表来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L144-L160)
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java#L30-L84)

**章节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L144-L160)
- [oracle-wram-flow-all.sql](file://sql/oracle/oracle-wram-flow-all.sql#L282-L313)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql#L270-L298)

## 字段详解

### 主键字段

| 字段名 | 类型 | 长度 | 必填 | 描述 |
|--------|------|------|------|------|
| id | bigint | - | 是 | 主键ID，全局唯一标识 |

### 权限控制字段

| 字段名 | 类型 | 长度 | 必填 | 描述 |
|--------|------|------|------|------|
| type | char(1) | 1 | 是 | 人员类型：<br/>1 - 待办任务的审批人权限<br/>2 - 待办任务的转办人权限<br/>3 - 待办任务的委托人权限 |
| processed_by | varchar(80) | 80 | 否 | 权限人标识，可以是用户ID、角色ID、部门ID等 |
| associated | bigint | - | 是 | 关联的任务表ID，可指向flow_task或flow_his_task的主键 |

### 元数据字段

| 字段名 | 类型 | 长度 | 必填 | 描述 |
|--------|------|------|------|------|
| create_time | datetime | - | 否 | 创建时间 |
| create_by | varchar(80) | 80 | 否 | 创建人 |
| update_time | datetime | - | 否 | 更新时间 |
| update_by | varchar(80) | 80 | 否 | 更新人 |
| del_flag | char(1) | 1 | 否 | 删除标志（0正常，1删除） |
| tenant_id | varchar(40) | 40 | 否 | 租户ID，支持多租户隔离 |

**章节来源**
- [FlowUser.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowUser.java#L30-L84)
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java#L26-L95)

## 设计模式分析

### 组合权限设计模式

`flow_user`表采用了组合权限设计模式，通过`type`和`processed_by`字段的组合，实现了灵活的角色权限映射：

```mermaid
flowchart TD
A["任务发起"] --> B["解析权限规则"]
B --> C{"权限类型判断"}
C --> |type=1| D["审批人权限"]
C --> |type=2| E["转办人权限"]
C --> |type=3| F["委托人权限"]
D --> G["processed_by: 用户ID"]
E --> H["processed_by: 角色ID"]
F --> I["processed_by: 部门ID"]
G --> J["权限验证"]
H --> J
I --> J
J --> K["任务执行"]
```

**图表来源**
- [UserType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/UserType.java#L34-L38)
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java#L58-L64)

### 松耦合关联机制

该表通过`associated`字段实现了与任务表的松耦合关联，这种设计具有以下优势：

1. **灵活性**：一个用户可以同时参与多个任务的权限验证
2. **可扩展性**：支持未来扩展新的关联类型
3. **性能优化**：独立的索引设计确保查询效率
4. **数据完整性**：外键约束保证数据一致性

**章节来源**
- [FlowUserDao.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/orm/dao/FlowUserDao.java#L27-L57)

## 关联关系

### 与flow_task的关联

`flow_user`表通过`associated`字段与`flow_task`表建立一对一或多对一的关系：

```mermaid
sequenceDiagram
participant T as flow_task
participant U as flow_user
participant P as 处理人
T->>U : 创建任务时插入权限记录
Note over U : associated = task.id<br/>type = APPROVAL<br/>processed_by = 用户ID
P->>U : 查询权限人列表
U->>T : 返回关联的任务信息
T->>U : 任务完成后清理权限记录
U->>U : 删除相关权限数据
```

**图表来源**
- [warm-flow_1.2.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.2.0.sql#L17-L27)
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java#L58-L64)

### 与flow_his_task的关联

对于历史任务，`flow_user`同样通过`associated`字段建立关联，但主要用于权限追溯和审计：

```mermaid
flowchart LR
A["flow_his_task"] --> B["associated"]
B --> C["flow_user"]
C --> D["权限验证历史"]
C --> E["审计追踪"]
F["当前任务"] --> G["associated"]
G --> H["flow_user"]
H --> I["实时权限控制"]
```

**图表来源**
- [User.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/User.java#L89-L93)

**章节来源**
- [warm-flow_1.2.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.2.0.sql#L17-L27)

## 权限类型机制

### UserType枚举定义

系统通过`UserType`枚举类明确定义了三种权限类型：

| 类型 | 键值 | 描述 |
|------|------|------|
| APPROVAL | 1 | 待办任务的审批人权限 |
| TRANSFER | 2 | 待办任务的转办人权限 |
| DEPUTE | 3 | 待办任务的委托人权限 |

### 权限类型应用场景

```mermaid
graph TB
subgraph "审批人权限 (type=1)"
A1["直接审批任务"]
A2["拥有最终决策权"]
A3["可进行通过/拒绝操作"]
end
subgraph "转办人权限 (type=2)"
B1["接收他人任务"]
B2["代替原处理人"]
B3["保持原有权限范围"]
end
subgraph "委托人权限 (type=3)"
C1["授权他人处理"]
C2["保留监督权"]
C3["可随时收回权限"]
end
A1 --> D["权限验证流程"]
B1 --> D
C1 --> D
```

**图表来源**
- [UserType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/UserType.java#L34-L38)

### 权限验证流程

系统通过以下流程实现权限验证：

```mermaid
flowchart TD
A["用户请求操作"] --> B["获取任务ID"]
B --> C["查询flow_user表"]
C --> D["按associated过滤"]
D --> E["按type筛选权限类型"]
E --> F["按processed_by匹配用户"]
F --> G{"权限验证结果"}
G --> |通过| H["允许操作"]
G --> |失败| I["拒绝操作"]
```

**图表来源**
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java#L71-L82)

**章节来源**
- [UserType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/UserType.java#L27-L71)
- [UserService.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/UserService.java#L69-L107)

## 数据迁移策略

### 从permission_flag到flow_user的迁移

在系统升级过程中，原有的`permission_flag`字段被迁移到`flow_user`表中，实现了更灵活的权限管理：

```mermaid
flowchart LR
A["flow_task.permission_flag"] --> B["权限标识解析"]
B --> C["多用户权限拆分"]
C --> D["批量插入flow_user"]
E["原始数据"] --> F["'user1,user2,user3'"]
F --> G["拆分为三条记录"]
G --> H["每条记录对应一个用户"]
I["新表结构"] --> J["id, type, processed_by, associated"]
J --> K["1, '1', 'user1', task_id"]
J --> L["2, '1', 'user2', task_id"]
J --> M["3, '1', 'user3', task_id"]
```

**图表来源**
- [warm-flow_1.2.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.2.0.sql#L17-L27)

### 迁移脚本分析

迁移过程包含以下关键步骤：

1. **数据解析**：将逗号分隔的权限标识转换为独立记录
2. **批量插入**：使用MySQL的`help_topic`表实现字符串分割
3. **字段映射**：将旧字段映射到新表结构
4. **索引重建**：创建必要的索引以保证查询性能

**章节来源**
- [warm-flow_1.2.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.2.0.sql#L17-L27)

## 业务应用场景

### 会签场景支持

`flow_user`表天然支持会签场景，每个参与者都有独立的权限记录：

```mermaid
graph LR
A["会签任务"] --> B["flow_task记录"]
B --> C["flow_user表"]
C --> D["用户A: type=1, processed_by=user1"]
C --> E["用户B: type=1, processed_by=user2"]
C --> F["用户C: type=1, processed_by=user3"]
D --> G["并行审批"]
E --> G
F --> G
G --> H["所有用户审批完成"]
```

### 转办和委托场景

系统支持复杂的任务转办和委托场景：

```mermaid
sequenceDiagram
participant O as 原处理人
participant S as 系统
participant T as 新处理人
participant U as flow_user
O->>S : 请求转办任务
S->>U : 创建转办权限记录
Note over U : type=2, processed_by=newUser
T->>S : 查看待办任务
S->>U : 查询转办权限
U->>S : 返回转办任务
S->>T : 显示可处理任务
```

### 加签和减签支持

通过动态的权限管理，系统支持运行时的加签和减签操作：

```mermaid
flowchart TD
A["任务执行中"] --> B["需要加签"]
B --> C["添加新权限记录"]
C --> D["type=1, processed_by=newUser"]
E["任务执行中"] --> F["需要减签"]
F --> G["删除指定权限记录"]
G --> H["重新计算完成率"]
I["会签场景"] --> J["动态调整参与人"]
J --> K["保持审批完整性"]
```

**图表来源**
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java#L123-L133)

**章节来源**
- [UserService.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/UserService.java#L30-L166)
- [UserServiceImpl.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/service/impl/UserServiceImpl.java#L48-L163)

## 性能优化考虑

### 索引设计策略

系统采用复合索引和单列索引相结合的方式优化查询性能：

| 索引名称 | 索引字段 | 用途 | 性能影响 |
|----------|----------|------|----------|
| PRIMARY KEY | id | 主键查询 | O(log n) |
| user_processed_type | processed_by, type | 权限验证 | O(log n) |
| user_associated_idx | associated | 关联查询 | O(log n) |

### 查询优化模式

```mermaid
flowchart TD
A["权限查询请求"] --> B{"查询条件分析"}
B --> |按用户查询| C["user_processed_type索引"]
B --> |按任务查询| D["user_associated_idx索引"]
B --> |混合查询| E["复合索引优化"]
C --> F["快速定位用户权限"]
D --> G["快速定位任务权限"]
E --> H["最优查询路径"]
F --> I["返回权限列表"]
G --> I
H --> I
```

### 批量操作优化

系统提供了批量操作接口，减少数据库交互次数：

```mermaid
sequenceDiagram
participant C as 客户端
participant S as 服务层
participant D as DAO层
participant DB as 数据库
C->>S : 批量添加权限
S->>D : saveBatch操作
D->>DB : 单次批量插入
DB-->>D : 返回执行结果
D-->>S : 返回操作结果
S-->>C : 返回最终结果
```

**图表来源**
- [FlowUserDao.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/orm/dao/FlowUserDao.java#L27-L57)

**章节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L158-L159)
- [oracle-wram-flow-all.sql](file://sql/oracle/oracle-wram-flow-all.sql#L311-L312)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql#L284-L285)

## 最佳实践建议

### 权限设计原则

1. **最小权限原则**：只授予完成任务所需的最小权限
2. **职责分离**：审批、审核、监督等角色应适当分离
3. **权限继承**：合理利用角色和部门权限继承机制
4. **定期清理**：及时清理过期的权限记录

### 数据维护建议

1. **索引监控**：定期检查索引使用情况，优化查询性能
2. **数据归档**：对历史权限数据进行定期归档处理
3. **权限审计**：建立完善的权限变更审计机制
4. **容量规划**：根据业务增长预测表空间需求

### 开发规范

1. **统一接口**：使用UserService提供的标准化接口
2. **事务管理**：权限操作应放在合适的事务边界内
3. **异常处理**：妥善处理权限验证失败的情况
4. **日志记录**：记录关键的权限操作日志

### 性能调优

1. **查询优化**：优先使用复合索引进行查询
2. **批量操作**：大量权限操作时使用批量接口
3. **缓存策略**：对频繁查询的权限数据进行缓存
4. **分页处理**：大数据量查询时实施分页策略

通过以上设计和实践，`flow_user`表为Warm-Flow工作流引擎提供了强大而灵活的权限管理能力，支撑了复杂的企业级业务流程需求。
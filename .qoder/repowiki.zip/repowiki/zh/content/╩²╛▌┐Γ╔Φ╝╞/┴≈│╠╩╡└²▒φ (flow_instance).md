# 流程实例表 (flow_instance) 数据模型文档

<cite>
**本文档引用的文件**
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java)
- [FlowInstance.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowInstance.java)
- [FlowInstanceDao.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/orm/dao/FlowInstanceDao.java)
- [FlowInstanceMapper.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/mapper/FlowInstanceMapper.java)
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql)
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java)
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java)
- [FlowStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FlowStatus.java)
- [NodeType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/NodeType.java)
- [ActivityStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/ActivityStatus.java)
</cite>

## 目录
1. [概述](#概述)
2. [表结构设计](#表结构设计)
3. [核心字段详解](#核心字段详解)
4. [关联关系分析](#关联关系分析)
5. [数据模型架构](#数据模型架构)
6. [业务场景应用](#业务场景应用)
7. [性能优化考虑](#性能优化考虑)
8. [最佳实践建议](#最佳实践建议)

## 概述

`flow_instance`表是Warm-Flow工作流引擎的核心数据表之一，专门用于记录每个流程的实际运行实例。该表作为流程从定义到执行的实例化体现，承载着流程执行过程中的所有关键信息，包括流程状态、执行节点、业务关联等重要数据。

该表的设计遵循了工作流管理的最佳实践，通过合理的字段设计和关联关系，实现了对复杂业务流程的有效跟踪和管理。它不仅记录了流程的基本信息，还维护了流程执行过程中的动态状态变化，为后续的流程监控、审计和分析提供了坚实的数据基础。

## 表结构设计

### 基础字段设计

```mermaid
erDiagram
FLOW_INSTANCE {
bigint id PK
bigint definition_id FK
varchar business_id
tinyint node_type
varchar node_code
varchar node_name
text variable
varchar flow_status
tinyint activity_status
text def_json
datetime create_time
varchar create_by
datetime update_time
varchar update_by
varchar ext
char del_flag
varchar tenant_id
}
FLOW_DEFINITION {
bigint id PK
varchar flow_code
varchar flow_name
varchar category
varchar version
tinyint is_publish
char form_custom
varchar form_path
tinyint activity_status
varchar ext
datetime create_time
varchar create_by
datetime update_time
varchar update_by
char del_flag
varchar tenant_id
}
FLOW_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
varchar node_code
varchar node_name
tinyint node_type
varchar flow_status
char form_custom
varchar form_path
datetime create_time
varchar create_by
datetime update_time
varchar update_by
char del_flag
varchar tenant_id
}
FLOW_HIS_TASK {
bigint id PK
bigint definition_id FK
bigint instance_id FK
bigint task_id FK
varchar node_code
varchar node_name
varchar node_type
varchar target_node_code
varchar target_node_name
varchar approver
tinyint cooperate_type
varchar collaborator
varchar skip_type
varchar flow_status
char form_custom
varchar form_path
varchar message
text variable
text ext
datetime create_time
datetime update_time
char del_flag
varchar tenant_id
}
FLOW_INSTANCE ||--|| FLOW_DEFINITION : "definition_id"
FLOW_INSTANCE ||--o{ FLOW_TASK : "instance_id"
FLOW_INSTANCE ||--o{ FLOW_HIS_TASK : "instance_id"
```

**图表来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L74-L94)
- [FlowInstance.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowInstance.java#L31-L138)

### 字段类型映射

| 字段名 | MySQL类型 | Java类型 | 描述 |
|--------|-----------|----------|------|
| id | bigint | Long | 主键，自增标识符 |
| definition_id | bigint | Long | 关联的流程定义ID |
| business_id | varchar(40) | String | 业务系统关联ID |
| node_type | tinyint(1) | Integer | 节点类型（0开始节点 1中间节点 2结束节点 3互斥网关 4并行网关） |
| node_code | varchar(40) | String | 流程节点编码 |
| node_name | varchar(100) | String | 流程节点名称 |
| variable | text | String | 流程级别变量（JSON格式） |
| flow_status | varchar(20) | String | 流程状态 |
| activity_status | tinyint(1) | Integer | 流程激活状态（0挂起 1激活） |
| def_json | text | String | 序列化的流程定义快照 |
| create_time | datetime | Date | 创建时间 |
| create_by | varchar(64) | String | 创建人 |
| update_time | datetime | Date | 更新时间 |
| update_by | varchar(64) | String | 更新人 |
| ext | varchar(500) | String | 扩展字段 |
| del_flag | char(1) | String | 删除标记（0正常 1删除） |
| tenant_id | varchar(40) | String | 租户ID |

**章节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L74-L94)
- [FlowInstance.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowInstance.java#L31-L138)

## 核心字段详解

### 主键字段 (id)

`id`字段是`flow_instance`表的主键，采用MySQL的`bigint`类型，确保了表的容量支持和性能表现。该字段由系统自动生成，通常使用雪花算法或分布式ID生成器来保证全局唯一性。

### 关联字段 (definition_id)

`definition_id`字段建立了与`flow_definition`表的一对一关联关系。这个字段的重要性体现在：

- **流程溯源**：通过这个字段可以追溯到具体的流程定义
- **版本控制**：即使流程定义被修改，实例仍然保持原始定义的快照
- **权限控制**：基于流程定义的权限设置进行访问控制

### 业务关联字段 (business_id)

`business_id`字段是连接业务系统的关键桥梁，具有以下特点：

- **业务唯一性**：在业务系统中保持唯一性
- **跨系统集成**：便于与其他业务系统的数据关联
- **审计追踪**：支持业务操作的完整审计链

### 节点控制字段 (node_code, node_type, node_name)

这三个字段共同构成了流程执行的节点控制机制：

```mermaid
flowchart TD
A["流程启动"] --> B["确定开始节点"]
B --> C["设置node_code"]
C --> D["更新node_type"]
D --> E["记录node_name"]
E --> F["执行节点逻辑"]
F --> G["更新到下一个节点"]
G --> H["重复上述过程"]
H --> I["流程结束"]
```

**图表来源**
- [NodeType.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/NodeType.java#L31-L57)

### 状态管理字段

#### flow_status 字段

`flow_status`字段记录了流程的当前状态，采用枚举值的方式管理：

| 状态值 | 状态名称 | 描述 |
|--------|----------|------|
| 0 | 待提交 | 流程刚创建，等待首次提交 |
| 1 | 审批中 | 流程正在审批过程中 |
| 2 | 审批通过 | 流程审批全部通过 |
| 4 | 终止 | 管理员主动终止流程 |
| 5 | 作废 | 流程被作废处理 |
| 6 | 撤销 | 用户主动撤销流程 |
| 8 | 已完成 | 流程正常完成 |
| 9 | 已退回 | 流程被退回至前一节点 |
| 10 | 失效 | 流程因某些原因失效 |
| 11 | 拿回 | 管理员拿回流程重新处理 |

#### activity_status 字段

`activity_status`字段用于控制流程的激活状态：

- **0 (挂起)**：流程暂停执行，但保留状态信息
- **1 (激活)**：流程正常执行

### 变量存储字段 (variable)

`variable`字段是一个重要的设计亮点，采用JSON格式存储流程级别的变量：

```mermaid
classDiagram
class VariableStorage {
+String variable
+Map~String,Object~ getVariableMap()
+void setVariable(String)
+void setVariableMap(Map~String,Object~)
}
class JsonConverter {
+Map~String,Object~ strToMap(String)
+String objToStr(Object)
+T strToBean(String,Class~T~)
}
VariableStorage --> JsonConverter : "使用"
```

**图表来源**
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java#L125-L127)

该字段的设计优势：
- **灵活性**：支持任意类型的业务变量存储
- **扩展性**：无需修改表结构即可添加新的变量类型
- **查询效率**：通过索引和分片策略优化查询性能

### 定义快照字段 (def_json)

`def_json`字段存储了流程定义的JSON快照，这一设计实现了：

- **历史一致性**：即使流程定义被修改，实例仍能反映当时的定义状态
- **审计需求**：提供完整的流程执行依据
- **调试支持**：便于问题排查和流程分析

**章节来源**
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java#L73-L156)
- [FlowInstance.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowInstance.java#L31-L138)

## 关联关系分析

### 与 flow_task 的关联

`flow_instance`表与`flow_task`表通过`instance_id`字段建立一对多的关系：

```mermaid
sequenceDiagram
participant Instance as "flow_instance"
participant Task as "flow_task"
participant History as "flow_his_task"
Instance->>Task : 创建新任务
Task->>Instance : 记录任务关联
Task->>History : 完成后归档
History->>Instance : 更新实例状态
Note over Instance,History : 实例跟踪整个任务生命周期
```

**图表来源**
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java#L80-L85)
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L76-L81)

### 与 flow_his_task 的关联

`flow_instance`表与`flow_his_task`表同样通过`instance_id`字段关联，这种设计实现了：

- **任务历史追踪**：完整记录每个任务的执行历史
- **状态变更记录**：跟踪流程状态的每一次变化
- **审计证据保存**：为合规审计提供完整的证据链

### 与 flow_definition 的关联

通过`definition_id`字段与`flow_definition`表建立关联，实现了：

- **流程版本控制**：支持流程定义的版本演进
- **配置继承**：实例继承定义的配置和规则
- **权限控制**：基于定义的权限设置进行访问控制

**章节来源**
- [FlowInstanceDao.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/orm/dao/FlowInstanceDao.java#L28-L37)
- [FlowInstanceMapper.java](file://warm-flow-orm/warm-flow-mybatis/warm-flow-mybatis-core/src/main/java/org/dromara/warm/flow/orm/mapper/FlowInstanceMapper.java#L29-L32)

## 数据模型架构

### 分层设计理念

```mermaid
graph TB
subgraph "表现层"
UI[用户界面]
API[REST API]
end
subgraph "服务层"
InsService[流程实例服务]
TaskService[任务服务]
HisTaskService[历史任务服务]
end
subgraph "数据访问层"
InsDao[实例DAO]
TaskDao[任务DAO]
HisTaskDao[历史任务DAO]
end
subgraph "数据持久层"
FlowInstance[flow_instance表]
FlowTask[flow_task表]
FlowHisTask[flow_his_task表]
end
UI --> API
API --> InsService
API --> TaskService
API --> HisTaskService
InsService --> InsDao
TaskService --> TaskDao
HisTaskService --> HisTaskDao
InsDao --> FlowInstance
TaskDao --> FlowTask
HisTaskDao --> FlowHisTask
```

**图表来源**
- [Instance.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Instance.java#L29-L166)
- [Task.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/Task.java#L27-L136)
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L30-L164)

### 数据完整性保障

系统通过多种机制确保数据完整性：

1. **外键约束**：确保关联数据的一致性
2. **事务控制**：保证操作的原子性
3. **状态验证**：防止非法的状态转换
4. **并发控制**：避免数据竞争和不一致

### 性能优化策略

```mermaid
flowchart LR
A["查询优化"] --> B["索引策略"]
A --> C["缓存机制"]
B --> D["主键索引"]
B --> E["业务ID索引"]
B --> F["状态索引"]
C --> G["内存缓存"]
C --> H["Redis缓存"]
I["写入优化"] --> J["批量操作"]
I --> K["异步处理"]
J --> L["批量插入"]
J --> M["批量更新"]
K --> N["消息队列"]
K --> O["定时任务"]
```

**章节来源**
- [warm-flow-all.sql](file://sql/mysql/warm-flow-all.sql#L74-L94)

## 业务场景应用

### 流程监控场景

在流程监控场景中，`flow_instance`表提供了丰富的数据支撑：

- **实时状态监控**：通过`flow_status`字段实时掌握流程状态
- **性能指标统计**：基于创建时间和更新时间计算流程耗时
- **资源使用分析**：通过`variable`字段分析流程中的资源消耗

### 审计追踪场景

审计追踪是`flow_instance`表的重要应用场景：

```mermaid
sequenceDiagram
participant Auditor as "审计员"
participant System as "系统"
participant Instance as "flow_instance"
participant History as "flow_his_task"
Auditor->>System : 请求审计报告
System->>Instance : 查询实例基本信息
Instance-->>System : 返回实例数据
System->>History : 查询历史任务记录
History-->>System : 返回完整执行轨迹
System-->>Auditor : 提供审计报告
```

**图表来源**
- [HisTask.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/entity/HisTask.java#L76-L81)

### 决策支持场景

基于`flow_instance`表的数据可以支持多种决策分析：

- **流程效率分析**：通过状态转换时间分析流程效率
- **瓶颈识别**：识别流程中的常见阻塞节点
- **质量评估**：基于成功率和退回率评估流程质量

**章节来源**
- [FlowStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FlowStatus.java#L32-L55)

## 性能优化考虑

### 索引策略

针对`flow_instance`表的查询模式，建议实施以下索引策略：

| 索引类型 | 字段组合 | 使用场景 |
|----------|----------|----------|
| 主键索引 | id | 唯一标识查询 |
| 业务索引 | business_id | 业务系统关联查询 |
| 状态索引 | flow_status | 状态过滤查询 |
| 时间索引 | create_time, update_time | 时间范围查询 |
| 组合索引 | definition_id, flow_status | 流程定义状态查询 |

### 分区策略

对于大规模部署，可以考虑分区策略：

- **按时间分区**：按创建时间进行月度或年度分区
- **按业务分区**：按业务ID范围进行分区
- **按租户分区**：多租户环境下的租户隔离

### 缓存策略

```mermaid
graph LR
A["请求"] --> B["缓存检查"]
B --> C{"缓存命中?"}
C --> |是| D["返回缓存数据"]
C --> |否| E["查询数据库"]
E --> F["更新缓存"]
F --> G["返回数据"]
H["数据更新"] --> I["清理相关缓存"]
I --> J["确保数据一致性"]
```

## 最佳实践建议

### 数据设计原则

1. **字段命名规范**：采用统一的命名约定，如使用下划线分隔
2. **数据类型选择**：根据实际需求选择合适的数据类型
3. **默认值设置**：为常用字段设置合理的默认值
4. **长度限制**：合理设置字段长度，避免浪费存储空间

### 业务应用指导

1. **状态机设计**：基于`flow_status`字段构建清晰的状态转换图
2. **变量管理**：合理使用`variable`字段存储业务变量
3. **审计日志**：充分利用`create_time`、`update_time`等字段进行审计
4. **性能监控**：定期监控表的性能指标，及时优化

### 维护管理建议

1. **定期清理**：清理过期的历史数据，保持表的性能
2. **备份策略**：制定完善的备份和恢复策略
3. **监控告警**：建立完善的监控和告警机制
4. **版本升级**：谨慎处理表结构的版本升级

### 安全考虑

1. **数据加密**：对敏感数据进行加密存储
2. **访问控制**：实施严格的访问权限控制
3. **审计追踪**：记录所有数据访问和修改操作
4. **数据脱敏**：在非生产环境中进行数据脱敏处理

通过以上设计和实践，`flow_instance`表能够有效支撑复杂的业务流程管理需求，为企业的数字化转型提供强有力的技术支撑。
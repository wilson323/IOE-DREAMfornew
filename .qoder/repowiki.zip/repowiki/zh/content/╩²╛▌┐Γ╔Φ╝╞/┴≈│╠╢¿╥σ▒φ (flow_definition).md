# 流程定义表 (flow_definition)

<cite>
**本文档引用的文件**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql)
- [FlowDefinition.java](file://warm-flow-orm/warm-flow-mybatis-plus/warm-flow-mybatis-plus-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowDefinition.java)
- [ModelEnum.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/ModelEnum.java)
- [ActivityStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/ActivityStatus.java)
- [PublishStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/PublishStatus.java)
- [FormCustomEnum.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FormCustomEnum.java)
- [warm-flow_1.3.0.sql](file://sql/mysql/v1-upgrade/warm-flow_1.3.0.sql)
- [warm-flow_1.7.6.sql](file://sql/mysql/v1-upgrade/warm-flow_1.7.6.sql)
</cite>

## 目录
1. [简介](#简介)
2. [表结构与字段说明](#表结构与字段说明)
3. [主键与索引约束](#主键与索引约束)
4. [外键关系](#外键关系)
5. [字段枚举值说明](#字段枚举值说明)
6. [逻辑删除机制](#逻辑删除机制)
7. [多租户支持](#多租户支持)
8. [使用示例](#使用示例)
9. [数据模型图](#数据模型图)

## 简介

`flow_definition` 表是流程管理系统中的核心元数据表，用于存储流程的定义信息。该表记录了每个流程的唯一编码、名称、设计器模型类型、版本、发布状态、激活状态等关键属性。作为流程实例化的基础，该表为整个流程引擎提供了配置依据。

该表设计支持多种流程模型（如经典模型和仿钉钉模型），并具备多租户能力，适用于企业级工作流应用。通过该表可以管理流程的生命周期，包括设计、发布、激活/挂起等状态转换。

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql#L1-L29)

## 表结构与字段说明

`flow_definition` 表包含以下字段，用于完整描述一个流程的元数据：

| 字段名 | 数据类型 | 是否为空 | 默认值 | 描述 |
|--------|---------|--------|--------|------|
| id | bigint/int8 | NOT NULL | - | 主键ID，唯一标识一个流程定义 |
| flow_code | nvarchar(40)/varchar(40) | NOT NULL | - | 流程唯一编码，用于程序化引用 |
| flow_name | nvarchar(100)/varchar(100) | NOT NULL | - | 流程名称，用于显示 |
| model_value | nvarchar(40)/varchar(40) | NOT NULL | 'CLASSICS' | 设计器模型类型（CLASSICS经典或MIMIC仿钉钉） |
| category | nvarchar(100)/varchar(100) | NULL | - | 流程类别，用于分类管理 |
| version | nvarchar(20)/varchar(20) | NOT NULL | - | 流程版本号 |
| is_publish | tinyint/int2 | NULL | 0 | 发布状态（0未发布，1已发布） |
| form_custom | nchar(1)/bpchar(1) | NULL | 'N' | 是否自定义表单（Y是，N否） |
| form_path | nvarchar(100)/varchar(100) | NULL | - | 审批表单路径 |
| activity_status | tinyint/int2 | NULL | 1 | 激活状态（0挂起，1激活） |
| listener_type | nvarchar(100)/varchar(100) | NULL | - | 监听器类型 |
| listener_path | nvarchar(400)/varchar(400) | NULL | - | 监听器路径 |
| ext | nvarchar(500)/varchar(500) | NULL | - | 扩展字段，预留给业务系统使用 |
| create_time | datetime2/timestamp | NULL | - | 创建时间 |
| create_by | nvarchar(64)/varchar(64) | NULL | - | 创建人 |
| update_time | datetime2/timestamp | NULL | - | 更新时间 |
| update_by | nvarchar(64)/varchar(64) | NULL | - | 更新人 |
| del_flag | nchar(1)/bpchar(1) | NULL | '0' | 删除标志（0未删除，1已删除） |
| tenant_id | nvarchar(40)/varchar(40) | NULL | - | 租户ID，支持多租户 |

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql#L1-L29)
- [FlowDefinition.java](file://warm-flow-orm/warm-flow-mybatis-plus/warm-flow-mybatis-plus-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowDefinition.java#L35-L145)

## 主键与索引约束

`flow_definition` 表具有以下约束：

- **主键约束**：`id` 字段是主键，确保每条记录的唯一性。在 SQL Server 中定义为 `PK__flow_def__3213E83FEE39AE33`，在 PostgreSQL 中为 `flow_definition_pkey`。
- **唯一性约束**：虽然未在 DDL 中显式定义，但业务逻辑上 `flow_code` 应保证唯一性以确保流程编码的唯一引用。
- **默认值约束**：
  - `model_value` 默认值为 'CLASSICS'
  - `is_publish` 默认值为 0（未发布）
  - `form_custom` 默认值为 'N'（非自定义表单）
  - `activity_status` 默认值为 1（激活状态）
  - `del_flag` 默认值为 '0'（未删除）

**Section sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)
- [postgresql-warm-flow-all.sql](file://sql/postgresql/postgresql-warm-flow-all.sql#L1-L29)

## 外键关系

`flow_definition` 表作为核心定义表，与其他流程相关表存在外键关联：

- **与 `flow_node` 表的关系**：`flow_node.definition_id` 字段外键引用 `flow_definition.id`，表示流程节点属于某个流程定义。
- **与 `flow_skip` 表的关系**：`flow_skip.definition_id` 字段外键引用 `flow_definition.id`，表示跳转规则属于某个流程定义。
- **与 `flow_instance` 表的关系**：`flow_instance.definition_id` 字段外键引用 `flow_definition.id`，表示流程实例基于某个流程定义创建。

这些外键关系确保了流程定义、节点、跳转规则和实例之间的数据一致性。

```mermaid
erDiagram
flow_definition ||--o{ flow_node : "包含"
flow_definition ||--o{ flow_skip : "包含"
flow_definition ||--o{ flow_instance : "生成"
flow_definition {
bigint id PK
varchar(40) flow_code UK
varchar(100) flow_name
varchar(40) model_value
varchar(100) category
varchar(20) version
int2 is_publish
bpchar(1) form_custom
varchar(100) form_path
int2 activity_status
varchar(100) listener_type
varchar(400) listener_path
varchar(500) ext
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_node {
bigint id PK
bigint definition_id FK
int2 node_type
varchar(40) node_code
varchar(100) node_name
varchar(100) permission_flag
int2 node_ratio
varchar(100) coordinate
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_skip {
bigint id PK
bigint definition_id FK
varchar(100) now_node_code
int2 now_node_type
varchar(100) next_node_code
int2 next_node_type
varchar(100) skip_name
varchar(40) skip_type
varchar(200) skip_condition
varchar(100) coordinate
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_instance {
bigint id PK
bigint definition_id FK
varchar(40) business_id
int2 node_type
varchar(40) node_code
varchar(100) node_name
text variable
varchar(20) flow_status
int2 activity_status
text def_json
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
```

**Diagram sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L192-L249)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L362-L411)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L457-L517)

## 字段枚举值说明

### model_value 字段
表示流程设计器的模型类型，支持两种模式：
- **CLASSICS**: 经典模型
- **MIMIC**: 仿钉钉模型

该字段在 `ModelEnum` 枚举类中定义，并在数据库中设置默认值为 'CLASSICS'。

**Section sources**
- [ModelEnum.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/ModelEnum.java#L1-L40)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

### is_publish 字段
表示流程的发布状态，其值含义如下：
- **0**: 未发布（UNPUBLISHED）
- **1**: 已发布（PUBLISHED）
- **9**: 已失效（EXPIRED）

该状态在 `PublishStatus` 枚举类中定义。

**Section sources**
- [PublishStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/PublishStatus.java#L1-L71)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

### activity_status 字段
表示流程的激活状态，其值含义如下：
- **0**: 挂起（SUSPENDED）
- **1**: 激活（ACTIVITY）

该状态在 `ActivityStatus` 枚举类中定义。

**Section sources**
- [ActivityStatus.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/ActivityStatus.java#L1-L55)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

### form_custom 字段
表示审批表单是否自定义，其值含义如下：
- **N**: 非自定义表单
- **Y**: 自定义表单

该类型在 `FormCustomEnum` 枚举类中定义。

**Section sources**
- [FormCustomEnum.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/enums/FormCustomEnum.java#L1-L41)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

## 逻辑删除机制

`flow_definition` 表采用逻辑删除机制，通过 `del_flag` 字段实现：

- **del_flag = '0'**: 记录未删除，正常显示
- **del_flag = '1'**: 记录已删除，从常规查询中隐藏

这种设计避免了物理删除带来的数据丢失风险，同时支持数据恢复。在 MyBatis-Plus 框架中，该字段通过 `@TableLogic` 注解自动处理逻辑删除，查询时自动添加 `del_flag = '0'` 条件，删除操作自动更新 `del_flag` 为 '1'。

**Section sources**
- [FlowDefinition.java](file://warm-flow-orm/warm-flow-mybatis-plus/warm-flow-mybatis-plus-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowDefinition.java#L76-L77)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

## 多租户支持

`flow_definition` 表通过 `tenant_id` 字段支持多租户架构：

- **tenant_id**: 存储租户标识，用于区分不同租户的数据
- 所有查询操作都应包含租户过滤条件，确保数据隔离
- 在框架层面，通过 `TenantHandler` 自动注入当前租户ID，避免业务代码中显式处理租户逻辑

这种设计使得系统能够支持多个独立的组织或客户共享同一套流程定义体系，同时保证数据安全和隔离。

**Section sources**
- [FlowDefinition.java](file://warm-flow-orm/warm-flow-mybatis-plus/warm-flow-mybatis-plus-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowDefinition.java#L65-L66)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

## 使用示例

当创建一个新的流程定义时，典型的插入操作如下：

```sql
INSERT INTO flow_definition (
    id, flow_code, flow_name, model_value, version, 
    is_publish, form_custom, activity_status, 
    create_time, create_by, tenant_id
) VALUES (
    123456789012345, 'LEAVE_PROCESS', '请假流程', 'CLASSICS', '1.0',
    0, 'N', 1,
    '2025-01-01 10:00:00', 'admin', 'tenant_001'
);
```

此操作创建了一个名为"请假流程"的流程定义，使用经典模型，版本为1.0，初始状态为未发布、已激活。系统会自动生成主键ID（通常使用雪花算法），并记录创建时间和创建人。

**Section sources**
- [FlowDefinition.java](file://warm-flow-orm/warm-flow-mybatis-plus/warm-flow-mybatis-plus-core/src/main/java/org/dromara/warm/flow/orm/entity/FlowDefinition.java#L35-L145)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)

## 数据模型图

以下是 `flow_definition` 表及其相关表的完整数据模型图：

```mermaid
erDiagram
flow_definition ||--o{ flow_node : "包含"
flow_definition ||--o{ flow_skip : "包含"
flow_definition ||--o{ flow_instance : "生成"
flow_definition {
bigint id PK
varchar(40) flow_code
varchar(100) flow_name
varchar(40) model_value
varchar(100) category
varchar(20) version
int2 is_publish
bpchar(1) form_custom
varchar(100) form_path
int2 activity_status
varchar(100) listener_type
varchar(400) listener_path
varchar(500) ext
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_node {
bigint id PK
bigint definition_id FK
int2 node_type
varchar(40) node_code
varchar(100) node_name
varchar(100) permission_flag
int2 node_ratio
varchar(100) coordinate
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_skip {
bigint id PK
bigint definition_id FK
varchar(100) now_node_code
int2 now_node_type
varchar(100) next_node_code
int2 next_node_type
varchar(100) skip_name
varchar(40) skip_type
varchar(200) skip_condition
varchar(100) coordinate
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
flow_instance {
bigint id PK
bigint definition_id FK
varchar(40) business_id
int2 node_type
varchar(40) node_code
varchar(100) node_name
text variable
varchar(20) flow_status
int2 activity_status
text def_json
timestamp create_time
varchar(64) create_by
timestamp update_time
varchar(64) update_by
bpchar(1) del_flag
varchar(40) tenant_id
}
```

**Diagram sources**
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L1-L45)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L192-L249)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L362-L411)
- [sqlserver.sql](file://sql/sqlserver/sqlserver.sql#L457-L517)
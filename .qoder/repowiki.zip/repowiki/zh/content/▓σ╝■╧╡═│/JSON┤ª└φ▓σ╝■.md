# JSON处理插件

<cite>
**本文档引用的文件**   
- [JsonConvert.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/json/JsonConvert.java)
- [JsonConvertFastJson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertFastJson.java)
- [JsonConvertGson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertGson.java)
- [JsonConvertJackson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertJackson.java)
- [JsonConvertSnack.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertSnack.java)
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-json/pom.xml)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java)
</cite>

## 目录
1. [核心接口定义](#核心接口定义)
2. [SPI服务发现机制](#spi服务发现机制)
3. [四种JSON库实现](#四种json库实现)
4. [可选依赖设计](#可选依赖设计)
5. [运行时实现选择](#运行时实现选择)
6. [总结](#总结)

## 核心接口定义

`JsonConvert`接口定义了JSON序列化与反序列化的核心方法，为系统提供了统一的JSON处理契约。该接口位于`warm-flow-core`模块中，作为所有JSON实现的基础规范。

**Section sources**
- [JsonConvert.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/json/JsonConvert.java#L26-L61)

## SPI服务发现机制

系统通过Java的SPI（Service Provider Interface）机制实现JSON转换器的动态加载。`ServiceLoaderUtil`工具类封装了SPI加载逻辑，`WarmFlow`配置类在初始化时调用`spiLoad()`方法，通过`ServiceLoaderUtil.loadFirst(JsonConvert.class)`加载第一个可用的`JsonConvert`实现，并将其赋值给`FlowEngine.jsonConvert`静态字段。

```mermaid
sequenceDiagram
participant WarmFlow as WarmFlow配置类
participant ServiceLoaderUtil as ServiceLoaderUtil工具类
participant FlowEngine as FlowEngine引擎
participant JsonConvert as JsonConvert实现
WarmFlow->>ServiceLoaderUtil : spiLoad()
ServiceLoaderUtil->>ServiceLoaderUtil : loadFirst(JsonConvert.class)
ServiceLoaderUtil->>JsonConvert : 加载第一个可用实现
JsonConvert-->>ServiceLoaderUtil : 返回实现实例
ServiceLoaderUtil-->>WarmFlow : 返回实现实例
WarmFlow->>FlowEngine : 设置jsonConvert字段
```

**Diagram sources**
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L138-L140)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java#L36-L45)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java#L69)

**Section sources**
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L133-L140)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java#L36-L45)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java#L69)

## 四种JSON库实现

`warm-flow-plugin-json`模块提供了四种`JsonConvert`接口的具体实现，分别对应不同的JSON处理库：

### FastJson实现
`JsonConvertFastJson`使用阿里巴巴的Fastjson2库实现JSON转换，通过`JSON.parseObject`和`JSON.toJSONString`方法完成序列化与反序列化操作。

### Gson实现
`JsonConvertGson`使用Google的Gson库实现JSON转换，通过`Gson.fromJson`和`Gson.toJson`方法完成序列化与反序列化操作。

### Jackson实现
`JsonConvertJackson`使用Fasterxml的Jackson库实现JSON转换，通过`ObjectMapper`的`readValue`和`writeValueAsString`方法完成序列化与反序列化操作，并配置了忽略未知属性等特性。

### Snack3实现
`JsonConvertSnack`使用Snack3库实现JSON转换，通过`ONode.deserialize`和`ONode.stringify`方法完成序列化与反序列化操作。特别地，该实现包含一个静态`ONode`字段，用于在SPI加载时触发类加载异常，从而避免在缺少Snack3依赖时加载此实现类。

```mermaid
classDiagram
class JsonConvert {
<<interface>>
+strToMap(String) Map~String, Object~
+strToBean(String, Class~T~) T
+strToList(String) T[]
+objToStr(Object) String
}
class JsonConvertFastJson {
-JSON
+strToMap(String) Map~String, Object~
+strToBean(String, Class~T~) T
+strToList(String) T[]
+objToStr(Object) String
}
class JsonConvertGson {
-GSON
+strToMap(String) Map~String, Object~
+strToBean(String, Class~T~) T
+strToList(String) T[]
+objToStr(Object) String
}
class JsonConvertJackson {
-OBJECT_MAPPER
-log
+strToMap(String) Map~String, Object~
+strToBean(String, Class~T~) T
+strToList(String) T[]
+objToStr(Object) String
}
class JsonConvertSnack {
-O_NODE
+strToMap(String) Map~String, Object~
+strToBean(String, Class~T~) T
+strToList(String) T[]
+objToStr(Object) String
}
JsonConvert <|-- JsonConvertFastJson
JsonConvert <|-- JsonConvertGson
JsonConvert <|-- JsonConvertJackson
JsonConvert <|-- JsonConvertSnack
```

**Diagram sources**
- [JsonConvertFastJson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertFastJson.java#L34-L95)
- [JsonConvertGson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertGson.java#L35-L99)
- [JsonConvertJackson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertJackson.java#L41-L127)
- [JsonConvertSnack.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertSnack.java#L35-L90)
- [JsonConvert.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/json/JsonConvert.java#L26-L61)

**Section sources**
- [JsonConvertFastJson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertFastJson.java#L34-L95)
- [JsonConvertGson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertGson.java#L35-L99)
- [JsonConvertJackson.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertJackson.java#L41-L127)
- [JsonConvertSnack.java](file://warm-flow-plugin/warm-flow-plugin-json/src/main/java/org/dromara/warm/plugin/json/JsonConvertSnack.java#L35-L90)

## 可选依赖设计

`warm-flow-plugin-json`模块的`pom.xml`文件中，将所有JSON库声明为`optional`依赖，这种设计具有重要的架构意义：

```xml
<dependency>
    <groupId>com.alibaba.fastjson2</groupId>
    <artifactId>fastjson2</artifactId>
    <optional>true</optional>
</dependency>
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <optional>true</optional>
</dependency>
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <optional>true</optional>
</dependency>
<dependency>
    <groupId>org.noear</groupId>
    <artifactId>snack3</artifactId>
    <optional>true</optional>
</dependency>
```

这种设计意图在于：
1. **避免强制依赖**：使用`warm-flow-plugin-json`模块的应用不会强制引入任何特定的JSON库
2. **按需引入**：用户可以根据项目需求选择引入Fastjson、Gson、Jackson或Snack3中的任意一个或多个
3. **减少冲突**：避免了不同JSON库版本冲突的问题，特别是在大型项目中
4. **轻量化**：确保核心功能不依赖于特定的第三方库，保持系统的轻量化

**Diagram sources**
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-json/pom.xml#L22-L44)

**Section sources**
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-json/pom.xml#L22-L44)

## 运行时实现选择

在运行时，系统根据classpath中可用的JSON库自动选择最优实现。这一过程通过SPI机制完成：

1. 应用启动时，`WarmFlow`配置类调用`spiLoad()`方法
2. `ServiceLoaderUtil.loadFirst(JsonConvert.class)`方法扫描classpath中的`META-INF/services/org.dromara.warm.flow.core.json.JsonConvert`文件
3. 按照类路径中找到的实现类顺序，尝试加载第一个可用的实现
4. 加载成功的实现被赋值给`FlowEngine.jsonConvert`，后续所有JSON操作都通过此实例完成

这种机制确保了系统的灵活性：用户只需在项目中引入所需的JSON库及其对应的SPI配置，系统就能自动使用该库进行JSON处理，而无需修改任何代码。

```mermaid
flowchart TD
Start([应用启动]) --> WarmFlow["WarmFlow配置类初始化"]
WarmFlow --> spiLoad["调用spiLoad()方法"]
spiLoad --> ServiceLoaderUtil["ServiceLoaderUtil.loadFirst()"]
ServiceLoaderUtil --> ScanSPI["扫描META-INF/services/"]
ScanSPI --> FindImplementations["查找JsonConvert实现"]
FindImplementations --> TryLoad["尝试加载第一个实现"]
TryLoad --> Success{"加载成功?"}
Success --> |是| SetInstance["设置FlowEngine.jsonConvert"]
Success --> |否| TryNext["尝试下一个实现"]
TryNext --> Success
SetInstance --> Ready["系统准备就绪"]
Ready --> End([JSON处理可用])
```

**Diagram sources**
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L138-L140)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java#L36-L45)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java#L69)

**Section sources**
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L133-L140)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java#L36-L45)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java#L69)

## 总结

`warm-flow-plugin-json`模块通过精巧的设计实现了JSON处理的灵活性和可扩展性。核心的`JsonConvert`接口定义了统一的JSON操作契约，四种具体实现分别对接不同的JSON库，而`optional`依赖设计则确保了用户可以按需引入特定的JSON库。通过SPI服务发现机制，系统能够在运行时自动选择并加载可用的JSON实现，这种设计既保证了系统的轻量化，又提供了极大的灵活性，使用户可以根据具体需求选择最适合的JSON处理方案。

**Section sources**
- [JsonConvert.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/json/JsonConvert.java#L26-L61)
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-json/pom.xml#L22-L44)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L138-L140)
- [ServiceLoaderUtil.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/utils/ServiceLoaderUtil.java#L36-L45)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java#L69)
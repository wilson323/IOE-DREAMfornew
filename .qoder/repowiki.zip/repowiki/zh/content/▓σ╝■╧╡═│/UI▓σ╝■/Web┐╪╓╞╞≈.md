# Web控制器层设计与实现

<cite>
**本文档引用的文件**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java)
- [WarmFlowUiConfig.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/config/WarmFlowUiConfig.java)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java)
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java)
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java)
</cite>

## 目录
1. [概述](#概述)
2. [项目架构](#项目架构)
3. [控制器层设计](#控制器层设计)
4. [WarmFlowUiController分析](#warmflowuicontroller分析)
5. [WarmFlowController分析](#warmflowcontroller分析)
6. [框架实现差异对比](#框架实现差异对比)
7. [配置管理](#配置管理)
8. [API接口详解](#api接口详解)
9. [响应结构设计](#响应结构设计)
10. [安全性和版本控制](#安全性和版本控制)
11. [前端集成方式](#前端集成方式)
12. [最佳实践建议](#最佳实践建议)

## 概述

WarmFlow的Web控制器层采用分层架构设计，提供了完整的REST API接口，支持Spring Boot和Solon两个主流Java框架。控制器层负责处理HTTP请求、验证参数、调用业务服务层，并返回标准化的JSON响应。

核心特性包括：
- 统一的API响应格式
- 分离的UI控制器和业务控制器
- 支持多种框架适配
- 完整的流程设计器API
- 灵活的权限管理系统

## 项目架构

```mermaid
graph TB
subgraph "前端层"
UI[Vue3前端界面]
API[API调用层]
end
subgraph "控制器层"
WFC[WarmFlowController<br/>业务API]
WFUC[WarmFlowUiController<br/>UI配置API]
WC[WarmFlowConfig<br/>配置管理]
end
subgraph "服务层"
WS[WarmFlowService<br/>业务逻辑]
HS[HandlerService<br/>权限服务]
FS[FormService<br/>表单服务]
end
subgraph "数据层"
DB[(数据库)]
CACHE[(缓存)]
end
UI --> API
API --> WFC
API --> WFUC
WFC --> WS
WFUC --> WS
WS --> HS
WS --> FS
WS --> DB
WS --> CACHE
WC --> WFUC
```

**图表来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L41-L210)
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L30-L45)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L46-L356)

## 控制器层设计

WarmFlow控制器层采用职责分离原则，分为两个主要控制器：

### 控制器分类

1. **WarmFlowUiController** - UI配置控制器
   - 提供设计器基础配置
   - 处理匿名访问请求
   - 配置静态资源映射

2. **WarmFlowController** - 业务控制器  
   - 提供完整的业务API
   - 处理事务管理
   - 支持复杂的业务流程

### 设计原则

- **统一响应格式**：所有API返回标准的`ApiResult`格式
- **异常处理**：全局异常捕获和标准化错误响应
- **参数验证**：严格的输入参数验证
- **安全控制**：基于框架的安全机制

**章节来源**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L30-L45)
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L41-L210)

## WarmFlowUiController分析

WarmFlowUiController是专门用于UI配置的控制器，提供设计器的基础配置信息。

### 类结构设计

```mermaid
classDiagram
class WarmFlowUiController {
+ApiResult~WarmFlowVo~ config()
}
class WarmFlowService {
+ApiResult~WarmFlowVo~ config()
}
class WarmFlowVo {
+String[] tokenNameList
}
class ApiResult~T~ {
+int code
+String msg
+T data
+static ApiResult~T~ ok(T data)
+static ApiResult~T~ fail(String msg)
}
WarmFlowUiController --> WarmFlowService : "调用"
WarmFlowService --> WarmFlowVo : "返回"
WarmFlowService --> ApiResult~T~ : "包装"
```

**图表来源**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L30-L45)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L48-L67)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java#L32-L40)

### 核心功能

#### `/warm-flow-ui/config` 接口

**功能描述**：获取流程设计器的配置信息，主要用于权限令牌配置。

**请求方法**：`GET`

**请求路径**：`/warm-flow-ui/config`

**响应结构**：
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "tokenNameList": ["Authorization", "token", "jwt"]
  }
}
```

**业务逻辑**：
1. 调用`WarmFlowService.config()`方法
2. 获取WarmFlow配置中的tokenName
3. 解析逗号分隔的token名称列表
4. 过滤空值并返回给前端

**错误处理**：
- tokenName未配置时返回失败响应
- 系统异常时抛出FlowException

**章节来源**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L39-L42)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L48-L67)

## WarmFlowController分析

WarmFlowController是核心业务控制器，提供完整的流程管理API。

### 接口分类

```mermaid
graph LR
subgraph "流程管理"
A[保存流程定义]
B[获取流程定义]
C[获取流程图]
end
subgraph "表单管理"
D[读取表单内容]
E[保存表单内容]
F[已发布表单列表]
end
subgraph "任务处理"
G[加载待办任务]
H[加载已办任务]
I[处理任务]
end
subgraph "权限管理"
J[办理人类型]
K[办理人结果]
L[办理人反馈]
M[办理人字典]
end
subgraph "扩展功能"
N[节点扩展属性]
end
```

**图表来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L208)

### 主要接口详解

#### 1. 流程定义管理

**保存流程定义** (`POST /warm-flow/save-json`)
- **功能**：保存流程定义的JSON数据
- **参数**：`DefJson`对象和`onlyNodeSkip`头部参数
- **事务**：支持回滚的事务管理

**获取流程定义** (`GET /warm-flow/query-def`)
- **功能**：获取流程定义数据
- **参数**：可选的流程ID
- **重载**：支持路径变量和无参数调用

**获取流程图** (`GET /warm-flow/query-flow-chart/{id}`)
- **功能**：获取流程实例的可视化图表
- **参数**：流程实例ID
- **扩展**：支持自定义图表颜色和提示内容

#### 2. 表单管理

**读取表单内容** (`GET /warm-flow/form-content/{id}`)
- **功能**：获取指定表单的内容
- **参数**：表单ID
- **用途**：设计器预览和编辑

**保存表单内容** (`POST /warm-flow/form-content`)
- **功能**：保存表单内容到数据库
- **参数**：`FlowDto`对象
- **事务**：自动事务管理

**已发布表单列表** (`GET /warm-flow/published-form`)
- **功能**：获取所有已发布的表单
- **用途**：流程定义时的表单选择

#### 3. 任务处理

**加载待办任务** (`GET /warm-flow/execute/load/{taskId}`)
- **功能**：加载指定任务的表单数据
- **参数**：任务ID
- **用途**：用户审批页面的数据准备

**通用任务处理** (`POST /warm-flow/execute/handle`)
- **功能**：处理任务审批
- **参数**：表单数据、任务ID、跳转类型、消息等
- **事务**：支持复杂业务流程的事务控制

#### 4. 权限管理

**办理人类型** (`GET /warm-flow/handler-type`)
- **功能**：获取可用的办理人类型列表
- **用途**：权限设置界面的选项

**办理人结果查询** (`GET /warm-flow/handler-result`)
- **功能**：根据查询条件获取办理人列表
- **参数**：`HandlerQuery`对象
- **分页**：支持分页查询

**办理人反馈** (`GET /warm-flow/handler-feedback`)
- **功能**：根据ID列表获取办理人名称
- **参数**：`HandlerFeedBackDto`对象
- **用途**：权限设置后的结果显示

**办理人字典** (`GET /warm-flow/handler-dict`)
- **功能**：获取办理人表达式字典
- **用途**：权限表达式的帮助信息

#### 5. 扩展功能

**节点扩展属性** (`GET /warm-flow/node-ext`)
- **功能**：获取节点的扩展属性配置
- **用途**：自定义节点属性的配置

**章节来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L208)

## 框架实现差异对比

WarmFlow支持Spring Boot和Solon两个框架，两者在控制器实现上存在显著差异。

### 注解体系对比

| 特性 | Spring Boot | Solon |
|------|-------------|-------|
| 控制器注解 | `@RestController` | `@Controller` |
| 路径映射 | `@RequestMapping` | `@Mapping` |
| 方法映射 | `@GetMapping`/`@PostMapping` | `@Get`/`@Post` |
| 参数绑定 | `@RequestParam`/`@PathVariable` | `@Param`/`@Path` |
| 事务管理 | `@Transactional` | `@Tran` |

### 路由注册方式

#### Spring Boot实现
```java
@RestController
@RequestMapping("/warm-flow-ui")
public class WarmFlowUiController {
    @GetMapping("/config")
    public ApiResult<WarmFlowVo> config() {
        return WarmFlowService.config();
    }
}
```

#### Solon实现
```java
@Controller
@Mapping("/warm-flow-ui")
public class WarmFlowUiController {
    @Get
    @Mapping("/config")
    public ApiResult<WarmFlowVo> config() {
        return WarmFlowService.config();
    }
}
```

### 配置注册差异

#### Spring Boot配置
```java
@Configuration
@ConditionalOnProperty(value = "warm-flow.ui", havingValue = "true", matchIfMissing = true)
@Import({WarmFlowUiController.class, WarmFlowController.class})
public class WarmFlowUiConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/warm-flow-ui/**")
            .addResourceLocations("classpath:/META-INF/resources/warm-flow-ui/", "classpath:/warm-flow-ui/");
    }
}
```

#### Solon配置
```java
public class XPluginImpl implements Plugin {
    @Override
    public void start(AppContext context) {
        context.beanScan(XPluginImpl.class);
        WarmFlow warmFlow = Solon.context().getBean(WarmFlow.class);
        if (warmFlow.isUi()) {
            StaticMappings.add("/warm-flow-ui/",
                new ClassPathStaticRepository("/META-INF/resources/warm-flow-ui/"));
        }
    }
}
```

### 实现差异总结

| 方面 | Spring Boot | Solon |
|------|-------------|-------|
| 启动方式 | 自动扫描+注解驱动 | 插件机制+手动注册 |
| 路由注册 | 注解声明 | 编程式注册 |
| 静态资源 | WebMvcConfigurer | StaticMappings |
| 依赖注入 | Spring容器 | Solon容器 |
| 生命周期 | Spring生命周期 | Solon生命周期 |

**章节来源**
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L30-L45)
- [WarmFlowUiController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java#L30-L46)
- [WarmFlowUiConfig.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/config/WarmFlowUiConfig.java#L31-L43)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java#L33-L42)

## 配置管理

WarmFlow的配置管理分为静态资源配置和跨域支持配置。

### 静态资源映射

#### Spring Boot配置
WarmFlowUiConfig类实现了WebMvcConfigurer接口，提供静态资源映射：

```java
@Override
public void addResourceHandlers(ResourceHandlerRegistry registry) {
    registry.addResourceHandler("/warm-flow-ui/**")
        .addResourceLocations("classpath:/META-INF/resources/warm-flow-ui/", "classpath:/warm-flow-ui/");
}
```

**映射规则**：
- 访问路径：`/warm-flow-ui/**`
- 资源位置1：`classpath:/META-INF/resources/warm-flow-ui/`
- 资源位置2：`classpath:/warm-flow-ui/`

#### Solon配置
XPluginImpl类通过编程方式注册静态资源：

```java
if (warmFlow.isUi()) {
    StaticMappings.add("/warm-flow-ui/",
        new ClassPathStaticRepository("/META-INF/resources/warm-flow-ui/"));
}
```

### 跨域支持

虽然当前配置中没有显式配置CORS，但可以通过以下方式实现：

#### Spring Boot跨域配置
```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/warm-flow/**")
            .allowedOrigins("*")
            .allowedMethods("GET", "POST", "PUT", "DELETE")
            .allowedHeaders("*");
    }
}
```

#### Solon跨域配置
```java
@ServerEndpoint
public class GlobalFilter implements Filter {
    @Override
    public void doFilter(Context ctx, FilterChain chain) throws Throwable {
        ctx.headerSet("Access-Control-Allow-Origin", "*");
        ctx.headerSet("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
        ctx.headerSet("Access-Control-Allow-Headers", "*");
        chain.doFilter(ctx);
    }
}
```

### 配置文件示例

#### application.yml (Spring Boot)
```yaml
warm-flow:
  ui: true
  token-name: Authorization,token,jwt
  top-text-show: true
```

#### solon.properties (Solon)
```properties
warm-flow.ui=true
warm-flow.token-name=Authorization,token,jwt
warm-flow.top-text-show=true
```

**章节来源**
- [WarmFlowUiConfig.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/config/WarmFlowUiConfig.java#L36-L43)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java#L37-L42)

## API接口详解

WarmFlow提供了丰富的REST API接口，涵盖流程管理、表单管理、任务处理和权限管理等多个方面。

### 接口契约规范

#### 统一响应格式
所有API都返回标准的`ApiResult<T>`格式：

```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {}
}
```

#### 错误码设计
- **200**: 操作成功
- **500**: 操作失败（系统异常）
- **自定义错误码**: 业务异常时使用

### 核心接口列表

| 接口路径 | 方法 | 功能描述 | 请求参数 | 响应数据 |
|----------|------|----------|----------|----------|
| `/warm-flow-ui/config` | GET | 获取UI配置 | 无 | WarmFlowVo |
| `/warm-flow/save-json` | POST | 保存流程定义 | DefJson + onlyNodeSkip | Void |
| `/warm-flow/query-def` | GET | 获取流程定义 | id (可选) | DefJson |
| `/warm-flow/query-flow-chart/{id}` | GET | 获取流程图 | id | DefJson |
| `/warm-flow/handler-type` | GET | 获取办理人类型 | 无 | List<String> |
| `/warm-flow/handler-result` | GET | 获取办理人结果 | HandlerQuery | HandlerSelectVo |
| `/warm-flow/handler-feedback` | GET | 办理人反馈 | HandlerFeedBackDto | List<HandlerFeedBackVo> |
| `/warm-flow/handler-dict` | GET | 办理人字典 | 无 | List<Dict> |
| `/warm-flow/published-form` | GET | 已发布表单列表 | 无 | List<Form> |
| `/warm-flow/form-content/{id}` | GET | 读取表单内容 | id | String |
| `/warm-flow/form-content` | POST | 保存表单内容 | FlowDto | Void |
| `/warm-flow/execute/load/{taskId}` | GET | 加载待办任务 | taskId | FlowDto |
| `/warm-flow/execute/handle` | POST | 处理任务 | FormData + 其他参数 | Instance |
| `/warm-flow/node-ext` | GET | 节点扩展属性 | 无 | List<NodeExt> |

### 接口调用时序图

#### 流程定义保存流程
```mermaid
sequenceDiagram
participant Frontend as 前端应用
participant Controller as WarmFlowController
participant Service as WarmFlowService
participant Engine as FlowEngine
participant DB as 数据库
Frontend->>Controller : POST /warm-flow/save-json
Controller->>Controller : 参数验证
Controller->>Service : saveJson(defJson, onlyNodeSkip)
Service->>Engine : defService().saveDef(defJson, onlyNodeSkip)
Engine->>DB : 保存流程定义
DB-->>Engine : 保存结果
Engine-->>Service : 操作结果
Service-->>Controller : ApiResult
Controller-->>Frontend : JSON响应
Note over Frontend,DB : 支持onlyNodeSkip头部参数
```

**图表来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L54-L58)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L79-L82)

#### 办理人权限查询流程
```mermaid
sequenceDiagram
participant Frontend as 前端应用
participant Controller as WarmFlowController
participant Service as WarmFlowService
participant HandlerService as HandlerSelectService
participant Business as 业务系统
Frontend->>Controller : GET /warm-flow/handler-result
Controller->>Controller : HandlerQuery参数解析
Controller->>Service : handlerResult(query)
Service->>Service : 获取HandlerSelectService
Service->>HandlerService : getHandlerSelect(query)
HandlerService->>Business : 查询业务数据
Business-->>HandlerService : 返回结果
HandlerService-->>Service : HandlerSelectVo
Service-->>Controller : ApiResult<HandlerSelectVo>
Controller-->>Frontend : JSON响应
Note over Frontend,Business : 支持分页和条件查询
```

**图表来源**
- [WarmFlowController.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowController.java#L99-L102)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L178-L187)

### 参数验证和错误处理

#### HandlerQuery参数验证
```java
public class HandlerQuery {
    private String handlerCode;      // 权限编码
    private String handlerName;      // 权限名称
    private String handlerType;      // 办理权限类型
    private String groupId;          // 树权限分组主键
    private Integer pageNum;         // 当前页码
    private Integer pageSize;        // 每页条数
    private String beginTime;        // 开始时间
    private String endTime;          // 结束时间
}
```

#### 错误处理策略
1. **参数验证**：使用框架内置验证机制
2. **业务异常**：捕获并转换为FlowException
3. **系统异常**：全局异常处理器处理
4. **响应格式**：统一的ApiResult格式

**章节来源**
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java#L31-L72)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L33-L97)

## 响应结构设计

WarmFlow采用统一的响应结构设计，确保前后端交互的一致性和可靠性。

### ApiResult统一响应格式

```mermaid
classDiagram
class ApiResult~T~ {
-int code
-String msg
-T data
+static ApiResult~T~ ok()
+static ApiResult~T~ ok(T data)
+static ApiResult~T~ ok(T data, String msg)
+static ApiResult~T~ fail()
+static ApiResult~T~ fail(String msg)
+static ApiResult~T~ fail(int code, String msg)
+static Boolean isSuccess(ApiResult~T~ ret)
+static Boolean isError(ApiResult~T~ ret)
}
class WarmFlowVo {
-String[] tokenNameList
}
class HandlerSelectVo {
-FlowPage~HandlerAuth~ handlerAuths
-Tree[] treeSelections
}
class Dict {
-String label
-String value
-Dict[] childList
}
ApiResult~T~ --> WarmFlowVo : "包装"
ApiResult~T~ --> HandlerSelectVo : "包装"
ApiResult~T~ --> Dict : "包装"
```

**图表来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L28-L97)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java#L32-L40)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java#L35-L47)

### 响应状态码

| 状态码 | 含义 | 使用场景 |
|--------|------|----------|
| 200 | 成功 | 操作成功完成 |
| 500 | 失败 | 系统内部错误 |
| 自定义 | 业务错误 | 业务逻辑验证失败 |

### 响应数据类型

#### 1. 基础配置响应
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "tokenNameList": ["Authorization", "token", "jwt"]
  }
}
```

#### 2. 流程定义响应
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "modelValue": "CLASSICS",
    "formCustom": "N",
    "nodes": [...],
    "skips": [...]
  }
}
```

#### 3. 办理人权限响应
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "handlerAuths": {
      "records": [
        {
          "id": "user:123",
          "name": "张三",
          "type": "USER"
        }
      ],
      "total": 100,
      "size": 10,
      "current": 1
    },
    "treeSelections": [
      {
        "id": "dept:1",
        "label": "技术部",
        "children": [...]
      }
    ]
  }
}
```

#### 4. 字典数据响应
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": [
    {
      "label": "默认表达式",
      "value": "${handler}",
      "childList": []
    },
    {
      "label": "SPeL表达式",
      "value": "#{@user.evalVar(#handler)}",
      "childList": []
    }
  ]
}
```

### 响应构建模式

#### 成功响应构建
```java
// 简单成功
return ApiResult.ok();

// 带数据的成功
return ApiResult.ok(data);

// 自定义消息的成功
return ApiResult.ok(data, "自定义成功消息");
```

#### 失败响应构建
```java
// 简单失败
return ApiResult.fail();

// 带数据的失败
return ApiResult.fail(data);

// 自定义消息的失败
return ApiResult.fail("自定义错误消息");

// 自定义状态码的失败
return ApiResult.fail(500, "自定义错误消息");
```

**章节来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L49-L97)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L48-L67)

## 安全性和版本控制

### 安全性设计

#### 1. 权限令牌配置
WarmFlow通过配置文件管理API访问权限：

```yaml
warm-flow:
  token-name: Authorization,token,jwt
```

**作用**：
- 支持多令牌名称
- 灵活的认证方式
- 与业务系统权限集成

#### 2. 匿名访问控制
WarmFlowUiController设计为匿名访问，适用于：
- UI配置获取
- 静态资源访问
- 基础配置信息

#### 3. 业务访问控制
WarmFlowController需要业务系统实现权限控制：
- HandlerSelectService接口
- HandlerDictService接口
- NodeExtService接口

### 版本控制策略

#### API版本管理
目前采用路径版本控制：

```
/warm-flow-ui/v1/config
/warm-flow/v1/save-json
```

#### 向后兼容性
- 新增字段使用可选参数
- 废弃功能标记为过时
- 提供迁移指南

### 错误码设计

#### 系统级错误码
```java
public static final int SUCCESS = 200;
public static final int FAIL = 500;
```

#### 业务级错误码
```java
// 自定义错误码示例
public static ApiResult fail(int code, String msg) {
    return restResult(null, code, msg);
}
```

#### 错误处理流程
```mermaid
flowchart TD
Start([请求开始]) --> Validate[参数验证]
Validate --> ValidOK{验证通过?}
ValidOK --> |否| ParamError[参数错误]
ValidOK --> |是| Business[业务处理]
Business --> BusinessOK{业务成功?}
BusinessOK --> |否| BusinessError[业务异常]
BusinessOK --> |是| Success[成功响应]
ParamError --> ErrorResponse[错误响应]
BusinessError --> ErrorResponse
Success --> End([响应结束])
ErrorResponse --> End
```

**图表来源**
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L33-L41)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L116-L120)

**章节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L53-L67)
- [ApiResult.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/dto/ApiResult.java#L33-L97)

## 前端集成方式

WarmFlow提供了完整的前端集成方案，支持Vue3前端界面的无缝对接。

### 前端API调用层

#### 1. API模块组织
前端采用模块化的方式组织API调用：

```
src/
├── api/
│   ├── flow/
│   │   └── definition.js      # 流程定义API
│   ├── form/
│   │   └── form.js           # 表单API
│   └── anony.js             # 匿名访问API
```

#### 2. 请求封装
前端使用统一的请求封装：

```javascript
// 基础请求函数
import request from '@/utils/request'

const urlPrefix = import.meta.env.VITE_URL_PREFIX

export function config() {
  return request({
    url: urlPrefix + 'warm-flow-ui/config',
    method: 'get'
  })
}
```

#### 3. 接口调用示例

##### 流程定义管理
```javascript
// 保存流程定义
export function saveJson(data, onlyNodeSkip) {
  return request({
    url: urlPrefix + 'warm-flow/save-json',
    method: 'post',
    data: data,
    headers: {
      'onlyNodeSkip': onlyNodeSkip
    }
  })
}

// 获取流程定义
export function queryDef(id) {
  if (id) {
    id = '/' + id
  } else {
    id = ''
  }
  return request({
    url: urlPrefix + 'warm-flow/query-def' + id,
    method: 'get'
  })
}
```

##### 办理人权限管理
```javascript
// 获取办理人类型
export function handlerType() {
  return request({
    url: urlPrefix + 'warm-flow/handler-type',
    method: 'get',
  })
}

// 获取办理人结果
export function handlerResult(query) {
  return request({
    url: urlPrefix + 'warm-flow/handler-result',
    method: 'get',
    params: query
  })
}

// 办理人反馈
export function handlerFeedback(query) {
  return request({
    url: urlPrefix + 'warm-flow/handler-feedback',
    method: 'get',
    params: query
  })
}
```

### 前端组件集成

#### 1. Vue3组件设计
```vue
<template>
  <div class="workflow-designer">
    <!-- 流程设计器 -->
    <flow-designer 
      :config="designerConfig"
      :handlers="handlerTypes"
      @save="handleSave"
      @load="handleLoad"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { config, handlerType } from '@/api/anony'
import { queryDef, saveJson } from '@/api/flow/definition'

const designerConfig = ref({})
const handlerTypes = ref([])

// 初始化配置
onMounted(async () => {
  const configRes = await config()
  const handlerRes = await handlerType()
  
  designerConfig.value = configRes.data
  handlerTypes.value = handlerRes.data
})
</script>
```

#### 2. 状态管理
前端使用Pinia进行状态管理：

```javascript
// store/designer.js
import { defineStore } from 'pinia'
import { queryDef, saveJson } from '@/api/flow/definition'

export const useDesignerStore = defineStore('designer', {
  state: () => ({
    currentFlow: null,
    flowList: [],
    loading: false
  }),
  
  actions: {
    async loadFlow(id) {
      this.loading = true
      try {
        const res = await queryDef(id)
        this.currentFlow = res.data
        return res
      } finally {
        this.loading = false
      }
    },
    
    async saveFlow(data, onlyNodeSkip = false) {
      return await saveJson(data, onlyNodeSkip)
    }
  }
})
```

### 集成最佳实践

#### 1. 错误处理
```javascript
// 统一错误处理
import { ElMessage } from 'element-plus'

try {
  const res = await saveJson(flowData, false)
  ElMessage.success('保存成功')
} catch (error) {
  ElMessage.error(error.message || '保存失败')
}
```

#### 2. 加载状态
```javascript
// 在组件中使用loading状态
const loading = ref(false)

async function handleSave() {
  loading.value = true
  try {
    await saveJson(flowData, false)
  } finally {
    loading.value = false
  }
}
```

#### 3. 数据验证
```javascript
// 前端数据验证
function validateFlowData(data) {
  if (!data.nodes || data.nodes.length === 0) {
    throw new Error('至少需要一个节点')
  }
  
  if (!data.skips || data.skips.length === 0) {
    throw new Error('至少需要一个跳转')
  }
  
  return true
}
```

**章节来源**
- [definition.js](file://warm-flow-ui/src/api/flow/definition.js#L1-L86)
- [anony.js](file://warm-flow-ui/src/api/anony.js#L1-L13)

## 最佳实践建议

### 1. 控制器设计原则

#### 单一职责原则
每个控制器专注于特定的功能领域：
- WarmFlowUiController：UI配置和静态资源
- WarmFlowController：业务流程管理

#### 参数验证
```java
// 使用注解进行参数验证
@GetMapping("/handler-result")
public ApiResult<HandlerSelectVo> handlerResult(
    @Valid HandlerQuery query,
    BindingResult result) {
    
    if (result.hasErrors()) {
        return ApiResult.fail("参数验证失败：" + result.getAllErrors());
    }
    return WarmFlowService.handlerResult(query);
}
```

### 2. 异常处理策略

#### 全局异常处理
```java
@ControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(FlowException.class)
    public ApiResult<?> handleFlowException(FlowException ex) {
        return ApiResult.fail(ex.getMessage());
    }
    
    @ExceptionHandler(Exception.class)
    public ApiResult<?> handleException(Exception ex) {
        log.error("系统异常", ex);
        return ApiResult.fail("系统异常，请稍后重试");
    }
}
```

### 3. 性能优化

#### 1. 缓存策略
```java
@Cacheable(value = "flow:definition", key = "#id")
public ApiResult<DefJson> queryDef(Long id) {
    // 查询逻辑
}
```

#### 2. 分页查询
```java
@GetMapping("/handler-result")
public ApiResult<HandlerSelectVo> handlerResult(
    @RequestParam(defaultValue = "1") int pageNum,
    @RequestParam(defaultValue = "10") int pageSize,
    HandlerQuery query) {
    
    query.setPageNum(pageNum);
    query.setPageSize(pageSize);
    return WarmFlowService.handlerResult(query);
}
```

### 4. 安全最佳实践

#### 1. 输入过滤
```java
@PostMapping("/save-json")
public ApiResult<Void> saveJson(@RequestBody DefJson defJson) {
    // 过滤危险字符
    defJson.setNodes(filterDangerousNodes(defJson.getNodes()));
    return WarmFlowService.saveJson(defJson, false);
}
```

#### 2. 权限检查
```java
@GetMapping("/handler-result")
public ApiResult<HandlerSelectVo> handlerResult(HandlerQuery query) {
    // 检查用户权限
    if (!permissionService.hasPermission(currentUser(), "flow:handler:view")) {
        return ApiResult.fail("无权限访问");
    }
    return WarmFlowService.handlerResult(query);
}
```

### 5. 监控和日志

#### 1. 请求日志
```java
@Aspect
@Component
public class RequestLoggingAspect {
    
    @Around("execution(* org.dromara.warm.flow..*.*(..))")
    public Object logRequest(ProceedingJoinPoint joinPoint) throws Throwable {
        // 记录请求信息
        log.info("Request: {} {}", 
                 joinPoint.getSignature().getName(),
                 Arrays.toString(joinPoint.getArgs()));
        
        long startTime = System.currentTimeMillis();
        try {
            Object result = joinPoint.proceed();
            long duration = System.currentTimeMillis() - startTime;
            log.info("Response: {} in {}ms", 
                     joinPoint.getSignature().getName(), duration);
            return result;
        } catch (Exception e) {
            log.error("Error in {}: {}", 
                      joinPoint.getSignature().getName(), e.getMessage());
            throw e;
        }
    }
}
```

#### 2. 性能监控
```java
@Metric(name = "api.response.time", type = MetricType.HISTOGRAM)
@GetMapping("/query-def")
public ApiResult<DefJson> queryDef(Long id) {
    return WarmFlowService.queryDef(id);
}
```

### 6. 测试策略

#### 1. 单元测试
```java
@SpringBootTest
public class WarmFlowControllerTest {
    
    @Autowired
    private WarmFlowController controller;
    
    @MockBean
    private WarmFlowService service;
    
    @Test
    public void testConfig() {
        when(service.config()).thenReturn(ApiResult.ok(new WarmFlowVo()));
        
        ApiResult<WarmFlowVo> result = controller.config();
        
        assertEquals(200, result.getCode());
        assertNotNull(result.getData());
    }
}
```

#### 2. 集成测试
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = "warm-flow.ui=true")
public class WarmFlowIntegrationTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    public void testConfigEndpoint() {
        ResponseEntity<ApiResult> response = 
            restTemplate.getForEntity("/warm-flow-ui/config", ApiResult.class);
            
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().getCode() == 200);
    }
}
```

通过遵循这些最佳实践，可以构建出高质量、高性能、高安全性的WarmFlow Web控制器层，为前端应用提供稳定可靠的API服务。
# UI插件

<cite>
**本文档引用文件**  
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/pom.xml)
- [warm-flow-plugin-ui-core/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/pom.xml)
- [warm-flow-plugin-ui-sb-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/pom.xml)
- [warm-flow-plugin-ui-solon-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/pom.xml)
- [warm-flow-plugin-vue3-ui/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/pom.xml)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [WarmFlowUiController.java (Spring Boot)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowUiController.java (Solon)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)
- [index.html](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/src/main/resources/warm-flow-ui/index.html)
- [vite.config.js](file://warm-flow-ui/vite.config.js)
- [package.json](file://warm-flow-ui/package.json)
</cite>

## 目录
1. [项目结构](#项目结构)
2. [核心组件](#核心组件)
3. [架构概述](#架构概述)
4. [详细组件分析](#详细组件分析)
5. [依赖分析](#依赖分析)
6. [性能考虑](#性能考虑)
7. [故障排除指南](#故障排除指南)
8. [结论](#结论)

## 项目结构

warm-flow-plugin-ui模块采用多模块Maven项目结构，包含核心服务、Web框架适配器和前端资源包。该结构支持Spring Boot和Solon两种Java框架的集成。

```mermaid
graph TD
A[warm-flow-plugin-ui] --> B[warm-flow-plugin-ui-core]
A --> C[warm-flow-plugin-ui-sb-web]
A --> D[warm-flow-plugin-ui-solon-web]
A --> E[warm-flow-plugin-vue3-ui]
B --> F[warm-flow-plugin-vue3-ui]
C --> B
D --> B
```

**图示来源**  
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/pom.xml)
- [warm-flow-plugin-ui-core/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/pom.xml)
- [warm-flow-plugin-ui-sb-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/pom.xml)
- [warm-flow-plugin-ui-solon-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/pom.xml)

**本节来源**  
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/pom.xml)

## 核心组件

warm-flow-plugin-ui模块的核心组件包括`warm-flow-plugin-ui-core`、`warm-flow-plugin-ui-sb-web`、`warm-flow-plugin-ui-solon-web`和`warm-flow-plugin-vue3-ui`。这些组件共同实现了UI服务的通用逻辑、REST API暴露、静态资源注册和前端应用集成。

**本节来源**  
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/pom.xml)
- [warm-flow-plugin-ui-core/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/pom.xml)

## 架构概述

warm-flow-plugin-ui模块的架构设计旨在实现前后端一体化部署，通过插件化方式集成到不同的Java Web框架中。该架构支持Spring Boot和Solon框架，提供了灵活的集成选项。

```mermaid
graph TB
subgraph "前端"
A[Vue3应用] --> B[Vite构建]
B --> C[构建产物]
end
subgraph "后端"
D[warm-flow-plugin-vue3-ui] --> E[warm-flow-plugin-ui-core]
E --> F[warm-flow-plugin-ui-sb-web]
E --> G[warm-flow-plugin-ui-solon-web]
F --> H[Spring Boot]
G --> I[Solon]
end
C --> D
H --> J[REST API /warm-flow-ui/config]
I --> K[静态资源 /warm-flow-ui/]
```

**图示来源**  
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [WarmFlowUiController.java (Spring Boot)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowUiController.java (Solon)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)

## 详细组件分析

### warm-flow-plugin-ui-core分析

`warm-flow-plugin-ui-core`模块提供通用的UI服务逻辑，是整个UI插件的核心。它定义了各种服务接口和实现，为上层Web框架适配器提供统一的API。

#### 类图
```mermaid
classDiagram
class WarmFlowService {
+static ApiResult<WarmFlowVo> config()
+static ApiResult<Void> saveJson(DefJson, boolean)
+static ApiResult<DefJson> queryDef(Long)
+static ApiResult<DefJson> queryFlowChart(Long)
+static ApiResult<List<String>> handlerType()
+static ApiResult<HandlerSelectVo> handlerResult(HandlerQuery)
+static ApiResult<List<HandlerFeedBackVo>> handlerFeedback(HandlerFeedBackDto)
+static ApiResult<List<Dict>> handlerDict()
+static ApiResult<List<Form>> publishedForm()
+static ApiResult<String> getFormContent(Long)
+static ApiResult<Void> saveFormContent(FlowDto)
+static ApiResult<FlowDto> load(Long)
+static ApiResult<FlowDto> hisLoad(Long)
+static ApiResult<Instance> handle(Map, Long, String, String, String)
+static ApiResult<List<NodeExt>> nodeExt()
}
class CategoryService {
<<interface>>
+List<Tree> queryCategory()
}
class FormPathService {
<<interface>>
+List<Tree> queryFormPath()
}
class HandlerSelectService {
<<interface>>
+List<String> getHandlerType()
+HandlerSelectVo getHandlerSelect(HandlerQuery)
+List<HandlerFeedBackVo> handlerFeedback(List<String>)
}
class HandlerDictService {
<<interface>>
+List<Dict> getHandlerDict()
}
class ChartExtService {
<<interface>>
+void initPromptContent(DefJson)
+void execute(DefJson)
}
class NodeExtService {
<<interface>>
+List<NodeExt> getNodeExt()
}
WarmFlowService --> CategoryService : "使用"
WarmFlowService --> FormPathService : "使用"
WarmFlowService --> HandlerSelectService : "使用"
WarmFlowService --> HandlerDictService : "使用"
WarmFlowService --> ChartExtService : "使用"
WarmFlowService --> NodeExtService : "使用"
```

**图示来源**  
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [CategoryService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/CategoryService.java)
- [FormPathService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/FormPathService.java)
- [HandlerSelectService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerSelectService.java)

**本节来源**  
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)

### warm-flow-plugin-ui-sb-web分析

`warm-flow-plugin-ui-sb-web`模块通过`WarmFlowUiController`暴露REST API，供前端调用。它基于Spring Boot框架，使用标准的Spring MVC注解来定义Web端点。

#### 序列图
```mermaid
sequenceDiagram
participant Frontend as 前端
participant Controller as WarmFlowUiController
participant Service as WarmFlowService
Frontend->>Controller : GET /warm-flow-ui/config
Controller->>Service : WarmFlowService.config()
Service-->>Controller : ApiResult<WarmFlowVo>
Controller-->>Frontend : 返回配置信息
```

**图示来源**  
- [WarmFlowUiController.java (Spring Boot)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)

**本节来源**  
- [WarmFlowUiController.java (Spring Boot)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)

### warm-flow-plugin-ui-solon-web分析

`warm-flow-plugin-ui-solon-web`模块通过`XPluginImpl`注册静态资源路径`/warm-flow-ui/`以服务前端文件。它基于Solon框架，使用插件机制来集成静态资源服务。

#### 序列图
```mermaid
sequenceDiagram
participant Solon as Solon框架
participant Plugin as XPluginImpl
participant Static as StaticMappings
Solon->>Plugin : 启动插件
Plugin->>Plugin : beanScan(XPluginImpl.class)
Plugin->>Plugin : 获取WarmFlow配置
Plugin->>Static : StaticMappings.add(\"/warm-flow-ui/\", ClassPathStaticRepository)
Static-->>Solon : 注册静态资源路径
```

**图示来源**  
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)
- [WarmFlowUiController.java (Solon)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)

**本节来源**  
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)

### warm-flow-plugin-vue3-ui分析

`warm-flow-plugin-vue3-ui`作为资源包，将构建好的Vue3前端应用嵌入到服务端。它通过Maven资源插件将前端资源复制到`/META-INF/resources/warm-flow-ui/`目录下，实现静态资源的自动服务。

#### 流程图
```mermaid
flowchart TD
A[Vue3前端项目] --> B[Vite构建]
B --> C[生成静态资源]
C --> D[复制到src/main/resources]
D --> E[Maven构建]
E --> F[复制到META-INF/resources]
F --> G[JAR包]
G --> H[运行时自动服务]
```

**图示来源**  
- [warm-flow-plugin-vue3-ui/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/pom.xml)
- [index.html](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/src/main/resources/warm-flow-ui/index.html)

**本节来源**  
- [warm-flow-plugin-vue3-ui/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/pom.xml)

### 前端构建分析

前端`warm-flow-ui`项目使用Vite构建工具，通过现代化的前端开发流程，实现高效的开发和生产构建。Vite配置了别名、代理、CSS处理等特性，支持模块化开发。

#### 流程图
```mermaid
flowchart TD
A[源代码] --> B[Vite开发服务器]
B --> C[热更新]
C --> D[开发环境]
A --> E[Vite构建]
E --> F[代码分割]
F --> G[资源优化]
G --> H[生产环境]
```

**图示来源**  
- [vite.config.js](file://warm-flow-ui/vite.config.js)
- [package.json](file://warm-flow-ui/package.json)

**本节来源**  
- [vite.config.js](file://warm-flow-ui/vite.config.js)

## 依赖分析

warm-flow-plugin-ui模块的依赖关系清晰，各组件之间耦合度低，便于维护和扩展。核心依赖包括Spring Boot、Solon、Vue3和Vite等技术栈。

```mermaid
graph TD
A[warm-flow-plugin-ui] --> B[warm-flow-plugin-ui-core]
A --> C[warm-flow-plugin-ui-sb-web]
A --> D[warm-flow-plugin-ui-solon-web]
A --> E[warm-flow-plugin-vue3-ui]
B --> F[warm-flow-core]
B --> E
C --> B
C --> G[Spring WebMVC]
C --> H[warm-flow-plugin-modes-sb]
D --> B
D --> I[Solon]
D --> J[warm-flow-plugin-modes-solon]
E --> K[Vue3]
E --> L[Vite]
```

**图示来源**  
- [warm-flow-plugin-ui-core/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/pom.xml)
- [warm-flow-plugin-ui-sb-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/pom.xml)
- [warm-flow-plugin-ui-solon-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/pom.xml)
- [warm-flow-plugin-vue3-ui/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/pom.xml)

**本节来源**  
- [warm-flow-plugin-ui-core/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/pom.xml)
- [warm-flow-plugin-ui-sb-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/pom.xml)
- [warm-flow-plugin-ui-solon-web/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/pom.xml)
- [warm-flow-plugin-vue3-ui/pom.xml](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-vue3-ui/pom.xml)

## 性能考虑

warm-flow-plugin-ui模块在设计时考虑了性能因素，通过合理的架构设计和技术选型，确保了系统的高效运行。前端使用Vite构建工具，提供快速的开发服务器和优化的生产构建；后端通过插件化设计，减少了不必要的依赖和开销。

## 故障排除指南

当遇到UI插件相关问题时，可以按照以下步骤进行排查：
1. 检查`warm-flow-plugin-ui-core`是否正确引入
2. 确认`warm-flow-plugin-ui-sb-web`或`warm-flow-plugin-ui-solon-web`是否根据使用的框架正确引入
3. 验证前端资源是否正确打包到JAR文件的`META-INF/resources/warm-flow-ui/`目录下
4. 检查REST API端点`/warm-flow-ui/config`是否可访问
5. 确认静态资源路径`/warm-flow-ui/`是否正确注册

**本节来源**  
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [WarmFlowUiController.java (Spring Boot)](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-sb-web/src/main/java/org/dromara/warm/flow/ui/controller/WarmFlowUiController.java)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-solon-web/src/main/java/org/dromara/warm/flow/ui/XPluginImpl.java)

## 结论

warm-flow-plugin-ui模块通过精心设计的架构，实现了前后端一体化部署。`warm-flow-plugin-ui-core`提供通用UI服务逻辑，`warm-flow-plugin-ui-sb-web`通过`WarmFlowUiController`暴露REST API，`warm-flow-plugin-ui-solon-web`通过`XPluginImpl`注册静态资源路径，而`warm-flow-plugin-vue3-ui`作为资源包将构建好的Vue3前端应用嵌入到服务端。前端项目使用Vite构建，最终被后端插件引用，实现了完整的前后端集成解决方案。
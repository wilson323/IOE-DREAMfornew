# UI核心服务

<cite>
**本文档引用的文件**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java)
- [CategoryService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/CategoryService.java)
- [NodeExtService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/NodeExtService.java)
- [TreeUtil.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/utils/TreeUtil.java)
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java)
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java)
- [HandlerSelectService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerSelectService.java)
- [FormPathService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/FormPathService.java)
- [HandlerFeedBackDto.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerFeedBackDto.java)
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java)
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java)
- [Dict.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/Dict.java)
- [HandlerAuth.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerAuth.java)
- [HandlerFeedBackVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerFeedBackVo.java)
</cite>

## 目录
1. [简介](#简介)
2. [核心服务类职责](#核心服务类职责)
3. [DTO与VO对象在数据传输中的作用](#dto与vo对象在数据传输中的作用)
4. [TreeUtil工具类在树形结构处理中的应用](#treeutil工具类在树形结构处理中的应用)
5. [服务层与流程引擎的交互](#服务层与流程引擎的交互)
6. [接口设计原则与异常处理](#接口设计原则与异常处理)

## 简介
warm-flow-plugin-ui-core模块是流程引擎的UI交互核心组件，负责封装前端界面与流程引擎之间的交互逻辑。该模块通过一系列服务类、数据传输对象(DTO)和视图对象(VO)实现了流程分类管理、节点扩展属性配置、办理人选择器等功能，为前端提供了统一的API接口。

## 核心服务类职责

### CategoryService服务
CategoryService接口定义了流程分类管理的功能，主要提供查询分类的方法。该服务允许业务系统实现自定义的分类逻辑，为流程设计器提供分类数据支持。

**服务职责**
- 提供流程分类数据查询接口
- 支持业务系统自定义分类实现
- 与WarmFlowService协同工作，为流程定义提供分类信息

**接口方法**
- `queryCategory()`: 查询所有分类，返回树形结构的分类数据

**实现特点**
- 采用接口形式，便于业务系统扩展
- 返回Tree对象列表，支持树形结构展示

**节来源**
- [CategoryService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/CategoryService.java#L28-L36)

### WarmFlowService服务
WarmFlowService是UI核心服务的主入口，封装了流程引擎与前端交互的主要功能。该服务通过调用core模块的FlowEngine进行业务处理，并对结果进行适配和转换以满足前端需求。

**核心功能**
- 流程配置管理
- 流程定义数据处理
- 办理人权限设置
- 表单内容管理
- 任务处理接口

**关键方法**
- `config()`: 返回流程配置信息，包括tokenName等安全配置
- `saveJson()`: 保存流程JSON字符串
- `queryDef()`: 获取流程定义数据
- `queryFlowChart()`: 获取流程图数据
- `handlerType()`: 获取办理人权限类型
- `handlerResult()`: 获取办理人选择结果
- `nodeExt()`: 获取节点扩展属性

**实现特点**
- 静态方法设计，便于直接调用
- 统一返回ApiResult封装结果
- 异常处理机制完善
- 通过FrameInvoker.getBean()获取业务系统实现的服务

**节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L46-L355)

### NodeExtService服务
NodeExtService接口定义了流程设计器中节点扩展属性的功能，允许业务系统自定义节点的扩展属性。

**服务职责**
- 提供节点扩展属性查询接口
- 支持业务系统自定义节点属性
- 为流程设计器提供丰富的节点配置选项

**接口方法**
- `getNodeExt()`: 获取所有节点扩展属性

**实现特点**
- 采用接口形式，便于业务系统扩展
- 返回NodeExt对象列表，包含属性代码、名称、描述等信息
- 支持嵌套的子属性和字典项

**节来源**
- [NodeExtService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/NodeExtService.java#L27-L35)

## DTO与VO对象在数据传输中的作用

### HandlerQuery DTO
HandlerQuery是办理人权限设置列表的查询参数DTO，用于封装前端传递的查询条件。

**属性说明**
- `handlerCode`: 办理权限编码
- `handlerName`: 办理权限名称
- `handlerType`: 办理权限类型（用户/角色/部门等）
- `groupId`: 页面左侧树权限分组主键
- `pageNum`: 当前页码
- `pageSize`: 每页显示条数
- `beginTime`: 开始时间
- `endTime`: 结束时间

**使用场景**
- 办理人选择器的分页查询
- 权限列表的筛选查询
- 树形结构与列表数据的联动查询

**节来源**
- [HandlerQuery.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/dto/HandlerQuery.java#L29-L71)

### WarmFlowVo VO
WarmFlowVo是流程配置的视图对象，用于向前端返回流程引擎的配置信息。

**属性说明**
- `tokenNameList`: token名称列表，用于权限验证

**使用场景**
- 初始化流程设计器时获取系统配置
- 前端权限验证配置
- 系统间权限共享配置

**节来源**
- [WarmFlowVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/WarmFlowVo.java#L32-L38)

### HandlerSelectVo VO
HandlerSelectVo是办理人选择的视图对象，封装了办理人选择器所需的所有数据。

**属性说明**
- `handlerAuths`: 办理人权限分页列表，包含具体的办理对象（部门、角色、用户等）
- `treeSelections`: 左侧树状选择结构，与handlerAuths配合使用

**使用场景**
- 办理人选择器的数据显示
- 树形结构与列表数据的联动展示
- 分页查询结果的封装

**节来源**
- [HandlerSelectVo.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/HandlerSelectVo.java#L34-L45)

### NodeExt VO
NodeExt是节点扩展属性的视图对象，用于定义流程节点的可配置属性。

**属性说明**
- `code`: 属性代码
- `name`: 属性名称
- `desc`: 属性描述
- `type`: 属性类型
- `childs`: 子属性列表

**嵌套对象**
- `ChildNode`: 子属性对象，包含代码、描述、标签、类型、是否必填、是否多选等属性
- `DictItem`: 字典项对象，包含标签、值、是否选中等属性

**使用场景**
- 流程节点的扩展属性配置
- 自定义节点行为
- 节点属性的动态加载

**节来源**
- [NodeExt.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/vo/NodeExt.java#L32-L75)

## TreeUtil工具类在树形结构处理中的应用

### TreeUtil功能概述
TreeUtil工具类提供了树形结构数据处理的核心功能，主要用于将扁平化的分类、路径等数据转换为树形结构。

**核心方法**
- `buildTree(List<Tree> trees)`: 构建树形结构
- `recursionFn(List<Tree> list, Tree t)`: 递归构建子节点
- `hasChild(List<Tree> list, Tree t)`: 判断是否有子节点
- `getChildList(List<Tree> list, Tree t)`: 获取子节点列表

### 树形结构构建算法
TreeUtil采用递归算法构建树形结构，主要步骤如下：

1. **识别根节点**: 遍历所有节点，找出父节点ID不在节点ID列表中的节点作为根节点
2. **递归构建**: 对每个根节点，递归查找其子节点并构建子树
3. **返回结果**: 返回构建完成的树形结构列表

**算法特点**
- 时间复杂度: O(n²)，其中n为节点数量
- 空间复杂度: O(n)，用于存储树形结构
- 支持多根节点的森林结构

### 使用场景
TreeUtil在以下场景中被广泛应用：

**流程分类管理**
- 将扁平化的分类数据转换为树形结构
- 支持多级分类展示
- 为流程设计器提供分类选择

**表单路径管理**
- 将自定义表单路径数据转换为树形结构
- 支持路径的层级展示
- 为表单选择提供结构化数据

**办理人选择器**
- 将部门、角色等组织结构数据转换为树形结构
- 支持按组织架构选择办理人
- 实现树形选择与列表展示的联动

**节来源**
- [TreeUtil.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/utils/TreeUtil.java#L25-L84)

## 服务层与流程引擎的交互

### 服务调用架构
warm-flow-plugin-ui-core模块通过FlowEngine与core模块进行交互，形成了清晰的分层架构：

```mermaid
graph TD
Frontend[前端界面] --> WarmFlowService[WarmFlowService]
WarmFlowService --> FlowEngine[FlowEngine]
FlowEngine --> CoreService[Core模块服务]
CoreService --> Database[(数据库)]
WarmFlowService --> BusinessService[业务系统服务]
BusinessService --> ExternalSystem[(外部系统)]
```

**交互特点**
- WarmFlowService作为UI层与核心引擎的桥梁
- FlowEngine提供核心业务逻辑的统一入口
- 业务系统服务实现特定业务逻辑
- 数据库持久化存储

### 核心交互流程
#### 流程定义数据获取流程
```mermaid
sequenceDiagram
participant Frontend as 前端
participant WarmFlowService as WarmFlowService
participant FlowEngine as FlowEngine
participant DefService as DefService
Frontend->>WarmFlowService : queryDef(id)
WarmFlowService->>FlowEngine : defService().queryDesign(id)
FlowEngine->>DefService : queryDesign(id)
DefService-->>FlowEngine : DefJson
FlowEngine-->>WarmFlowService : DefJson
WarmFlowService->>WarmFlowService : 获取分类数据
WarmFlowService->>CategoryService : queryCategory()
CategoryService-->>WarmFlowService : Tree列表
WarmFlowService->>TreeUtil : buildTree()
TreeUtil-->>WarmFlowService : 树形结构
WarmFlowService->>WarmFlowService : 设置分类列表
WarmFlowService-->>Frontend : ApiResult<DefJson>
```

#### 办理人选择流程
```mermaid
sequenceDiagram
participant Frontend as 前端
participant WarmFlowService as WarmFlowService
participant HandlerSelectService as HandlerSelectService
participant BusinessSystem as 业务系统
Frontend->>WarmFlowService : handlerResult(query)
WarmFlowService->>FrameInvoker : getBean(HandlerSelectService)
FrameInvoker-->>WarmFlowService : HandlerSelectService实例
WarmFlowService->>HandlerSelectService : getHandlerSelect(query)
HandlerSelectService->>BusinessSystem : 查询办理人数据
BusinessSystem-->>HandlerSelectService : 办理人数据
HandlerSelectService-->>WarmFlowService : HandlerSelectVo
WarmFlowService-->>Frontend : ApiResult<HandlerSelectVo>
```

### 数据适配与转换
服务层在调用core模块后，需要对结果进行适配和转换以满足前端需求：

**数据转换示例**
- 将core模块的实体对象转换为UI模块的VO对象
- 将扁平化数据转换为树形结构
- 将业务数据转换为前端可识别的格式
- 添加前端所需的额外信息

**转换策略**
- 使用DTO封装查询参数
- 使用VO封装返回结果
- 保持接口的稳定性
- 支持业务系统的扩展

**节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L92-L115)
- [HandlerSelectService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/HandlerSelectService.java#L54-L55)

## 接口设计原则与异常处理

### 接口设计原则
warm-flow-plugin-ui-core模块遵循以下接口设计原则：

**统一返回格式**
- 所有接口返回ApiResult封装对象
- 包含成功状态、消息和数据
- 支持泛型，可返回不同类型的数据

**职责单一**
- 每个服务类只负责特定领域的功能
- 方法功能明确，避免功能重叠
- 接口粒度适中，既不过于细碎也不过于庞大

**扩展性设计**
- 使用接口定义服务，便于业务系统扩展
- 提供默认实现，降低使用门槛
- 支持插件化架构，可动态加载功能

**前后端分离**
- 提供RESTful风格的API
- 数据格式标准化（JSON）
- 关注点分离，UI层不包含业务逻辑

### 异常处理机制
模块采用统一的异常处理机制，确保系统的稳定性和可维护性。

**异常处理策略**
- 使用try-catch捕获异常
- 记录详细的错误日志
- 抛出自定义的FlowException
- 返回友好的错误信息

**异常处理示例**
```java
public static ApiResult<DefJson> queryDef(Long id) {
    try {
        // 业务逻辑
        return ApiResult.ok(defJson);
    } catch (Exception e) {
        log.error("获取流程json字符串", e);
        throw new FlowException(ExceptionUtil.handleMsg("获取流程json字符串失败", e));
    }
}
```

**异常处理特点**
- 全局异常捕获，避免异常泄露
- 详细的错误日志记录
- 用户友好的错误提示
- 异常信息的标准化处理

**节来源**
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L116-L119)
- [WarmFlowService.java](file://warm-flow-plugin/warm-flow-plugin-ui/warm-flow-plugin-ui-core/src/main/java/org/dromara/warm/flow/ui/service/WarmFlowService.java#L147-L149)
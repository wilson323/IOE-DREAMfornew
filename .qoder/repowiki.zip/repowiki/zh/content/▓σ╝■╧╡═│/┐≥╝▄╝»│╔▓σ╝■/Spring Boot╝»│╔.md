# Spring Boot集成

<cite>
**本文档引用的文件**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java)
- [WarmFlowProperties.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/WarmFlowProperties.java)
- [SpringUtil.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/utils/SpringUtil.java)
- [ConditionStrategySpel.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/expression/ConditionStrategySpel.java)
- [VariableStrategySpel.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/expression/VariableStrategySpel.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/pom.xml)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概览](#架构概览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介

warm-flow-plugin-modes-sb模块是Warm-Flow工作流引擎与Spring Boot框架集成的核心组件，提供了无缝的自动化配置和依赖注入功能。该模块通过Spring Boot的自动配置机制，实现了工作流引擎的快速部署和配置管理，使开发者能够轻松地在Spring Boot项目中集成强大的工作流功能。

该模块的主要特性包括：
- 基于Spring Boot的自动配置
- 通过`@Configuration`和`@Bean`注解的组件注册
- 配置属性的自动绑定
- 表达式策略的动态支持
- 与Spring上下文的深度集成

## 项目结构

warm-flow-plugin-modes-sb模块采用标准的Spring Boot Starter结构，包含以下关键目录：

```mermaid
graph TD
A[warm-flow-plugin-modes-sb] --> B[config]
A --> C[expression]
A --> D[helper]
A --> E[utils]
B --> F[BeanConfig.java]
B --> G[WarmFlowProperties.java]
C --> H[ConditionStrategySpel.java]
C --> I[VariableStrategySpel.java]
C --> J[ListenerStrategySpel.java]
C --> K[ConditionStrategyDefault.java]
D --> L[SpelHelper.java]
E --> M[SpringUtil.java]
```

**图表来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L1-L177)
- [WarmFlowProperties.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/WarmFlowProperties.java#L1-L27)

**章节来源**
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/pom.xml#L1-L64)

## 核心组件

warm-flow-plugin-modes-sb模块的核心组件包括：

### BeanConfig类
负责Spring Boot自动配置的核心配置类，通过`@Configuration`和`@Bean`注解注册所有工作流相关的服务组件。

### WarmFlowProperties类  
继承自核心配置类，通过`@ConfigurationProperties`实现配置项的自动绑定。

### SpringUtil工具类
提供Spring上下文访问能力，支持静态方法获取Bean实例。

### 表达式策略类
实现SpEL表达式支持，包括条件判断、变量解析和监听器策略。

**章节来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L49-L53)
- [WarmFlowProperties.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/WarmFlowProperties.java#L24-L26)

## 架构概览

warm-flow-plugin-modes-sb模块采用分层架构设计，实现了清晰的关注点分离：

```mermaid
graph TB
subgraph "Spring Boot层"
A[BeanConfig] --> B[Spring容器]
C[WarmFlowProperties] --> B
D[SpringUtil] --> B
end
subgraph "表达式层"
E[ConditionStrategySpel] --> F[SpelHelper]
G[VariableStrategySpel] --> F
H[ListenerStrategySpel] --> F
I[ConditionStrategyDefault] --> F
end
subgraph "核心引擎层"
J[FlowEngine] --> K[WarmFlow]
L[DefService] --> M[FlowDefinitionDao]
N[NodeService] --> O[FlowNodeDao]
P[InsService] --> Q[FlowInstanceDao]
end
B --> E
B --> G
B --> H
B --> I
B --> J
B --> L
B --> N
B --> P
```

**图表来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L142-L154)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L114-L135)

## 详细组件分析

### BeanConfig配置类分析

BeanConfig类是整个模块的核心配置类，采用了多种Spring Boot特性来实现自动配置：

#### 注解组合使用
```mermaid
classDiagram
class BeanConfig {
<<@Configuration>>
<<@Import(SpringUtil, SpelHelper)>>
<<@ConditionalOnProperty(warm-flow.enabled)>>
<<@EnableConfigurationProperties(WarmFlowProperties)>>
+definitionDao() FlowDefinitionDao
+definitionService(definitionDao) DefService
+nodeService(nodeDao) NodeService
+instanceService(instanceDao) InsService
+taskService(taskDao) TaskService
+hisTaskService(hisTaskDao) HisTaskService
+flowUserService(userDao) UserService
+flowFormService(formDao) FormService
+initFlow() WarmFlow
-setExpression() void
-setNewEntity() void
+after(flowConfig) void
}
class SpringUtil {
+getApplicationContext() ApplicationContext
+getBean(clazz) M
}
class SpelHelper {
+parseExpression(expression, variable) Object
}
BeanConfig --> SpringUtil
BeanConfig --> SpelHelper
```

**图表来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L50-L53)
- [SpringUtil.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/utils/SpringUtil.java#L26-L55)

#### 核心服务组件注册

BeanConfig类通过`@Bean`注解注册了以下核心服务组件：

| 组件类型 | DAO实现类 | Service实现类 | 功能描述 |
|---------|----------|--------------|----------|
| 流程定义 | FlowDefinitionDaoImpl | DefServiceImpl | 处理流程定义相关操作 |
| 节点管理 | FlowNodeDaoImpl | NodeServiceImpl | 管理流程节点信息 |
| 跳转规则 | FlowSkipDaoImpl | SkipServiceImpl | 处理节点间的跳转规则 |
| 实例管理 | FlowInstanceDaoImpl | InsServiceImpl | 管理流程实例生命周期 |
| 任务管理 | FlowTaskDaoImpl | TaskServiceImpl | 处理任务相关操作 |
| 历史任务 | FlowHisTaskDaoImpl | HisTaskServiceImpl | 管理历史任务记录 |
| 用户管理 | FlowUserDaoImpl | UserServiceImpl | 处理用户相关信息 |
| 表单管理 | FlowFormDaoImpl | FormServiceImpl | 管理表单定义 |

#### initFlow方法执行流程

```mermaid
sequenceDiagram
participant Spring as Spring容器
participant BeanConfig as BeanConfig
participant FlowEngine as FlowEngine
participant WarmFlow as WarmFlow
participant SpelHelper as SpelHelper
Spring->>BeanConfig : 自动扫描@Configuration
Spring->>BeanConfig : 创建BeanConfig实例
Spring->>BeanConfig : 调用@PostConstruct方法
BeanConfig->>BeanConfig : setNewEntity()
BeanConfig->>BeanConfig : FrameInvoker.setCfgFunction()
BeanConfig->>BeanConfig : FrameInvoker.setBeanFunction()
BeanConfig->>WarmFlow : 获取WarmFlowProperties
WarmFlow->>WarmFlow : warmFlow.init()
BeanConfig->>FlowEngine : FlowEngine.setFlowConfig()
BeanConfig->>BeanConfig : setExpression()
BeanConfig->>SpelHelper : ExpressionUtil.setExpression()
BeanConfig->>BeanConfig : after(warmFlow)
BeanConfig-->>Spring : 返回WarmFlow实例
```

**图表来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L142-L154)

**章节来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L58-L154)

### WarmFlowProperties配置属性分析

WarmFlowProperties类通过继承核心配置类并添加`@ConfigurationProperties`注解，实现了配置项的自动绑定：

```mermaid
classDiagram
class WarmFlow {
+boolean enabled
+boolean banner
+String keyType
+boolean logicDelete
+String logicDeleteValue
+String dataFillHandlerPath
+String tenantHandlerPath
+String dataSourceType
+boolean ui
+String tokenName
+String[] chartStatusColor
+init() void
+spiLoad() void
}
class WarmFlowProperties {
<<@ConfigurationProperties("warm-flow")>>
}
WarmFlowProperties --|> WarmFlow
```

**图表来源**
- [WarmFlowProperties.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/WarmFlowProperties.java#L24-L26)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L35-L135)

#### 支持的配置属性

| 属性名 | 类型 | 默认值 | 描述 |
|-------|------|--------|------|
| warm-flow.enabled | boolean | true | 是否启用工作流引擎 |
| warm-flow.banner | boolean | true | 是否显示启动横幅 |
| warm-flow.keyType | String | null | ID生成器类型 |
| warm-flow.logicDelete | boolean | false | 是否开启逻辑删除 |
| warm-flow.logicDeleteValue | String | "2" | 逻辑删除字段值 |
| warm-flow.dataFillHandlerPath | String | null | 数据填充处理类路径 |
| warm-flow.tenantHandlerPath | String | null | 租户模式处理类路径 |
| warm-flow.dataSourceType | String | null | 数据源类型 |
| warm-flow.ui | boolean | true | 是否启用UI界面 |
| warm-flow.tokenName | String | "Authorization" | 权限验证Token名称 |
| warm-flow.chartStatusColor | List\<String\> | null | 流程状态颜色配置 |

**章节来源**
- [WarmFlowProperties.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/WarmFlowProperties.java#L1-L27)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java#L40-L107)

### SpringUtil工具类分析

SpringUtil类提供了Spring上下文访问能力，支持静态方法获取Bean实例：

```mermaid
classDiagram
class SpringUtil {
-static ApplicationContext applicationContext
+getApplicationContext() ApplicationContext
+getBean(clazz) M
+setApplicationContext(applicationContext) void
}
class ApplicationContextAware {
<<interface>>
+setApplicationContext(applicationContext) void
}
SpringUtil ..|> ApplicationContextAware
```

**图表来源**
- [SpringUtil.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/utils/SpringUtil.java#L26-L55)

**章节来源**
- [SpringUtil.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/utils/SpringUtil.java#L1-L56)

### 表达式策略组件分析

warm-flow-plugin-modes-sb模块提供了完整的SpEL表达式支持，包括条件判断、变量解析和监听器策略：

#### 表达式策略架构

```mermaid
graph TB
subgraph "表达式策略层"
A[ConditionStrategySpel] --> B[SpelHelper]
C[VariableStrategySpel] --> B
D[ListenerStrategySpel] --> B
E[ConditionStrategyDefault]
end
subgraph "核心引擎"
F[ExpressionUtil] --> A
F --> C
F --> D
F --> E
end
subgraph "Spring集成"
B --> G[Spring上下文]
B --> H[Bean注入]
end
```

**图表来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L156-L161)
- [ConditionStrategySpel.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/expression/ConditionStrategySpel.java#L28-L39)

#### SpEL表达式支持特性

| 策略类型 | 表达式前缀 | 功能描述 | 使用场景 |
|---------|-----------|----------|----------|
| 条件策略 | spel | 支持复杂的条件判断表达式 | 节点跳转条件、审批条件 |
| 变量策略 | # | 支持变量预计算和解析 | 表单字段赋值、变量替换 |
| 监听器策略 | spel | 支持监听器中的表达式执行 | 事件触发、状态变更监听 |

**章节来源**
- [ConditionStrategySpel.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/expression/ConditionStrategySpel.java#L1-L40)
- [VariableStrategySpel.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/expression/VariableStrategySpel.java#L1-L40)

## 依赖关系分析

warm-flow-plugin-modes-sb模块的依赖关系体现了清晰的分层架构：

```mermaid
graph TD
A[warm-flow-plugin-modes-sb] --> B[warm-flow-core]
A --> C[spring-boot-autoconfigure]
A --> D[spring-boot]
A --> E[spring-context]
B --> F[warm-flow-mybatis-core]
B --> G[warm-flow-mybatis-plus-core]
A --> H[warm-flow-plugin-json]
subgraph "外部依赖"
C --> I[spring-boot-starter]
D --> I
E --> I
end
subgraph "可选依赖"
F -.-> A
G -.-> A
end
```

**图表来源**
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/pom.xml#L16-L60)

### 关键依赖说明

| 依赖项 | 版本要求 | 用途 | 必需性 |
|-------|---------|------|--------|
| spring-boot-autoconfigure | 最新版本 | 提供自动配置支持 | 必需 |
| spring-boot | 最新版本 | 核心Spring Boot功能 | 必需 |
| spring-context | 最新版本 | Spring上下文管理 | 必需 |
| warm-flow-core | 相同版本 | 核心工作流功能 | 必需 |
| warm-flow-plugin-json | 相同版本 | JSON序列化支持 | 必需 |

**章节来源**
- [pom.xml](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/pom.xml#L16-L60)

## 性能考虑

warm-flow-plugin-modes-sb模块在设计时充分考虑了性能优化：

### 延迟初始化策略
- 通过`@ConditionalOnProperty`注解实现按需加载
- 核心服务组件采用延迟初始化机制
- 表达式策略按需注册和加载

### 内存优化
- 使用工厂模式创建实体对象
- 合理的缓存策略避免重复创建
- 及时释放不需要的资源

### 并发安全
- Spring容器级别的线程安全保证
- 表达式解析器的线程安全设计
- 数据访问层的连接池管理

## 故障排除指南

### 常见问题及解决方案

#### 1. 工作流引擎未启用
**症状**: 应用启动后工作流功能不可用
**原因**: `warm-flow.enabled=false`
**解决方案**: 在application.yml中设置`warm-flow.enabled=true`

#### 2. 配置属性不生效
**症状**: 自定义配置无法覆盖默认值
**原因**: 缺少`@EnableConfigurationProperties`注解
**解决方案**: 确保在主配置类上添加`@EnableConfigurationProperties(WarmFlowProperties.class)`

#### 3. SpEL表达式解析失败
**症状**: 表达式语法正确但执行报错
**原因**: Spring上下文未正确初始化或Bean注入失败
**解决方案**: 检查SpringUtil是否正确初始化，确保SpelHelper可用

#### 4. 依赖注入失败
**症状**: 服务组件无法正常工作
**原因**: DAO实现类未正确注册或映射配置错误
**解决方案**: 检查MyBatis Mapper扫描配置和DAO实现类

**章节来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-sb/src/main/java/org/dromara/warm/plugin/modes/sb/config/BeanConfig.java#L51-L53)

## 结论

warm-flow-plugin-modes-sb模块通过精心设计的架构和Spring Boot集成特性，为开发者提供了强大而易用的工作流引擎集成方案。该模块的主要优势包括：

### 技术优势
- **零配置启动**: 通过自动配置实现开箱即用
- **灵活配置**: 支持丰富的配置选项和自定义扩展
- **表达式支持**: 完整的SpEL表达式支持，满足复杂业务需求
- **Spring生态**: 深度集成Spring Boot生态系统

### 开发体验
- **简化集成**: 几乎无需额外配置即可使用
- **类型安全**: 通过注解和泛型提供编译时检查
- **扩展性强**: 支持自定义策略和处理器
- **维护友好**: 清晰的分层架构便于维护和扩展

### 最佳实践建议
1. **合理配置**: 根据实际需求调整warm-flow相关配置
2. **性能监控**: 关注工作流引擎的性能指标
3. **安全考虑**: 正确配置权限验证和数据隔离
4. **版本管理**: 保持warm-flow与Spring Boot版本兼容

通过本文档的详细分析，开发者可以深入理解warm-flow-plugin-modes-sb模块的设计理念和实现细节，从而更好地在Spring Boot项目中集成和使用工作流功能。
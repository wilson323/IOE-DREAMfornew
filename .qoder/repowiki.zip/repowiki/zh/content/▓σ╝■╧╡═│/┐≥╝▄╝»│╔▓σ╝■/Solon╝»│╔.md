# Solon集成

<cite>
**本文档引用文件**   
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)
- [org.dromara.warm.plugin.modes.solon.properties](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/resources/META-INF/solon/org.dromara.warm.plugin.modes.solon.properties)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java)
- [FrameInvoker.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/invoker/FrameInvoker.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)
</cite>

## 目录
1. [简介](#简介)
2. [插件化集成机制](#插件化集成机制)
3. [核心组件分析](#核心组件分析)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考量](#性能考量)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文档全面解析warm-flow-plugin-modes-solon模块如何实现与Solon框架的插件化集成。重点描述XPluginImpl作为Solon插件入口，如何实现Plugin接口并在start方法中通过AppContext.beanMake触发BeanConfig的加载，完成组件注入。说明BeanConfig类在非Spring环境下如何手动构建并注册所有必要的DAO和服务实例（如DefinitionService、NodeService等），以及如何初始化FlowEngine核心引擎，设置实体工厂、表达式策略（SpEL）和框架调用器（FrameInvoker），确保与Solon的IoC容器协同工作。对比Spring Boot的自动装配机制，突出Solon插件模式的轻量级与启动效率优势，并提供在Solon应用中集成warm-flow的具体配置步骤和注意事项。

## 插件化集成机制

warm-flow-plugin-modes-solon模块通过Solon框架的插件机制实现无缝集成。该模块遵循Solon的插件规范，在`META-INF/solon/`目录下提供属性文件，声明插件入口类，从而在应用启动时被自动加载和执行。

```mermaid
flowchart TD
A["Solon应用启动"] --> B["加载META-INF/solon/*.properties"]
B --> C["发现solon.plugin属性"]
C --> D["实例化XPluginImpl"]
D --> E["调用start方法"]
E --> F["通过beanMake加载BeanConfig"]
F --> G["完成组件注册与初始化"]
```

**图源**
- [org.dromara.warm.plugin.modes.solon.properties](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/resources/META-INF/solon/org.dromara.warm.plugin.modes.solon.properties)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)

**本节来源**
- [org.dromara.warm.plugin.modes.solon.properties](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/resources/META-INF/solon/org.dromara.warm.plugin.modes.solon.properties)
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)

## 核心组件

warm-flow-plugin-modes-solon模块的核心在于`XPluginImpl`和`BeanConfig`两个类的协同工作。`XPluginImpl`作为插件的启动入口，负责触发`BeanConfig`的加载。`BeanConfig`则承担了所有核心组件的注册与初始化工作，包括DAO、Service实例以及FlowEngine引擎的配置。

**本节来源**
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)

## 架构概述

该模块的架构设计体现了清晰的分层和职责分离。上层是Solon框架的插件机制，负责生命周期管理；中层是`BeanConfig`配置类，负责组件的装配；底层是warm-flow-core提供的核心引擎和业务逻辑。

```mermaid
graph TD
subgraph "Solon框架"
A["XPluginImpl"]
B["AppContext"]
end
subgraph "warm-flow插件层"
C["BeanConfig"]
end
subgraph "warm-flow核心层"
D["FlowEngine"]
E["DAO/Service"]
F["FrameInvoker"]
end
A --> |start| B
B --> |beanMake| C
C --> |注册| D
C --> |注册| E
C --> |配置| F
D --> |调用| F
```

**图源**
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java)
- [FrameInvoker.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/invoker/FrameInvoker.java)

## 详细组件分析

### XPluginImpl分析
`XPluginImpl`是整个插件的入口点，它实现了Solon的`Plugin`接口。当Solon应用启动时，会根据`META-INF/solon/`下的属性文件找到并实例化此类，然后调用其`start`方法。

```mermaid
classDiagram
class XPluginImpl {
+start(AppContext context) void
}
XPluginImpl ..|> Plugin : 实现
Plugin <.. AppContext : 被调用
```

**图源**
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)

**本节来源**
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)

### BeanConfig分析
`BeanConfig`是一个配置类，使用`@Configuration`注解标记。它通过`@Bean`注解的方法，手动创建并注册了所有必要的DAO和服务实例。这是在非Spring环境下实现依赖注入的关键。

```mermaid
classDiagram
class BeanConfig {
+definitionDao() FlowDefinitionDao
+definitionService(FlowDefinitionDao) DefService
+nodeDao() FlowNodeDao
+nodeService(FlowNodeDao) NodeService
+initFlow(WarmFlow) WarmFlow
+setNewEntity() void
}
BeanConfig --> FlowDefinitionDaoImpl : 创建
BeanConfig --> DefServiceImpl : 创建
BeanConfig --> FlowNodeDaoImpl : 创建
BeanConfig --> NodeServiceImpl : 创建
BeanConfig --> FlowEngine : 配置
```

**图源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)

**本节来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)

### FlowEngine初始化分析
`BeanConfig`中的`initFlow`方法是整个初始化流程的核心。它不仅设置了`FrameInvoker`以适配Solon的IoC容器，还调用了`FlowEngine.setFlowConfig`来初始化核心引擎。

```mermaid
sequenceDiagram
participant BeanConfig
participant FrameInvoker
participant FlowEngine
participant WarmFlow
BeanConfig->>FrameInvoker : setCfgFunction(Solon.cfg().get)
BeanConfig->>FrameInvoker : setBeanFunction(Solon.context() : : getBean)
BeanConfig->>WarmFlow : warmFlow.init()
WarmFlow->>FlowEngine : initTenantHandler()
WarmFlow->>FlowEngine : initDataFillHandler()
WarmFlow->>FlowEngine : initPermissionHandler()
WarmFlow->>FlowEngine : initGlobalListener()
BeanConfig->>FlowEngine : setFlowConfig(warmFlow)
```

**图源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)
- [FrameInvoker.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/invoker/FrameInvoker.java)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)

**本节来源**
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)
- [FrameInvoker.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/invoker/FrameInvoker.java)
- [FlowEngine.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/FlowEngine.java)
- [WarmFlow.java](file://warm-flow-core/src/main/java/org/dromara/warm/flow/core/config/WarmFlow.java)

## 依赖分析

该模块的依赖关系清晰，主要依赖于Solon框架的核心库和warm-flow-core模块。

```mermaid
graph TD
A["warm-flow-plugin-modes-solon"] --> B["solon-core"]
A --> C["warm-flow-core"]
A --> D["warm-flow-orm"]
B --> E["JDK"]
C --> E
D --> E
```

**图源**
- [pom.xml](file://warm-flow/pom.xml)

**本节来源**
- [pom.xml](file://warm-flow/pom.xml)

## 性能考量
与Spring Boot的自动装配相比，Solon的插件模式具有更轻量级和更快的启动速度。warm-flow-plugin-modes-solon模块通过手动配置`BeanConfig`，避免了Spring的类路径扫描和复杂的Bean后处理器，从而减少了启动时的开销。同时，`FrameInvoker`的设计使得核心引擎可以无缝适配不同的IoC容器，保证了性能和灵活性。

## 故障排除指南
在集成过程中，如果遇到组件无法注入或`FlowEngine`初始化失败的问题，请检查以下几点：
1. 确认`warm-flow-plugin-modes-solon`依赖已正确添加到项目中。
2. 检查`META-INF/solon/`目录下的属性文件是否正确配置。
3. 确保`XPluginImpl`类能够被正确加载。
4. 验证`BeanConfig`中的`@Bean`方法是否被成功调用。

**本节来源**
- [XPluginImpl.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/XPluginImpl.java)
- [BeanConfig.java](file://warm-flow-plugin/warm-flow-plugin-modes/warm-flow-plugin-modes-solon/src/main/java/org/dromara/warm/plugin/modes/solon/config/BeanConfig.java)

## 结论
warm-flow-plugin-modes-solon模块通过精巧的设计，成功实现了与Solon框架的插件化集成。它利用`XPluginImpl`作为入口，通过`BeanConfig`完成了所有核心组件的注册和`FlowEngine`的初始化。这种模式不仅保持了与Spring Boot版本功能的一致性，还充分发挥了Solon框架轻量、高效的优势，为开发者提供了一个高性能的工作流解决方案。
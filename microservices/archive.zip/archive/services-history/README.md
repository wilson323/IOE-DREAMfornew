# 历史微服务归档

本目录包含已弃用的微服务代码，这些服务已被整合到新的微服务架构中。

## 弃用服务列表

| 服务名称 | 替换方案 | 整合时间 |
|---------|---------|---------|
| ioedream-auth-service | ioedream-common-service | 2025-12 |
| ioedream-identity-service | ioedream-common-service | 2025-12 |
| ioedream-notification-service | ioedream-common-service | 2025-12 |
| ioedream-audit-service | ioedream-common-service | 2025-12 |
| ioedream-scheduler-service | ioedream-common-service | 2025-12 |
| ioedream-monitor-service | ioedream-common-service | 2025-12 |
| ioedream-enterprise-service | ioedream-oa-service | 2025-12 |
| ioedream-device-service | ioedream-device-comm-service | 2025-12 |
| ioedream-infrastructure-service | ioedream-oa-service | 2025-12 |
| ioedream-integration-service | 拆分到各业务服务 | 2025-12 |
| ioedream-report-service | 拆分到各业务服务 | 2025-12 |
| ioedream-system-service | ioedream-common-service | 2025-12 |
| ioedream-config-service | Nacos配置中心 | 2025-12 |

## 注意事项

- 这些代码仅作历史参考，不应在新开发中使用
- 新的微服务架构请参考 `microservices/` 目录下的活跃服务
- 详细的迁移方案请查看项目文档
- 所有业务逻辑已迁移到新的微服务架构中

## 当前活跃服务

- ioedream-gateway-service (8080) - API网关
- ioedream-common-service (8088) - 公共业务服务
- ioedream-device-comm-service (8087) - 设备通讯服务
- ioedream-oa-service (8089) - OA办公服务
- ioedream-access-service (8090) - 门禁管理服务
- ioedream-attendance-service (8091) - 考勤管理服务
- ioedream-video-service (8092) - 视频监控服务
- ioedream-consume-service (8094) - 消费管理服务
- ioedream-visitor-service (8095) - 访客管理服务